/* global _:true */
/* global gdt:true */
jQuery.sap.declare("gdt.salesui.s4.Component");
jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
jQuery.sap.require("sap.m.MessageToast");
jQuery.sap.require("gdt.salesui.s4.data.Preloader");

sap.ui.core.UIComponent.extend("gdt.salesui.s4.Component", {

	metadata: {
		manifest: "json"
	},

	init: function () {

		var that = this,
			core = sap.ui.getCore(),
			serviceConfig = this.getMetadata().getConfig()["serviceConfig"],
			manifestServiceUrl = this.getMetadata().getManifestEntry("sap.app").dataSources["mainService"].uri,
			serviceUrl = ((window.location.hostname === "localhost") ? "proxy" : "") + manifestServiceUrl //serviceConfig.serviceUrl
			+ ((window.location.hostname === "localhost") ? "?sap-client=300" : ""),
			// 

			rootPath = jQuery.sap.getModulePath("gdt.salesui.s4"),

			mainCSSUrl = [rootPath, "css/mainCSS.css"].join("/"),

			printCSSUrl = [rootPath, "css/print.css"].join("/"),

			i18nModel = new sap.ui.model.resource.ResourceModel({
				bundleUrl: [rootPath, "i18n/messageBundle.properties"].join("/")
			}),

			deviceModel = new sap.ui.model.json.JSONModel({
				isTouch: sap.ui.Device.support.touch,
				isNoTouch: !sap.ui.Device.support.touch,
				isPhone: sap.ui.Device.system.phone,
				isNoPhone: !sap.ui.Device.system.phone,
				listMode: (sap.ui.Device.system.phone) ? "None" : "SingleSelectMaster",
				listItemType: (sap.ui.Device.system.phone) ? "Active" : "Inactive"
			}),

			blankDetailLine = new sap.ui.model.json.JSONModel({}),

			rejectionReasons = new sap.ui.model.json.JSONModel({}),

			allCustomers = new sap.ui.model.json.JSONModel({}),

			myCustomers = new sap.ui.model.json.JSONModel({}),

			currentCustomer = new sap.ui.model.json.JSONModel({}),

			closedQuotes = new sap.ui.model.json.JSONModel({}),

			openQuotes = new sap.ui.model.json.JSONModel({}),

			completedQuotes = new sap.ui.model.json.JSONModel({}),

			rejectedSalesOrders = new sap.ui.model.json.JSONModel({}),

			pendingSalesOrders = new sap.ui.model.json.JSONModel({}),

			openSalesOrders = new sap.ui.model.json.JSONModel({}),

			orderTypes = new sap.ui.model.json.JSONModel([]),
			itemCatConfigValues = new sap.ui.model.json.JSONModel([]),
			docItemCatValues = new sap.ui.model.json.JSONModel([]),

			closedSalesOrders = new sap.ui.model.json.JSONModel({}),
			ciscoPunchout = new sap.ui.model.json.JSONModel({}),

			systemInfo = new sap.ui.model.json.JSONModel({}),
			userPref = new sap.ui.model.json.JSONModel({}),
			currencies = new sap.ui.model.json.JSONModel([]),

			currentSalesDocumentAttachments = new sap.ui.model.json.JSONModel({}),
			currentCopySalesDocumentLines = new sap.ui.model.json.JSONModel([]),
			currentSalesDocument = new sap.ui.model.json.JSONModel({}),

			currentSalesDocumentLines = new sap.ui.model.json.JSONModel([]),
			beforeSaveSalesDocumentLines = new sap.ui.model.json.JSONModel([]),

			currentAttachments = new sap.ui.model.json.JSONModel([]),

			copies = new sap.ui.model.json.JSONModel([]),
			invoiceOutputValues = new sap.ui.model.json.JSONModel([]),
			routeOptions = new sap.ui.model.json.JSONModel([]),
			dirOutputValues = new sap.ui.model.json.JSONModel([]),

			documentFlow = new sap.ui.model.json.JSONModel([]),

			soAvailableQty = new sap.ui.model.json.JSONModel([]),
			variantColumns = new sap.ui.model.json.JSONModel([]),

			lineItemVariant = new sap.ui.model.json.JSONModel([]),

			variantFields = new sap.ui.model.json.JSONModel([]),
			//   layoutFields = new sap.ui.model.json.JSONModel(modelLayoutColumnsUrl);
			layoutFields = new sap.ui.model.json.JSONModel([]),
			orgData = new sap.ui.model.json.JSONModel([]),
			ciscoPayload = new sap.ui.model.json.JSONModel([]),
			draft = new sap.ui.model.json.JSONModel([]),

			currentState = new sap.ui.model.json.JSONModel({
				isEditMode: false,
				isNotEditMode: true,
				isQuote: false,
				isSalesOrder: false,
				isPendingSalesOrder: false,
				isSubmittedSalesOrder: false,
				isAttachmentsNeedSave: false,
				canDelete: false,
				canEdit: true,
				isCiscoPunchoutEnable: true
			}),

			currentTotals = new sap.ui.model.json.JSONModel({
				HWRevenue: 0,
				HWCost: 0,
				HWGP: 0,
				HWGPP: 0,
				ServicesRevenue: 0,
				ServicesCost: 0,
				ServicesGP: 0,
				ServicesGPP: 0,
				TotalRevenue: 0,
				TotalCost: 0,
				TotalGP: 0,
				TotalGPP: 0
			}),

			currentCustomerBalances = new sap.ui.model.json.JSONModel({
				Balance: 0,
				OverdueAmt: 0,
				CreditLimit: 0,
				AvailableCredit: 0,
				YTDSales: 0
			}),

			currentTexts = new sap.ui.model.json.JSONModel({
				Description: "",
				Notes: ""
			}),

			currentVia = new sap.ui.model.json.JSONModel({
				ID: "",
				Name: "",
				Street: "XXXXX",
				City: "",
				State: "",
				Zip: "",
				Phone: ""
			}),

			globalSelectItems = new sap.ui.model.json.JSONModel({
				"customerPOTypes": [{
					"Desc": "",
					"Key": ""
				}, {
					"Desc": "EDI",
					"Key": "DFUE"
				}, {
					"Desc": "Oral",
					"Key": "MUEN"
				}, {
					"Desc": "Email",
					"Key": "SCHR"
				}, {
					"Desc": "Telephone",
					"Key": "TELE"
				}],
				"ShippingConditions": [],
				"Vendors": [],
				"Manufacturers": [],
				"MaterialsSet": []

			}),

			customerSelectItems = new sap.ui.model.json.JSONModel({
				"SalesAdmins": [],
				"AccountManagers": [],
				"ShipTos": [],
				"BillTos": [],
				"Payers": [],
				"EndCustomers": []
			});

		//	                    $.sap.log.setLevel($.sap.log.Level.TRACE);
		//	                    $.sap.log.setLevel($.sap.log.Level.INFO);
		//	                    $.sap.log.setLevel($.sap.log.Level.WARNING);
		currentState.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
		globalSelectItems.setDefaultBindingMode("OneWay");
		customerSelectItems.setDefaultBindingMode("OneWay");

		var model = new sap.ui.model.odata.ODataModel(serviceUrl, {
			json: true,
			loadMetadataAsync: false
		});

		model.forceNoCache(true);

		jQuery.sap.includeStyleSheet(printCSSUrl);
		jQuery.sap.includeStyleSheet(mainCSSUrl);

		sap.ui.core.UIComponent.prototype.init.apply(this,
			arguments);

		//** set models
		model.setDefaultBindingMode("TwoWay");
		core.setModel(model);
		deviceModel.setDefaultBindingMode("OneWay");
		core.setModel(deviceModel, "device");
		core.setModel(i18nModel, "i18n");
		core.setModel(rejectionReasons, "rejectionReasons");
		core.setModel(myCustomers, "myCustomers");
		core.setModel(allCustomers, "allCustomers");
		core.setModel(currentCustomer, "currentCustomer");
		core.setModel(openQuotes, "openQuotes");
		core.setModel(completedQuotes, "completedQuotes");
		core.setModel(closedQuotes, "closedQuotes");
		core.setModel(rejectedSalesOrders, "rejectedSalesOrders");
		core.setModel(pendingSalesOrders, "pendingSalesOrders");
		core.setModel(openSalesOrders, "openSalesOrders");
		core.setModel(closedSalesOrders, "closedSalesOrders");
		core.setModel(orderTypes, "orderTypes");
		core.setModel(itemCatConfigValues, "itemCatConfigValues");
		core.setModel(docItemCatValues, "docItemCatValues");
		core.setModel(systemInfo, "systemInfo");
		core.setModel(userPref, "userPref");
		core.setModel(currencies, "currencies");
		core.setModel(currentSalesDocumentAttachments, "currentSalesDocumentAttachments");
		core.setModel(currentCustomerBalances, "currentCustomerBalances");
		core.setModel(currentTexts, "currentTexts");
		core.setModel(currentVia, "currentVia");
		core.setModel(currentSalesDocument, "currentSalesDocument");
		core.setModel(currentSalesDocumentLines, "currentSalesDocumentLines");
		core.setModel(currentCopySalesDocumentLines, "currentCopySalesDocumentLines");
		core.setModel(beforeSaveSalesDocumentLines, "beforeSaveSalesDocumentLines");
		core.setModel(documentFlow, "documentFlow");
		core.setModel(soAvailableQty, "soAvailableQty");
		core.setModel(lineItemVariant, "lineItemVariant");
		core.setModel(layoutFields, "layoutFields");
		core.setModel(variantFields, "variantFields");
		core.setModel(variantColumns, "variantColumns");
		core.setModel(invoiceOutputValues, "invoiceOutputValues");
		core.setModel(routeOptions, "routeOptions");
		core.setModel(dirOutputValues, "dirOutputValues");
		core.setModel(currentAttachments, "currentAttachments");
		core.setModel(copies, "copies");
		core.setModel(currentState, "currentState");
		core.setModel(currentTotals, "currentTotals");
		core.setModel(globalSelectItems, "globalSelectItems");
		core.setModel(customerSelectItems, "customerSelectItems");
		core.setModel(blankDetailLine, "blankDetailLine");
		core.setModel(ciscoPunchout, "ciscoPunchout");
		core.setModel(orgData, "orgData");
		core.setModel(draft, "draft");
		core.setModel(ciscoPayload, "ciscoPayload");

		$.when(gdt.salesui.s4.data.Preloader.init(model)).done(function () {
			that._oRouteMatchedHandler = new sap.m.routing.RouteMatchedHandler(
				that.getRouter());
			that.getRouter().initialize();
		}).fail(function () {
			sap.m.MessageToast.show("Failed to preload data...app could not start");
		});

	},

	createContent: function () {
		//  	alert($('input[name=cxml-urlencoded]').val());
		//   	alert($('input:hidden[name=cxml-urlencoded]').val());
		//   	var sScenario = this.getComponentData( ).startupParameters;  
		var view = sap.ui.view({
				id: "app",
				viewName: "gdt.salesui.s4.view.App",
				type: sap.ui.core.mvc.ViewType.XML,
				viewData: {
					component: this
				}
			}),
			splitApp = view.byId("fioriContent"),
			initialDetail = splitApp.getDetailPages()[0];

		splitApp.setInitialDetail(initialDetail);
		return view;

	}
});