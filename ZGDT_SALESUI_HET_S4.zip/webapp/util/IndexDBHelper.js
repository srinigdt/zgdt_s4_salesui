/* global _:true */
/* global delete:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.util.IndexDBHelper");
$.sap.require("sap.ui.core.Core");

gdt.salesui.s4.util.IndexDBHelper = (function ($, core, _, db) {
	var getdb = function () {

			return $.Deferred(function (defer) {
				window.indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;

				//prefixes of window.IDB objects
				window.IDBTransaction = window.IDBTransaction || window.webkitIDBTransaction || window.msIDBTransaction;
				window.IDBKeyRange = window.IDBKeyRange || window.webkitIDBKeyRange || window.msIDBKeyRange;

				if (!window.indexedDB) {
					window.alert("Your browser doesn't support a stable version of IndexedDB.")
					return false;
				}

				var request = window.indexedDB.open("cisco_response", 1);

				request.onerror = function (event) {
				//	console.log("error: ");
					defer.reject();
				};

				request.onsuccess = function (event) {
					db = request.result;
				//	console.log("success: " + db);
					defer.resolve(db);
				};

				request.onupgradeneeded = function (event) {
					var db = event.target.result;
					/*	        var objectStore = db.createObjectStore("GDTCiscoPayLoad", {keyPath: "id"});
						        for (var i in customerData) {
						                objectStore.add(customerData[i]);      
						        }*/
				};

			}).promise();

		},

		read = function (param) {

			var id = param[param.length - 1];
			var reqType = param[param.length - 3];

			return $.Deferred(function (defer) {
				if (id === null) {
					defer.reject();
					return;
				};

				getdb().done(function (db) {
					if (db === null) {
						return;
					}
					var transaction = db.transaction(["GDTCiscoPayLoad"], "readonly");
					var objectStore = transaction.objectStore("GDTCiscoPayLoad");
					var index = objectStore.index("MessageIndex");
					var request = objectStore.get(parseInt(id));

					request.onerror = function (event) {
						//		console.log("Unable to retrieve data from database!");
						// sap.base.Log.error("Unable to retrieve data from database!");
					};
					request.onsuccess = function (event) {
						// Do something with the request.result!
						if (request.result) {
							//	console.log("Cisco Payload Data found with requested ID:" + id + " Started Parsing Data into required format");
							// sap.base.Log.info("Cisco Payload Data found with requested ID:" + id + " Started Parsing Data into required format");
							defer.resolve(startParseCiscoPayloadData(request.result.punchout_message, id, reqType));

						} else {
							//	console.log("Cisco Payload Data not found with requested ID:" + id);
							// sap.base.Log.error("Cisco Payload Data not found with requested ID:" + id);
						}
					};

				}).fail(function (msg) {
					//	console.log("Unable to find IndexDB");
					// sap.base.Log.error("Unable to find IndexDB");

				});

			}).promise();
		},

		startParseCiscoPayloadData = function (data, payloadReqID, reqType) {
			var JsonObject = JSON.parse(data);
			var payload = {};
			var items = [];
			var partAddLines = [];
			var partContLines = [];
			var itemDetails = [];
			var itemData = JsonObject["ItemIn"];

			if (!Array.isArray(itemData)) {
				itemDetails.push(itemData);

			} else {
				itemDetails = itemData;
			}

			_.each(itemDetails, function (data) {

				//Item Partner Address details
				var partnerAddress = {};
				if (Boolean(data.PartnerAddress)) {
					partAddLines = data.PartnerAddress.Extrinsic;
				}
				_.each(partAddLines, function (partAddLine) {
					partnerAddress[partAddLine["name"]] = Boolean((partAddLine["$t"])) ? (partAddLine["$t"]).toString() : "";
				});

				//Item Partner Contact details		     
				var partnerContact = {};
				if (Boolean(data.PartnerContact)) {
					var partContLines = data.PartnerContact.Extrinsic;
				}
				_.each(partContLines, function (partContLine) {
					partnerContact[partContLine["name"]] = Boolean((partContLine["$t"])) ? (partContLine["$t"]).toString() : "";
				});

				// Main Item details Parsing			 
				var up = data.ItemDetail.UnitPrice.Money["$t"];
				var upAmt = (Boolean(up) ? up : "0").toString().replace(/$/g, "").replace(/,/g, "");
				var stConfig = data.ItemID["SupplierPartAuxiliaryID"].split(";");
				var lpAmt = stConfig[4];

				var st = {
					"RootKey": stConfig[0],
					"ParentKey": stConfig[1],
					"ChildKey": stConfig[2],
					"CCWLineID": ((Boolean(stConfig[0])) ? stConfig[0] : "").toString(), //encodeURIComponent(
					"CCWParentID": ((Boolean(stConfig[1])) ? stConfig[1] : "").toString(),
					"CCWConfigSetID": ((Boolean(stConfig[0])) ? (Boolean(stConfig[1])) ? stConfig[0] + ";" + stConfig[1] : stConfig[0] : "").toString(),
					"QTY": parseInt(Boolean(data.quantity) ? data.quantity : "0").toString().replace(/,/g, ""),
					"UnitOfMeasure": data.ItemDetail["UnitOfMeasure"],
					"UnitPrice": (parseFloat(upAmt) > 0) ? (Math.round(parseFloat(upAmt) * 100.0) / 100.0).toString() : "0.00",
					"ListPrice": (parseFloat(lpAmt) > 0) ? (Math.round(parseFloat(lpAmt) * 100.0) / 100.0).toString() : "0.00",
					"Currency": data.ItemDetail.UnitPrice.Money["currency"],
					"ManufacturerPartID": data.ItemID["SupplierPartID"],
					"Description": data.ItemDetail.Description["$t"].split('|')[0],
				};

				var ifds = data.ItemDetail.Extrinsic; //item further details

				_.each(ifds, function (ifds) {

					switch (ifds["name"]) {
					case "LineNumber":
						st["StructuredLineID"] = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "";
						break;
					case "ListPrice":
						var ListPrice = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "0.00";
						ListPrice = (parseFloat(ListPrice) > 0) ? (Math.round(parseFloat(ListPrice) * 100.0) / 100.0).toString() : "0.00";
						st[ifds["name"]] = ListPrice;
						break;
					case "ExtendedListPrice":
						var ExtendedListPrice = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "0.00";
						ExtendedListPrice = (parseFloat(ExtendedListPrice) > 0) ? (Math.round(parseFloat(ExtendedListPrice) * 100.0) / 100.0).toString() :
							"0.00";
						st["ExtendedListPrice"] = ExtendedListPrice;
						st["ListPrice"] = "0.0";
						break;
						st["ListPrice"] = ExtendedListPrice;
						break;
					case "ExtendedNetPrice":
						var ExtendedCost = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "0.00";
						ExtendedListPrice = (parseFloat(ExtendedCost) > 0) ? (Math.round(parseFloat(ExtendedCost) * 100.0) / 100.0).toString() : "0.00";
						//	st["ExtendedCost"] = ExtendedCost;
						break;
					case "TotalDisc":
						var totalDisc = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "0.00";
						totalDisc = (parseFloat(totalDisc) > 0) ? (Math.round(parseFloat(totalDisc) * 100.0) / 100.0).toString() : "0.00";
						if (reqType === "Q") {
							st["GDTDiscountPercent"] = totalDisc;
						} else {
							st["CustomerDiscountPercent"] = totalDisc;
						}

						break;
					case "ServiceLength":
						st["SmartNetDuration"] = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "";
						break;
					case "LeadTime":
						st["CCWLeadTimeDays"] = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "";
						// {column : "Lead Time (in Days)", field : "CCWLeadTimeDays", converter : function (val) {var amt = val.replace(/,/g, ""); amt = ((!amt || amt === "N/A") ? 0 : parseInt(amt.split(" ")[0])); return ((!amt) ? 0 : amt);}},

						if (st["CCWLeadTimeDays"].toString().toUpperCase() === "N/A") {
							st["CCWLeadTimeDays"] = "";
						}

						break;
					case "QuoteID":
						st["ExternalQuoteID"] = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "";
						// {column : "CCW Quote #", field : "ExternalQuoteID", optional : true},					
						break;
					case "EstimateID":
						st["ExternalQuoteID"] = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "";
						break;
					case "DealID":
						st["DealID"] = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "";
						// 	{column : "Deal ID / DART", field : "DealID", optional : true},					
						break;
					case "BuyMethod":
						st["VendorID"] = Boolean((ifds["$t"])) ? (ifds["$t"]).toString().toUpperCase().replace(/ /g, "") : "";
						//	{column : "Buy Method",  field : "VendorID", lookup : [{from : "Cisco", to : CiscoVdrID}, {from : "INGRAM MICRO", to : IngramVdrID}]},						
						break;
					case "MagicKey":
						st["ciscoMagicKey"] = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "";
						break;
					case "ServiceLevel":
						st["SmartNetServiceLevel"] = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "";

						break;
					case "ServiceType":
						st["SmartNetServiceLevelDescription"] = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "";
						break;
					default:
						st[ifds["name"]] = Boolean((ifds["$t"])) ? (ifds["$t"]).toString() : "";
					}

				});

				// Partner Address and Contact details to line
				st.partnerAddress = partnerAddress;
				st.partnerContact = partnerContact;

				items.push(st);

			});

			var resultItems = items;
			// Create Hierarchy Key/Configuration key(Parent Child relationship)
			/*        var parents = _.filter(items,function(item){ return (item.ParentKey === "0")})	;
			        var children = _.filter(items,function(item){ return (item.ParentKey !== "0")})	;
			        var ParentsNo = parents.length;
			        var pkey = 0;
			        var resultItems = [];
			        if(parents.length > 0){
			        _.each(parents,function(parent){
			        	pkey  = pkey  + 1;
			        	parent.StructuredLineID = pkey + '.0';
			        	resultItems.push(parent);
			        	  var children = _.filter(items,function(item){ return (item.ParentKey === parent.RootKey)})	;
			        	  if(children.length > 0){
			        	  _generateRelation(children,pkey,false,items,resultItems)
			        	  }
			        });	
			        }*/

			payload.Header = {};
			payload.Items = resultItems;
			payload.mappingFields = _getCiscoToSAPmappingFields();
			payload.response = data;
			payload.reqReqID = payloadReqID;

			if (reqType === "Q") {
				delete payload.mappingFields.CustomerDiscountPercent;
			} else {
				delete payload.mappingFields.GDTDiscountPercent;
			}

			return payload;
		},

		_generateRelation = function (children, pkey, addzero, items, result) {
			var ckey = 0;

			_.each(children, function (child) {
				ckey = ckey + 1;
				if (addzero) {
					child.StructuredLineID = pkey + ".0." + ckey;
				} else {
					child.StructuredLineID = pkey + "." + ckey;
				}

				result.push(child);

				var children = _.filter(items, function (item) {
					return (item.ParentKey === child.RootKey && item.ChildKey === "");
				});
				if (children.length > 0) {
					_generateRelation(children, child.StructuredLineID, true, items, result);
				}

				var children = _.filter(items, function (item) {
					return (item.ParentKey === child.RootKey && item.ChildKey !== "");
				});
				if (children.length > 0) {
					_generateRelation(children, child.StructuredLineID, false, items, result);
				}

			});

		},

		_getCiscoToSAPmappingFields = function () {
			var mappingFields = {
				"ExternalQuoteID": "QuoteID",
				// "LeadTime":"LeadTime", 
				"VendorID": "BuyMethod",
				"UnitPrice": "UnitPrice",
				// "ListPrice":"ListPrice",
				"ExtendedListPrice": "ExtendedListPrice",
				"UnitOfMeasure": "UnitOfMeasure",
				"ManufacturerPartID": "ManufacturerPartID",
				"Description": "Description",
				"QTY": "QTY",
				"GDTDiscount": "GDTDiscount",
				"CustomerDiscount": "CustomerDiscount",
				"StructuredLineID": "StructuredLineID",
				"GDTDiscountPercent": "GDTDiscountPercent",
				"CustomerDiscountPercent": "CustomerDiscountPercent",
				"CCWParentID": "CCWParentID",
				"CCWLineID": "CCWLineID",
				"CCWConfigSetID": "CCWConfigSetID",
				"CCWLeadTimeDays": "CCWLeadTimeDays",
				"DealID": "DealID",
				"ciscoMagicKey": "ciscoMagicKey",
				// "ExtendedCost":"ExtendedCost",
				// "ExtendedPrice":"ExtendedPrice",
				"SmartNetDuration": "SmartNetDuration",
				"SmartNetServiceLevelDescription": "SmartNetServiceLevelDescription",
				"SmartNetServiceLevel": "SmartNetServiceLevel"
					/* , "Kdmat":"",
				 "Dsb":"", 			
				 "EdiMfrpn":"", 
				 "TaxAmount":"", 
				 "ZZLineID":"", 
				 "Action":"", 
				 "WBSElement":"", 	  
				 "UnitCost":"", 
				 "StructuredLineID":"", 
				 "SmartNetServiceLevelDescription":"", 
				 "SmartNetServiceLevel":"", 
				 "SmartNetReplacedSerialNumber":"", 
				 "SmartNetLineType":"", 
				 "SmartNetInstanceNumber":"", 
				 "SmartNetEndDate":"", 
				 "SmartNetDuration":"", 
				 "SmartNetCoveredSerialNumber":"", 
				 "SmartNetCoveredMaterial":"", 
				 "SmartNetContractNumber":"", 
				 "SmartNetBeginDate":"", 
				 "ShipToID":"", 
				 "ShipToAttn":"", 
				 "SearchTerm":"", 
				 "ScaleQTY":"", 
				 "SalesDocumentLineID":"", 
				 "SalesDocumentID":"", 
				 "ReferenceDocumentID":"", 
				 "ReferenceDocumentCategory":"", 
				 "ReferenceDocLineID":"", 
				 "QtyShipped":"", 
				 "QtyReceived":"", 
				 "QtyOrdered":"", 
				 "QtyBilled":"", 			
				 "ParentLineID":"", 
				 "OTSTZip":"", 
				 "OTSTStreet3":"", 
				 "OTSTStreet2":"", 
				 "OTSTStreet":"", 
				 "OTSTState":"", 
				 "OTSTPhone":"", 
				 "OTSTName":"", 
				 "OTSTCountry":"", 
				 "OTSTCity":"", 
				 "OTSTAddressID":"", 
				 "OriginatingDocLineID":"", 
				 "OrginatingDocumentID":"", 
				 "MaterialID":"", 
				 "MaterialGroup":"", 
				 "MARAMaterialGroup":"", 
			
				 "ManufacturerID":"", 
				 "LongDescription":"", 
				 "ItemCategory":"", 
				 "GrossProfitPercentage":"", 
				 "GrossProfit":"", 
				 "GDTDiscount":"", 			 
				 "ExtendedPrice":"", 
				 "ExtendedCost":"", 
				 "EDelivery":"", 			 
				 "DeliveryDate":"", 
			
				 "CustomerPOLineID":"", 
				 "CustomerPOID":"", 
				 "CustomerPartID":"", 
				 "CustomerMaterialID":"", 
				 "CustomerDiscountPercent":"", 
				 "CustomerDiscount":"", 
				 "ConditionLineID":"", 
				 "CCWOther":"", 
				 "BillingNotes":"", 
				 "BillingBlock":"", 
				 "SMARTAcctNo":"", 
				 "CustomerContractWithVendor":"", 
				 "SalesDocument":""		*/
			};

			return mappingFields;

		},

		readAll = function () {
			var objectStore = db.transaction("GDTCiscoPayLoad").objectStore("GDTCiscoPayLoad");

			objectStore.openCursor().onsuccess = function (event) {
				var cursor = event.target.result;
				if (cursor) {
					//	console.log("Name for id " + cursor.key + " is " + cursor.value.name + ", Age: " + cursor.value.age + ", Email: " + cursor.value.email);
					// sap.base.Log.error("Name for id " + cursor.key + " is " + cursor.value.name + ", Age: " + cursor.value.age + ", Email: " + cursor.value.email);
					//    cursor.continue();
				} else {
					// sap.base.Log.error("No more entries!");
					//	console.log("No more entries!");
				}
			};
		},

		add = function () {
			/*	        var request = db.transaction(["GDTCiscoPayLoad"], "readwrite").objectStore("GDTCiscoPayLoad").add({ id: "00-03", name: "Kenny", age: 19, email: "kenny@planet.org" });
				                                 
				        request.onsuccess = function(event) {
				        	console.log("Kenny has been added to your database.");
				        };
				         
				        request.onerror = function(event) {
				        	console.log("Unable to add data\r\nKenny is aready exist in your database! ");       
				        }
				         */
		},

		remove = function (id) {

			var tx = db.transaction(["GDTCiscoPayLoad"], "readwrite"),
				req = tx.objectStore("GDTCiscoPayLoad").delete(parseInt(id));
			req.onsuccess = function (event) {
				//	console.log("Record with Key - " + id + " has been deleted from Index database.");
				// sap.base.Log.info("Record with Key - " + id + " has been deleted from Index database.");
				clearData();
			};

			req.onerror = function (event) {
				clearData();
			};

		},

		clearData = function () {
			// open a read/write db transaction, ready for clearing the data
			var tx = db.transaction(["GDTCiscoPayLoad"], "readwrite");

			// report on the success of the transaction completing, when everything is done
			tx.oncomplete = function (event) {
				//	console.log("Transaction Successfully to clear Index database Data");
				// sap.base.Log.info("Transaction Successfully to clear Index database Data");
			};

			tx.onerror = function (event) {
				//	console.log("Transaction failed to clear Index database Data");
				// sap.base.Log.info("Transaction failed to clear Index database Data");
			};

			// create an object store on the transaction
			var objectStore = tx.objectStore("GDTCiscoPayLoad");

			// Make a request to clear all the data out of the object store
			var objectStoreRequest = objectStore.clear();

			objectStoreRequest.onsuccess = function (event) {
				// report the success of our request
				//	console.log("successfully Cleared Data from Object Store: GDTCiscoPayLoad");
				// sap.base.Log.info("successfully Cleared Data from Object Store: GDTCiscoPayLoad");
			};
		};

	return {
		read: read,
		remove: remove
	};

})($, sap.ui.getCore(), _);