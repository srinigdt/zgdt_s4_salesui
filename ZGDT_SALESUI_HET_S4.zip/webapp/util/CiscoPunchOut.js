/* global _:true */
/* global gdt:true */
// ==UserScript==
// @name        window.close demo
// @include     http://YOUR_SERVER.COM/YOUR_PATH/*
// @grant       window.close
// ==/UserScript==

$.sap.declare("gdt.salesui.s4.util.CiscoPunchOut");
$.sap.require("sap.ui.core.Core");
$.sap.require("sap.m.MessageBox");
$.sap.require("gdt.salesui.s4.util.SAPGatewayHelper");

gdt.salesui.s4.util.CiscoPunchOut = (function ($, core, _, messageBox, helper) {
	var reqPocUrl = "https://api.gdt.com:44302/b2b/pncout-wxysdbx/reqUp"; //"https://clearview.test.gdt.com/cisco/"; //"https://wsgx.cisco.com/b2b/pncout-wxysdbx/reqUp"; 
	//   reqPocUrl = "https://wsgx.cisco.com/b2b/pncout-wxysdbx/reqUp";
	reqPocUrl = "https://clearview.test.gdt.com/cisco/";
	//    reqPocUrl = "https://wsgx.cisco.com/b2b/pncout-wxysdbx/reqUp";
	//   reqPocUrl = "https://u2hc4p-poeprod.cloudapps.cisco.com/poe/tnxshop/cXMLPunchOut?AR=Y";
	reqPocUrl = "https://api.gdt.com:44302/poe/tnxshop/cXMLPunchOut?AR=Y";
	var reqProdUrl = "https://wsgx.cisco.com/b2b/pncout/reqUp";
	reqProdUrl = "https://u2hc4p.cloudapps.cisco.com/eb2b/tnxshop/cXMLPunchOut?AR=Y";
	var supplierUrl = " ";
	var reqUrl = reqPocUrl;
	var systemInfo = core.getModel("systemInfo").getData();
	//   reqUrl = reqProdUrl;
	var prepareCXMLDoc = function (credentials, vc, poutReqid) {
			var reqid;
			if (Boolean(poutReqid)) {
				reqid = poutReqid;
			} else {
				reqid = Math.floor(Math.random() * 9000000000) + 1000000000;
			}

			_createXMLDocAndSend(reqid, credentials, vc);

		},

		_createXMLDocAndSend = function (reqKey, credentials, vc) {
			var randStr = Math.floor(Math.random() * 20);
			var cXMLString = genXMLDoc("1.0", randStr, reqKey, credentials);
			var parser = new DOMParser();
			var xmlDoc = parser.parseFromString(cXMLString, "application/xml");
			var jQueryxmlDoc = jQuery.parseXML(cXMLString);

			var serializer = new XMLSerializer();
			var xmlString = serializer.serializeToString(xmlDoc);

			if (true) {
				vc.busyDlg.setText("Request Sent. Please wait... Once Response is received, will navigate to Cisco Commerce Website");
				vc.busyDlg.open();
				var model = core.getModel();
				model.callFunction("/ExecuteAction", "POST", {
						ActionType: "CiscoPunchOutInitiate",
						Value1: getCurrentWindowURL(reqKey),
						Value2: "BasicAuthentication",
						Value3: vc._reqType
					}, null,
					function (data, response) { //success
						vc.busyDlg.close();
						if (response.statusCode >= 200 && response.statusCode <= 299) {
							window.open(data.ExecuteAction.Value5, "_self");
						} else {
							//	defer.reject();
						}
					},
					function (data) { //error
						vc.busyDlg.close();
						messageBox.show(helper.ParseError(data, "SalesUI Unable Perform Cisco Punchout."), {
							icon: messageBox.Icon.ERROR,
							title: "Cisco Punchout Error Occured",
							actions: messageBox.Action.OK,
							onClose: null
						});
					},
					true // Async
				);

			}

		},

		launchCCWPage = function (URL) {
			window.open(URL, "_self");
			return;
			window.open(URL);

			// Closing Parent Window	    
			var win = window.open("about:blank", "_self");
			win.close();
			setTimeout(function () {
				win.close();
			}, 1000);

		},

		loadDoc = function () {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function () {

				if (this.readyState == 4 && this.status == 200) {
					var responseText = this.responseText;
					var responseXML = this.responseXML;
					//	alert(responseXML);
				}
			};

		},

		parseResponse = function (response) {
			if (response.status >= 200 && response.status <= 299) {
				readIncomingcXMLResponse(response.responseXML);
			} else {
				parseError(response);
			}

		},

		parseError = function (response) {
			var errorCode;
			var responseXmlDocument = response.responseXML;
			var errorCode = $(responseXmlDocument).find("faultcode").getEncodedText(),
				errorCode = (errorCode === "") ? response.status : errorCode,
				msg = "Error Code :" + errorCode + "-" + response.statusText + "\n";
			msg += ($(responseXmlDocument).find("faultstring").getEncodedText() === "") ? response.responseText : $(responseXmlDocument).find(
				"faultstring").getEncodedText();

			if (errorCode === "403") {
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Authentication Error",
					actions: sap.m.MessageBox.Action.OK,
					onClose: null
				});
			} else {
				sap.m.MessageBox.show(msg, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error Occured",
					actions: sap.m.MessageBox.Action.OK,
					onClose: null
				});
			}

		},

		elementValue = function (xml, elem) {
			var begidx;
			var endidx;
			var retStr;
			begidx = xml.indexOf(elem);
			if (begidx > 0) {
				endidx = xml.indexOf("</", begidx);
				if (endidx > 0) {
					retStr = xml.slice(begidx + elem.length, endidx);
				}
				return retStr;
			}
			return null;
		},

		twoChar = function (str) {
			var retStr;
			str = str.toString();
			if (str.length === 1) {
				retStr = "0" + str;
			} else {
				retStr = str;
			}
			return retStr;

		},

		readIncomingcXMLResponse = function (xmlDoc) {
			if (typeof xmlDoc === Object) {
				var serializer = new XMLSerializer();
				var xmlString = serializer.serializeToString(xmlDoc);
			} else if (typeof xmlDoc === "string") {
				xmlString = xmlDoc;
			}
			var ciscoEndPointURL = elementValue(xmlString, "<URL>");
			if (Boolean(ciscoEndPointURL)) {
				launchCCWPage(ciscoEndPointURL);
			} else {
				var messsage = elementValue(xmlString, ">");
				messageBox.show(messsage, {
					icon: messageBox.Icon.ERROR, // default
					title: "Cisco Punchout Response" // default
				});
			}
		},

		timestamp = function (dt) {
			var str;
			var milli;

			str = dt.getFullYear() + "-" + twoChar(1 + dt.getMonth()) + "-";
			str += twoChar(dt.getDate()) + "T" + twoChar(dt.getHours()) + ":";
			str += twoChar(dt.getMinutes()) + ":" + twoChar(dt.getSeconds()) + ".";
			milli = dt.getMilliseconds();
			milli = milli.toString();
			if (3 == milli.length) {
				str += milli;
			} else {
				str += "0" + twoChar(milli);
			}
			str += "-08:00";
			return str;
		},

		//Get querystring value
		getParameterByName = function (url, name) {
			name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
			var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
				search = url || location.search,
				results = regex.exec(search);
			return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
		},

		//Add or modify querystring
		changeParam = function (url, key, value) {
			//Get query string value
			var urlValue = "";
			var searchUrl = url || location.search;
			if (searchUrl.indexOf("?") == "-1") {
				// urlValue='?'+key+'='+value;
				urlValue = searchUrl.replace("?", "?" + key + "=" + value);
				if (urlValue == searchUrl) {
					urlValue = searchUrl + "?" + key + "=" + value;

				}
			} else {
				//Check for key in query string, if not present
				if (searchUrl.indexOf(key) == "-1") {
					urlValue = searchUrl + '&' + key + '=' + value;
				} else { //If key present in query string
					var oldValue = getParameterByName(url, key);
					if (searchUrl.indexOf("?" + key + "=") != "-1") {
						urlValue = searchUrl.replace("?" + key + "=" + oldValue, "?" + key + "=" + value);
					} else {
						urlValue = searchUrl.replace("&" + key + "=" + oldValue, "&" + key + "=" + value);
					}
				}
				//history.pushState({state:1, rand: Math.random()}, '', urlValue);
				//history.pushState function is used to add history state.
				//It takes three parameters: a state object, a title (which is currently ignored), and (optionally) a URL.
			}

			return urlValue;

		},

		removeParam = function (key, sourceURL) {
			var rtn = sourceURL.split("?")[0],
				param,
				params_arr = [],
				queryString = (sourceURL.indexOf("?") !== -1) ? sourceURL.split("?")[1] : "";
			if (queryString !== "") {
				params_arr = queryString.split("&");
				for (var i = params_arr.length - 1; i >= 0; i -= 1) {
					param = params_arr[i].split("=")[0];
					if (param === key) {
						params_arr.splice(i, 1);
					}
				}
				rtn = rtn + "?" + params_arr.join("&");
			}
			return rtn;
		},

		getCurrentWindowURL = function (reqKey) {
			var currentURL = window.location.href;
			var orgin = window.location.origin;
			var replaceOrgin = systemInfo.ExtWdOrigin;
			currentURL = currentURL.replace(orgin, replaceOrgin);
			return encodeURIComponent(currentURL + "/indexDBidEq" + reqKey);
			//var currentWindowURL =  changeParam(window.location.href,"cxml-urlencoded",'ID12345');
			//var currentWindowURL = removeParam("cxml-urlencoded",window.location.href) ;
			//		var currentWindowURL = window.location.href;
			//		var splitURL = currentWindowURL.split(/&/);
			//		currentWindowURL ="";
			//		_.each(splitURL,function(literal){(currentWindowURL === "")? currentWindowURL = literal: currentWindowURL = currentWindowURL  + "&amp;" + literal;  });
			//		return encodeURI( currentWindowURL );  //encodeURI(uri)
		},

		genXMLDoc = function (cXMLvers, randStr, reqKey, credentials) {
			var dt;
			var str;
			var vers, sysID;
			var nowNum, timeStr;
			var ciscoUserID = Boolean(credentials) ? credentials.CiscoUserId : "",
				ciscoPw = Boolean(credentials) ? credentials.CiscoPw : "";
			var buyerCookie = "";
			var formPostURL = systemInfo.CiscoFormPostURLsMask;
			vers = "1.2.014";
			sysID = "http://xml.cXML.org/schemas/cXML/" + vers + "/cXML.dtd";
			dt = new Date();
			nowNum = dt.getTime();
			timeStr = timestamp(dt);
			str = '<?xml version="1.0" encoding="UTF-8"?>';
			str += '<!DOCTYPE cXML SYSTEM "' + sysID + '">';
			str += '<cXML payloadID="' + nowNum + ".";
			str += randStr + '@gdt.com';
			str += '" timestamp="' + timeStr + '" version="1.2.014"  xml:lang="en-US">';
			str += '<Header>';
			str += '<From>';
			str += '<Credential domain="">';
			//		str += '<Credential domain="">';
			str += '<Identity></Identity>';
			str += '</Credential>';
			//	str += '<To>';
			//	str += '<Credential domain="">';
			//	str += '<Identity></Identity>';
			//	str += '</Credential>';
			//	str += '</To>';
			str += '</From>';
			str += '</Header>';
			str += '<Request deploymentMode="test">';
			str += '<PunchOutSetupRequest operation="create">';
			str += '<BuyerCookie>' + buyerCookie + '</BuyerCookie>';
			str += '<Extrinsic name="Function"></Extrinsic>';
			str += '<BrowserFormPost>';
			str += '<URL>' + formPostURL + '</URL>'; //  reqUrl  supplierUrl
			str += '</BrowserFormPost>';
			str += '<SupplierSetup>';
			str += '<URL>' + formPostURL + '</URL>'; // supplierUrl // reqUrl
			str += '</SupplierSetup>';
			str += '</PunchOutSetupRequest>';
			str += '</Request>';
			str += '</cXML>';

			return str;
		};

	return {
		prepareCXMLDoc: prepareCXMLDoc
	};

})($, sap.ui.getCore(), _, sap.m.MessageBox, gdt.salesui.s4.util.SAPGatewayHelper);