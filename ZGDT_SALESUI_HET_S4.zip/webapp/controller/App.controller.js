/* global _:true */
/* global gdt:true */
sap.ui.controller("gdt.salesui.s4.controller.App", {});