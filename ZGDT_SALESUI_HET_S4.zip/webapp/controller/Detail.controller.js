/* global _:true */
/* global gdt:true */
//$.sap.require("gdt.salesui.s4.lib.underscoreMin");
$.sap.require("gdt.salesui.s4.lib.jqueryScrollToMin");
$.sap.require("gdt.salesui.s4.lib.jqueryVisibleMin");
sap.ui.define([
	"gdt/salesui/s4/util/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"sap/ui/core/Core",
	"gdt/salesui/s4/data/DataContext",
	"gdt/salesui/s4/data/DataImporter",
	"gdt/salesui/s4/data/DataImporterCiscoPayload",
	"gdt/salesui/s4/util/AddressHelper",
	"gdt/salesui/s4/util/Formatter",
	"gdt/salesui/s4/util/Sharepoint",
	"gdt/salesui/s4/util/CiscoPunchOut",
	"gdt/salesui/s4/util/VariantHandler",
	"gdt/salesui/s4/vm/SalesDocumentDetail",
	"gdt/salesui/s4/data/DataLoader",
	"gdt/salesui/s4/util/IndexDBHelper",
	"sap/ui/model/Filter"

], function (Controller,
	MessageBox,
	MessageToast,
	Export,
	ExportTypeCSV,
	core,
	datacontext,
	importer,
	importerCiscoPayload,
	addressHelper,
	formatter,
	sharepoint,
	ciscoPunchOut,
	variantHandler,
	detailsvm,
	dataLoader,
	indexdbhelper,
	Filter,
	vc
) {
	"use strict";

	return Controller.extend("gdt.salesui.s4.controller.Detail", {

		onInit: function () {
			vc = this;
			vc.copies = core.getModel("copies");
			vc.materialSeriesFinishedGoods = 1;
			vc.materialSeriePlaceHolder = 2;
			vc.materialSeriesHardware = 3;
			vc.materialSerieProfessionalServices = 4;
			vc.currentTab = null;
			vc.view = null;
			vc.page = null;
			vc.busyDlg = null;
			vc.splitApp = sap.ui.getCore().byId("app").byId("fioriContent");
			vc.componentId = null;
			vc.eventBus = null;
			vc.router = null;
			vc.currentCustomerID = "";
			vc.currentSalesDocumentID = "";
			vc.orgData = "";
			vc.forceRefresh = false;
			vc.startupMsg = null;
			vc.firstTime = true;

			var table = null,
				oldTableOnAfterRendering = null,
				currentState = core.getModel("currentState");

			vc.view = vc.getView();
			vc.view.setModel(core.getModel("soAvailableQty"), "soAvailableQty");
			vc.view.setModel(core.getModel("lineItemVariant"), "lineItemVariant");
			vc.view.setModel(new sap.ui.model.json.JSONModel(_.clone(core.getModel("layoutFields"))), "layoutFields");
			vc.view.setModel(core.getModel("variantFields"), "variantFields");
			vc.view.setModel(core.getModel("invoiceOutputValues"), "invoiceOutputValues");
			vc.view.setModel(core.getModel("dirOutputValues"), "dirOutputValues");
			vc.view.setModel(core.getModel("orderTypes"), "orderTypes");
			vc.view.setModel(core.getModel("currentCopySalesDocumentLines"), "currentCopySalesDocumentLines");
			vc.view.setModel(core.getModel("routeOptions"), "routeOptions");
			vc.view.setModel(core.getModel("userPref"), "userPref");
			vc.view.setModel(core.getModel("systemInfo"), "systemInfo");
			vc.view.setModel(core.getModel("ciscoPunchout"), "ciscoPunchout");
			vc.view.setModel(core.getModel("draft"), "draft");
			vc.busyDlg = vc.view.byId("busyDlg");
			vc.componentId = sap.ui.core.Component.getOwnerIdFor(vc.view);
			vc.eventBus = sap.ui.component(vc.componentId).getEventBus();
			vc.router = vc.getRouter();
			vc.page = vc.view.byId("detailPage");
			table = vc.view.byId("lineItemsTable");
			variantHandler.initialize_variant(vc.view, vc);
			oldTableOnAfterRendering = table.onAfterRendering;

			table.onAfterRendering = function () {
				var tmpResult = oldTableOnAfterRendering.apply(this, arguments);

				if (typeof vc.onAfterTableOnAfterRendering === "function") {
					vc.onAfterTableOnAfterRendering.apply(this, arguments);
				}

				return tmpResult;
			};
			vc.view.setModel(currentState, "currentState");
			vc.view.setModel(core.getModel("device"), "device");
			vc.view.setModel(core.getModel("globalSelectItems"), "globalSelectItems");
			vc._attachValidationHandlers();
			vc.view.setModel(core.getModel("i18n"), "i18n");

			//vc.view.setModel(currentState,"currentState");
			if (window.location.hostname === "api.gdt.com") {
				core.getModel("currentState").setProperty("/isCiscoPunchoutEnable", true);
			} else {
				core.getModel("currentState").setProperty("/isCiscoPunchoutEnable", false);
			}

			if (sap.ui.version < "1.38") {
				table._oVSb.attachScroll(_.debounce(vc._calculateTotals, 50), table);
			}
			$(document).on("paste", "td", vc.handlePaste);
			$(document).on("keydown", "td", vc.handleTableKeyDown);
			$(document).on(
				"dragover",
				function (e) {
					e.preventDefault();
					e.stopPropagation();
				}
			);
			$(document).on(
				"dragenter",
				function (e) {
					e.preventDefault();
					e.stopPropagation();
				}
			);
			$(document).on("drop", "#" + vc.view.byId("detailPage").getId(), vc.handleDropFile);

			sap.ui.core.UIComponent.getRouterFor(vc).attachRouteMatched(vc._onRouteMatched, vc);

			/*           if(document.referrer.indexOf("cisco_punchout") > 0){
			        	 vc.busyDlg.setText("Please wait.. Reading Cisco Quote/Estimate from request"); 
						 vc.busyDlg.open(); 
			            jQuery.sap.delayedCall(500, this, function () {			
			            	  this._check_ciscoPayload( );
						});
			           };*/

		},

		_check_ciscoPayload: function (evt) {

			/*      	indexdbhelper.read("9093370055").done( function( payload1){
			      		vc.busyDlg.setText("Now Validating Cisco Data with SAP.");
			      		vc._doImportPayloadData(payload1 ,false);	
			      	                              }).fail(function(msg){
			      		console.log("Unable read IndexDB Data");
			      		vc.busyDlg.close();
			     			});
			     			 	return;*/

			var urlParts = [];
			var fxn;
			urlParts = window.location.href.split("/indexDBidEq");
			if (urlParts.length > 1) {
				vc.busyDlg.setText("Now Validating Cisco Data with SAP.");
				vc.busyDlg.open();
				window.location.replace(urlParts[0] || window.location.href);
				urlParts = urlParts[1].split("f");
				if (Boolean(urlParts) && (urlParts[urlParts.length - 1] !== null)) {
					vc.busyDlg.setText("Please wait.. Retrieving Data from Cisco");
					vc.busyDlg.open();
					vc._checkDraft(urlParts); // Check any unsaved records/Draft records and append to existing order
					indexdbhelper.read(urlParts).done(function (payload) {
						vc.busyDlg.setText("Now Validating Cisco Data with SAP.");
						vc.busyDlg.open();
						var vdrs = core.getModel("globalSelectItems").getProperty("/Vendors") || [];
						var userData = core.getModel("userPref").getData();
						if (vdrs.length === 0) {
							var model = core.getModel();
							model.read("/ManufacturerSet?$filter=Vkorg eq '" + userData.Vkorg + "'", {
								success: function (data) {
									var globalSelectItems = core.getModel("globalSelectItems"),
										mfrs = null,
										vdrs = null;

									data.results.unshift({
										ManufacturerID: "",
										ManufacturerName: ""
									});
									mfrs = _.filter(_.reject(data.results, {
										ManufacturerName: "Alt Payee"
									}), {
										KTOKK: "MNFR"
									});
									vdrs = _.filter(_.reject(data.results, {
										ManufacturerName: "Alt Payee"
									}), {
										KTOKK: "YB01"
									});
									globalSelectItems.setProperty("/Manufacturers", mfrs);
									globalSelectItems.setProperty("/Vendors", vdrs);

									if (urlParts[urlParts.length - 2] === "a") {
										vc._doImportPayloadData(payload, true);
									} else {
										vc._doImportPayloadData(payload, false);
									};

								},
								error: function () {
									vc.busyDlg.close();
								}
							});

						} else {

							if (urlParts[urlParts.length - 2] === "a") {
								vc._doImportPayloadData(payload, true);
							} else {
								vc._doImportPayloadData(payload, false);
							};
						}
						indexdbhelper.remove(urlParts[urlParts.length - 1]);
					}).fail(function (msg) {
						//	console.log("Unable read IndexDB Data");
						vc.busyDlg.close();
						indexdbhelper.remove(urlParts[urlParts.length - 1]);
					});

				};
			}
		},
		_checkDraft: function (param) {
			if (param[param.length - 2] === "a") {
				var draftData = _.filter(core.getModel("draft").getData(), function (data) {
					return data.Reqid === param[param.length - 1];
				});
				if (draftData.length > 0) {
					var draftrecord = draftData[0];
					var salesLineDraftItems = JSON.parse(draftrecord.IDraft);
					var payloadDraft = JSON.parse(draftrecord.PDraft);
					draftrecord.PunchoutTime = (draftrecord.PunchoutTime) ? new Date(draftrecord.PunchoutTime) : null;
					if (salesLineDraftItems.length > 0) {
						var currentLineItemsModel = (Boolean(vc.view.getModel("currentSalesDocumentLines"))) ? vc.view.getModel(
							"currentSalesDocumentLines") : core.getModel("currentSalesDocumentLines");
						var currentLineItemsData = _.reject(currentLineItemsModel.getData(), function (line) {
							return !line.MaterialID;
						});

						_.each(currentLineItemsData, function (line) {
							salesLineDraftItems = _.reject(salesLineDraftItems, {
								SalesDocumentLineID: line.SalesDocumentLineID
							});
						});

						_.each(salesLineDraftItems, function (data) {
							data.SmartNetEndDate = (data.SmartNetEndDate) ? new Date(data.SmartNetEndDate) : null;
							data.SmartNetBeginDate = (data.SmartNetBeginDate) ? new Date(data.SmartNetBeginDate) : null;
							data.LastUpdatedOn = (data.LastUpdatedOn) ? new Date(data.LastUpdatedOn) : null;
							data.DeliveryDate = (data.DeliveryDate) ? new Date(data.DeliveryDate) : null;
							data.CreatedOn = (data.CreatedOn) ? new Date(data.CreatedOn) : null;
						});

						Array.prototype.push.apply(currentLineItemsData, salesLineDraftItems);
						currentLineItemsModel.setData(currentLineItemsData);
					}

					if (payloadDraft.length > 0) {

						_.each(payloadDraft, function (data) {
							data.PunchoutTime = (draftrecord.PunchoutTime) ? draftrecord.PunchoutTime : (data.PunchoutTime) ? new Date(data.PunchoutTime) :
								null;
						});

						core.getModel("ciscoPayload").setData(payloadDraft);
					}

				}
			}
		},

		_doImportPayloadData: function (data, append) {

			var errors = [],
				missingAddresses = [];

			//	if (!vc.view.getModel("currentState").getProperty("/isEditMode")){ vc._toggleEdit(true);}
			//view.getModel('currentSalesDocumentLines').setData([]);
			var currentSalesDocument = (Boolean(vc.view.getModel("currentSalesDocument"))) ? vc.view.getModel("currentSalesDocument") : core.getModel(
					"currentSalesDocument"),
				currentSalesDocumentLines = (Boolean(vc.view.getModel("currentSalesDocumentLines"))) ? vc.view.getModel(
					"currentSalesDocumentLines") : core.getModel("currentSalesDocumentLines");
			vc.busyDlg.setText("Please wait.. Validating and Rendering Data");
			vc.busyDlg.open();
			if (!core.getModel("currentState").getProperty("/isEditMode")) {
				vc._toggleEdit(true);
			}
			importerCiscoPayload.ImportFromCiscoPayLoad(data, currentSalesDocument,
					currentSalesDocumentLines, errors, missingAddresses,
					vc._createNewLine, vc._lookupPartID, vc._determineItemCategoryForDropShip, append)
				.fail(function (msg) {
					vc.busyDlg.close();
					MessageBox.show(msg, {
						icon: MessageBox.Icon.ERROR,
						title: "Import Error",
						actions: MessageBox.Action.OK
					});
				})
				.always(function () {
					vc.busyDlg.open();
					vc.busyDlg.setText("Please wait.. Almost done");
					jQuery.sap.delayedCall(200, this, function () {
						vc.busyDlg.close();
					});

					if (errors && errors.length !== 0) {
						vc._presentImportErrors(errors);
					} else {
						if (missingAddresses && missingAddresses.length !== 0) {
							vc._presentAddressErrors(missingAddresses);
						} else {
							vc._calculateTotals();
						}
					}
				});

			/*						vc.busyDlg.setText("Attempting to import file.");
									vc.busyDlg.open();*/

		},

		_onRouteMatched: function (evt) {
			if (evt.getParameter("name") === "detail") {
				var args = evt.getParameter("arguments"),
					iconTabBar = vc.view.byId("iconTabBar"),
					salesDocumentID = args.salesDocId;

				vc.orgData = args.orgData;
				vc.currentTab = args.tab || "lineItems";

				if (vc.currentCustomerID !== args.customerId) {
					vc.currentCustomerID = args.customerId;
					vc._setCustShippingConditions(vc.currentCustomerID);
				}

				vc.currentCustomerID = args.customerId;
				vc.docType = args.docType;

				//page.addStyleClass("sapUiSizeCompact");

				if (!!salesDocumentID && parseInt(salesDocumentID) !== 0) {
					vc.busyDlg.setText("Fetching document " + salesDocumentID + " from SAP.");
				} else {
					vc.busyDlg.setText("Please Wait.");
				}
				if (vc.currentTab === "attachments") {
					vc.busyDlg.setText("Checking with SharePoint.");
				}
				//Begin of Change:Added by SXVASAMSETTI												
				if (vc.currentTab === "docflow") {
					var documentID = core.getModel("currentSalesDocument").getProperty("/ReferencedBy") || salesDocumentID;
					vc.busyDlg.setText("Fetching related documents to document(" + documentID + ") from SAP.");
				}

				if (vc.currentTab === "soAvailableQty") {
					vc.busyDlg.setText("Fetching Sales Order Available Qty details for the document(" + salesDocumentID + ") from SAP.");
				}

				//end of Changed		                        //End of Change							
				vc.busyDlg.open();

				if (Boolean(core.getModel("currentState").getProperty("/forceRefresh"))) {
					core.getModel("currentState").setProperty("/forceRefresh", false);
					vc.forceRefresh = true;
				}

				setTimeout(function () {
					vc._refreshSalesDocumentFromServer(salesDocumentID, vc.forceRefresh, vc.docType).done(function () {
						if (iconTabBar && (iconTabBar.getSelectedKey() !== vc.currentTab)) {
							iconTabBar.setSelectedKey(vc.currentTab);
						}

						if (vc.firstTime) {
							vc.firstTime = false;
							if (document.referrer.indexOf("cisco_punchout") > 0) {
								vc.busyDlg.setText("Please wait.. Reading Cisco Quote/Estimate from request");
								vc.busyDlg.open();
								jQuery.sap.delayedCall(1, vc, function () {
									this._check_ciscoPayload();
								});
							};
						}

						if (vc.currentTab === "attachments") {
							vc._refreshAttachments().always(function () {
								vc.busyDlg.close();

								if (vc.startupMsg) {
									sap.m.MessageToast.show(vc.startupMsg);

									vc.startupMsg = null;
								}
							});
						}
						//Begin of Change:Added by SXVASAMSETTI		                         
						else if (vc.currentTab === "docflow") {

							vc._getDocumentFlowFromSAP(core.getModel("currentSalesDocument").getProperty("/ReferencedBy") || salesDocumentID, true).always(
								function () {
									vc.busyDlg.close();
								});

						} else if (vc.currentTab === "soAvailableQty" && parseInt(vc.salesDocumentID) !== 0) {
							vc._getSalesOrderAvailableQtyFromSAP(salesDocumentID, true).always(function () {
								vc.busyDlg.close();
							});
						}
						//End of Change:SXVASAMSETTI                                    
						else {
							vc.busyDlg.close();
						}

					}).fail(function (msg) {
						vc.busyDlg.close();
						if (vc.page) {
							vc.splitApp.toDetail(vc.splitApp.getInitialDetail());
							vc.splitApp.showMaster();
						}
						vc.currentSalesDocumentID = null;
						core.getModel("currentSalesDocument").setProperty("/SalesDocumentID", "");
						vc.router.navTo("master", {
							from: "customer",
							orgData: vc.orgData,
							customerId: vc.currentCustomerID
						}, true);
					}).always(function () {
						if (vc.startupMsg) {
							sap.m.MessageToast.show(vc.startupMsg);

							vc.startupMsg = null;
						}
					});
				});
			}
		},

		onBeforeRendering: function () {
			var qPnl = vc.view.byId("detailQuotePageHeader"),
				sPnl = vc.view.byId("detailSalesOrderPageHeader");

			qPnl.attachEvent("expand", vc._resizeTable, null);
			sPnl.attachEvent("expand", vc._resizeTable, null);
			$(window).resize(vc._resizeTable);
			vc._resizeTable();
		},

		onAfterRendering: function () {
			var linesModel = core.getModel("currentSalesDocumentLines");

			linesModel.bindList("/", null).attachChange(vc._handleDetailListChange);

		},

		onAfterTableOnAfterRendering: function () {
			vc._calculateTotals();
			if (sap.ui.version >= "1.38") {
				$("#" + this.getId() + "-vsb").scroll(function () {
					vc._calculateTotals();
				});
			}

		},

		_setCustShippingConditions: function (customerId) {
			var model = core.getModel();
			var CustShippingConditionsDfr = $.Deferred(function (defer) {
				model.read("RouteOptionSet?$expand=ShippingRouteSet&$filter=Customer eq '" + customerId + "'", {
					//	model.read('/RouteOptionSet?$filter=Customer eq"'+customerId + '"&expand=ShippingRouteSet', {
					success: function (data) {
						var routeOptionsModel = core.getModel("routeOptions");
						routeOptionsModel.setData(data.results);
						defer.resolve();
					},
					error: function () {
						defer.reject();
					}
				});

			});
		},
		handleShippingRoutes: function (event) {
			// create popover
			if (!vc._oPopover) {
				vc._oPopover = sap.ui.xmlfragment("popoverNavCon", "gdt.salesui.s4.fragment.DetailHeaderPopover", vc);
				vc.getView().addDependent(vc._oPopover);
			}

			// delay because addDependent will do a async rerendering and the popover will immediately close without it
			var oButton = event.getSource();
			jQuery.sap.delayedCall(0, vc, function () {
				vc._oPopover.openBy(oButton);
			});
		},
		handleOnNavToShippingRoute: function (event) {
			var oCtx = event.getSource().getBinding("title").getBindings()[0].getContext();
			var oModel = event.getSource().getBinding("title").getBindings()[0].getModel();
			var row = oModel.getProperty(oCtx.getPath());
			var oNavCon = sap.ui.core.Fragment.byId("popoverNavCon", "navCon");
			var oDetailPage = sap.ui.core.Fragment.byId("popoverNavCon", "detail");
			var oTableCoumn = sap.ui.core.Fragment.byId("popoverNavCon", "Account");
			if (oDetailPage.getModel("shippingRoute") === undefined) {
				var shippingRoute = new sap.ui.model.json.JSONModel([]);
				oDetailPage.setModel(shippingRoute, "shippingRoute");
			}
			oDetailPage.getModel("shippingRoute").setData(row.ShippingRouteSet.results);
			oDetailPage.setTitle(row.RouteOptionID + "-" + row.RouteOptionText);
			oTableCoumn.setVisible(row.RouteOptionID === "S");
			oNavCon.to(oDetailPage);
		},
		handleOnNavBacktoRoutionOptions: function () {
			var oNavCon = sap.ui.core.Fragment.byId("popoverNavCon", "navCon");
			oNavCon.back();
		},

		handleSelectShippingPoint: function (event) {
			var oCtx = event.getSource().getBinding("title").getContext();
			var oModel = event.getSource().getBinding("title").getModel();
			var row = oModel.getProperty(oCtx.getPath());
			var hdr = core.getModel("currentSalesDocument");
			hdr.setProperty("/Account", row.Account);
			hdr.setProperty("/RouteOptionID", row.Routeoption);
			hdr.setProperty("/ShippingConditionID", row.Vsbed);
			hdr.setProperty("/Scaccode", row.Scaccode);
			vc._oPopover.close();
		},

		handlePopoverClosed: function () {
			vc.handleOnNavBacktoRoutionOptions();
		},

		//Begin of insert AXPALADUGU  
		// Value help for account field

		accounthandleValueHelp: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();

			vc.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!vc._acvalueHelpDialog) {
				vc._acvalueHelpDialog = sap.ui.xmlfragment(
					"acpopoverInputHelp", "gdt.salesui.s4.fragment.DetailHeaderAccountValueHelp", vc
				);
				vc.getView().addDependent(vc._acvalueHelpDialog);
			}

			var routeFilter = _.filter(sap.ui.getCore().getModel("routeOptions").getData(), function (data) {
				return data.RouteOptionID === "S";
			});

			var shipCondId = core.getModel("currentSalesDocument").getProperty("/ShippingConditionID");
			if (routeFilter.length > 0) {
				var routeData = routeFilter[0].ShippingRouteSet;
				var routeResult = routeData.results;

				var shipFilter = new sap.ui.model.json.JSONModel(_.filter(routeResult, function (data) {
					return data.Vsbed === shipCondId;
				}));
				vc._acvalueHelpDialog.setModel(shipFilter);
				//	sap.ui.getCore().byId("acpopoverInputHelp").setModel(shipFilter);
			}

			//var accData = core.getModel("currentSalesDocument").getProperty("/Account");
			//var shipCondIdData = core.getModel("currentSalesDocument").getProperty("/ShippingConditionID");

			// create a filter for the binding
			/*			vc._acvalueHelpDialog.getBinding("items").filter([new Filter(
							"Vsbed",
							sap.ui.model.FilterOperator.Contains, shipCondIdData
						)]);*/

			// open value help dialog filtered by the input value
			vc._acvalueHelpDialog.open();
		},

		_handleAcValueHelpSearch: function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"Account",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleAcValueHelpClose: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var hdr = core.getModel("currentSalesDocument");
				hdr.setProperty("/Account", oSelectedItem.getTitle());
				//var productInput = vc.getView().byId(this.inputId);
				//productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},
		//End of insert AXPALADUGU                      

		//Begin of Change for DocumentFlow Section:SXVASAMSETTI 
		_refreshDocumentFlowFromServer: function (salesDocumentID, refresh) {
			vc._getDocumentFlowFromSAP(salesDocumentID, refresh).always(function () {
				vc.busyDlg.close();
			});
		},

		_doExpandAll: function () {
			var treeTable = vc.view.byId("docflowTreeTable");
			for (var i = 0; i < treeTable.getRows().length; i++) {
				if (treeTable.getContextByIndex(i) !== undefined) {
					try {
						treeTable.expand(i);
					} catch (e) {
						//	console.log(e);
					}
				}
			}
		},

		_getDocumentFlowFromSAP: function (documentID, refresh) {
			var deferred = $.Deferred(function (defer) {
				vc.busyDlg.setText("Fetching related documents to document(" + documentID + ") from SAP.");
				vc.busyDlg.open();
				datacontext.documentFlow.get(documentID, refresh).done(function (data) {
					var treeTable = vc.view.byId("docflowTreeTable");
					var treeTableModel = new sap.ui.model.json.JSONModel();
					treeTableModel.setData({
						modelData: data
					});
					treeTable.setModel(treeTableModel);
					treeTable.bindRows("/modelData");
					defer.resolve();
				}).fail(function (msg) {
					defer.reject(msg);
				});
			}).done(function () {
				vc._doExpandAll();
			}).fail();

			return deferred;
		},
		//End of Change       

		// Begin of Change :SXVASAMSETTI : 04/12/2016
		_getSalesOrderAvailableQtyFromSAP: function (documentID, refresh) {
			var deferred = $.Deferred(function (defer) {
				vc.busyDlg.setText("Fetching Sales Order Available Qty details for the document(" + documentID + ") from SAP.");
				vc.busyDlg.open();
				datacontext.SoAvailableQty.get(documentID, refresh).done(function (data) {
					vc.busyDlg.open();
					vc.view.getModel("soAvailableQty").setData(data);
					defer.resolve();
				}).fail(function (msg) {
					defer.reject(msg);
				});
			}).done(function () {
				vc._resizeSoAvailQtyTable();
			}).fail();

			return deferred;
		},
		_resizeSoAvailQtyTable: function () {
			var height = $(document).height(),
				tbl = vc.view.byId("soAvailableQty"),
				offset = 375,
				rows = parseInt((height - offset) / 32);
			if (tbl) {
				if (rows > 5) {
					tbl.setVisibleRowCount(rows);
				} else {
					tbl.setVisibleRowCount(5);
				}
			}
		},

		handleDetailQtyChange: function (event) {
			detailsvm.HandleDetailQtyChange(event);
			vc._calculateTotals();
		},

		_handleDetailListChange: function (event) {
			var source = event.getSource(),
				linesModel = core.getModel("currentSalesDocumentLines");

			_.each(source.getContexts(), function (context) {
				var path = context.getPath();

				/*                    		if (_.filter(linesModel.aBindings, function (b) {return b.getPath() == 'QTY' && (b.getContext()) && (b.getContext().getPath) && (b.getContext().getPath() == path); }).length == 0) {
				                    			linesModel.bindProperty('QTY',context).attachChange(function(event) {detailsvm.HandleDetailQtyChange(event); _calculateTotals()});
				                    		}*/
				if (_.filter(linesModel.aBindings, function (b) {
						return b.getPath() === "ListPrice" && (b.getContext()) && (b.getContext().getPath) && (b.getContext().getPath() === path);
					}).length === 0) {
					linesModel.bindProperty("ListPrice", context).attachChange(function (event) {
						detailsvm.HandleDetailListPriceChange(event);
						vc._calculateTotals();
					});
				}
				if (_.filter(linesModel.aBindings, function (b) {
						return b.getPath() === "GDTDiscountPercent" && (b.getContext()) && (b.getContext().getPath) && (b.getContext().getPath() ===
							path);
					}).length === 0) {
					linesModel.bindProperty("GDTDiscountPercent", context).attachChange(function (event) {
						detailsvm.HandleDetailGDTDiscountChange(event);
						vc._calculateTotals();
					});
				}
				if (_.filter(linesModel.aBindings, function (b) {
						return b.getPath() === "UnitCost" && (b.getContext()) && (b.getContext().getPath) && (b.getContext().getPath() === path);
					}).length === 0) {
					linesModel.bindProperty("UnitCost", context).attachChange(function (event) {
						detailsvm.HandleDetailUnitCostChange(event);
						vc._calculateTotals();
					});
				}
				if (_.filter(linesModel.aBindings, function (b) {
						return b.getPath() === "ExtendedCost" && (b.getContext()) && (b.getContext().getPath) && (b.getContext().getPath() === path);
					}).length === 0) {
					linesModel.bindProperty("ExtendedCost", context).attachChange(function (event) {
						detailsvm.HandleDetailExtendedCostChange(event);
						vc._calculateTotals();
					});
				}
				if (_.filter(linesModel.aBindings, function (b) {
						return b.getPath() === "CustomerDiscountPercent" && (b.getContext()) && (b.getContext().getPath) && (b.getContext().getPath() ===
							path);
					}).length === 0) {
					linesModel.bindProperty("CustomerDiscountPercent", context).attachChange(function (event) {
						detailsvm.HandleDetailCustomerDiscountChange(event);
						vc._calculateTotals();
					});
				}
				if (_.filter(linesModel.aBindings, function (b) {
						return b.getPath() === "UnitPrice" && (b.getContext()) && (b.getContext().getPath) && (b.getContext().getPath() === path);
					}).length === 0) {
					linesModel.bindProperty("UnitPrice", context).attachChange(function (event) {
						detailsvm.HandleDetailUnitPriceChange(event);
						vc._calculateTotals();
					});
				}
				if (_.filter(linesModel.aBindings, function (b) {
						return b.getPath() === "ExtendedPrice" && (b.getContext()) && (b.getContext().getPath) && (b.getContext().getPath() === path);
					}).length === 0) {
					linesModel.bindProperty("ExtendedPrice", context).attachChange(function (event) {
						detailsvm.HandleDetailExtendedPriceChange(event);
						vc._calculateTotals();
					});
				}
				if (_.filter(linesModel.aBindings, function (b) {
						return b.getPath() === "GrossProfit" && (b.getContext()) && (b.getContext().getPath) && (b.getContext().getPath() === path);
					}).length === 0) {
					linesModel.bindProperty("GrossProfit", context).attachChange(function (event) {
						detailsvm.HandleDetailGrossProfitChange(event);
						vc._calculateTotals();
					});
				}
				if (_.filter(linesModel.aBindings, function (b) {
						return b.getPath() === "GrossProfitPercentage" && (b.getContext()) && (b.getContext().getPath) && (b.getContext().getPath() ===
							path);
					}).length === 0) {
					linesModel.bindProperty("GrossProfitPercentage", context).attachChange(function (event) {
						detailsvm.HandleDetailGrossProfitPercentageChange(event);
						vc._calculateTotals();
					});
				}

			});
		},

		_resizeTable: function () {
			var height = $(document).height(),
				tbl = vc.view.byId("lineItemsTable"),
				//	qPnl = vc.view.byId("detailQuotePageHeader"),
				//	sPnl = vc.view.byId("detailSalesOrderPageHeader"),
				//	salesDoc = core.getModel("currentSalesDocument"),
				//	docCat = (salesDoc) ? salesDoc.getProperty("/DocumentCategory") : "B",
				//	isQuote = (docCat) ? (docCat == "B") : false,
				//   qExpanded = (qPnl) ? qPnl.getExpanded() : true,
				//   sExpanded = (sPnl) ? sPnl.getExpanded() : true,
				offset = 375, //MG - reduce offset now Header on own tab
				//	                		offset = (isQuote) ? ((qExpanded) ? 470 : 415) : ((sExpanded) ? 635 : 444),
				rows = parseInt((height - offset) / 32);

			if (tbl) {
				if (rows > 5) {
					rows = rows - 1;
					tbl.setVisibleRowCount(rows);
				} else {
					tbl.setVisibleRowCount(5);
				}
			}
		},

		_refreshSalesDocumentFromServer: function (salesDocumentID, refresh, docType) {
			var deferred;

			if (!refresh && core.getModel("currentSalesDocument").getProperty("/SalesDocumentID") === salesDocumentID) {
				return $.Deferred(function (def) {
					return def.resolve();
				}).promise();
			}

			deferred = $.Deferred(function (defer) {
				vc.currentSalesDocumentID = salesDocumentID;

				dataLoader.loadSalesDocument(salesDocumentID, vc.forceRefresh || refresh, docType).done(function () {
					//	var currentCustomerID = core.getModel("currentCustomer").getProperty("/CustomerID");

					vc.view.setModel(core.getModel("currentTotals"), "currentTotals");
					vc.view.setModel(core.getModel("currentCustomer"), "currentCustomer");
					vc.view.setModel(core.getModel("customerSelectItems"), "customerSelectItems");
					vc.view.setModel(core.getModel("currentSalesDocumentLines"), "currentSalesDocumentLines");
					vc.view.setModel(core.getModel("currentSalesDocument"), "currentSalesDocument");
					vc.view.setModel(core.getModel("currentAttachments"), "currentAttachments");
					vc.view.setModel(core.getModel("currentVia"), "currentVia");
					vc._setCurrentDocumentStates();
					if (!parseInt(salesDocumentID)) { // Creating a new document
						vc._setupNewDocument();
					}
					vc._calculateTotals();

					vc.splitApp.hideMaster();
					defer.resolve();
				}).fail(function (msg) {
					defer.reject(msg);
				}).always(function () {
					vc.forceRefresh = false;
					vc._resizeTable();
				});
			});

			return deferred;
		},

		handleTableKeyDown: function (event) {
			var target = event.target,
				tbl = vc.view.byId("lineItemsTable"),
				data = core.getModel("currentSalesDocumentLines").getData(),
				newtarget = null,
				//	parent = null,
				td = null,
				tr = null,
				body = null,
				value = null,
				startRow = tbl.getFirstVisibleRow(),
				lastRow = 0,
				numRows = (data) ? data.length : 0,
				voffset = 0,
				hoffset = 0,
				newrow = -1,
				newcol = -1,
				//	moved = false,
				row = 0,
				col = 0;

			if (numRows === 0) {
				return;
			}

			td = $(target).closest("td");

			if (td) {
				tr = $(td).closest("tr");
			}

			if (tr) {
				col = _.findIndex(tr.children(), {
					id: $(td).attr("id")
				});
				body = tr.closest("tbody");
			}

			if (body) {
				lastRow = body.children().length - 1;
				row = _.findIndex(body.children(), {
					id: $(tr).attr("id")
				});
			}

			if (event.ctrlKey && event.shiftKey && event.keyCode === 13) { // Ctrl-Shift-Down = copy to all rows
				$(target).blur();
				setTimeout(function () {
					var c = _.find(tbl.getColumns(), function (col) {
							var colid = col.getAggregation("template").getId(),
								trgid = target.getAttribute("id").substring(0, colid.length);

							return colid === trgid;
						}),
						t = (c) ? c.getTemplate() : null,
						bindingInfo = (t) ? t.getBindingInfo("value") : null,
						parts = (bindingInfo) ? bindingInfo.parts : null,
						firstPart = (parts && parts.length > 0) ? parts[0] : null,
						path = (firstPart) ? firstPart.path : null,
						linesModel = vc.view.getModel("currentSalesDocumentLines");

					if (path && path !== "StructuredLineID") {
						_.each(data, function (r, i) {
							if ((core.getModel("currentState").getProperty("/isEditMode")) && !linesModel.getProperty("/" + (i) + "/WBSElement") && !
								linesModel.getProperty("/" + (i) + "/MarkedAsDeleted") && !linesModel.getProperty("/" + (i) + "/DeletedFlag")) {
								linesModel.setProperty("/" + (i) + "/" + path, data[row + startRow][path]);
							}
						});
						vc.view.getModel("currentSalesDocumentLines").setData(data);
					}
				});
				event.preventDefault();
				event.stopPropagation();
				return;
			}

			if (event.shiftKey) {
				if (event.keyCode === 9) {
					hoffset = -1;
				}
			} else {
				if (event.keyCode === 9) {
					hoffset = 1;
				}
			}
			if (event.keyCode === 40) {
				voffset = 1;
			}
			if (event.keyCode === 38) {
				voffset = -1;
			}

			newrow = row + voffset;
			newcol = col + hoffset;

			if (newrow === row && newcol === col) {
				return;
			} // not one of our interesting key presses

			$(target).blur();

			setTimeout(function () {
				var c = _.find(tbl.getColumns(), function (col) {
						return col.getAggregation("template").getId() == target.getAttribute("id").substring(0, target.getAttribute("id").indexOf("-"));
					}),
					t = (c) ? c.getTemplate() : null,
					bindingInfo = (t) ? t.getBindingInfo("value") : null,
					parts = (bindingInfo) ? bindingInfo.parts : null,
					firstPart = (parts && parts.length > 0) ? parts[0] : null,
					path = (firstPart) ? firstPart.path : null,
					linesModel = vc.view.getModel("currentSalesDocumentLines");

				if (event.shiftKey) {
					if (event.keyCode !== 9) {
						value = linesModel.getProperty("/" + (startRow + row) + "/" + path);
					}
				}
				if (path && path !== "StructuredLineID") {
					if (value && (core.getModel("currentState").getProperty("/isEditMode")) && !linesModel.getProperty("/" + (startRow + newrow) +
							"/WBSElement") && !linesModel.getProperty("/" + (startRow + newrow) + "/MarkedAsDeleted") && !linesModel.getProperty("/" + (
							startRow + newrow) + "/DeletedFlag")) {
						linesModel.setProperty("/" + (startRow + newrow) + "/" + path, value);
					}
				}

				if ((newrow > lastRow) && (startRow + lastRow < numRows - 1)) {
					newrow--;
					row--;
					tbl.setFirstVisibleRow(startRow + 1);
				}

				if ((newrow < 0) && (startRow > 0)) {
					newrow++;
					row++;
					tbl.setFirstVisibleRow(startRow - 1);
				}

				setTimeout(function () {

					if ((voffset && newrow >= 0 && newrow < body.children().length) ||
						(hoffset && newcol >= 0 && newcol < $(body.find("tr")[newrow]).children().length)) {
						newtarget = $($(body.find("tr")[newrow]).find("td")[newcol]).find("input");
						event.preventDefault();
						event.stopPropagation();
					}

					if (newtarget) {
						setTimeout(function () {

							if (!$(newtarget).visible(true, false, "both")) {
								$(".sapUiTableCtrlScr").scrollTo($(newtarget));
							}
							$(newtarget).focus();

						});
					}
				});
			}, 10);
		},

		_reloadSAPAttachments: function (salesDocumentId) {
			return $.Deferred(function (defer) {
				datacontext.salesdocumentattachments.getByForeignKey(salesDocumentId, true).done(function () {
					var salesDocumentAttachments = core.getModel("currentSalesDocumentAttachments"),
						results = datacontext.salesdocumentattachments.getLocalByForeignKey(salesDocumentId);

					salesDocumentAttachments.setData(results);

					defer.resolve();
				}).fail(function (response) {
					defer.reject(response);
				});
			}).promise();
		},

		_refreshAttachments: function () {
			var documentCategory = core.getModel("currentSalesDocument").getProperty("/DocumentCategory"),
				attachmentsInSAP = core.getModel("currentSalesDocumentAttachments"),
				absoluteUrl,
				newAttachment = false,
				deferred = $.Deferred(function (def) {
					sharepoint.listDocuments(vc.currentCustomerID, vc.currentSalesDocumentID, vc.orgData)
						.done(function (attachments) {
							core.getModel("currentAttachments").setData(attachments);
							_.each(attachments, function (attachment) {
								absoluteUrl = sharepoint.absoluteUrl(attachment.ServerRelativeUrl);
								if (absoluteUrl.indexOf("?") !== -1) {
									absoluteUrl += "&web=1";
								} else {
									absoluteUrl += "?web=1";
								}
								if (!_.findWhere(attachmentsInSAP.getData(), {
										DocumentDes: attachment.Name
									})) { // if not in SAP yet...add it as a link
									//	console.log("Document " + attachment.Name + " not found in SAP Attachments: ");
									_.each(attachmentsInSAP.getData(), function (sapAttachment) {
										//		console.log(sapAttachment.DocumentDes);
									});
									attachmentsInSAP.getData().push({
										DocumentCategory: documentCategory,
										AttachmentLink: absoluteUrl,
										DocumentDes: attachment.Name,
										SalesDocumentID: vc.currentSalesDocumentID
									}); //push new record
									core.getModel().createEntry("/SalesDocumentSet(SalesDocumentID='" + vc.currentSalesDocumentID + "')/AttachmentsLink", {
										DocumentCategory: documentCategory,
										AttachmentLink: absoluteUrl,
										DocumentDes: attachment.Name,
										SalesDocumentID: vc.currentSalesDocumentID
									});
									newAttachment = true;
									//	console.log("Document " + attachment.Name + " attached in SAP as " + absoluteUrl);
								}
							});

							if (newAttachment) {
								core.getModel().submitChanges();
								vc._reloadSAPAttachments(vc.currentSalesDocumentID).done(function () {
									if (!core.getModel("currentState").getProperty("/isQuote") && !!core.getModel("currentSalesDocument").getProperty(
											"/ReferencedBy")) {
										vc._checkForRelatedAttachments(core.getModel("currentSalesDocument").getProperty("/ReferencedBy"))
											.done(function () {
												def.resolve();
											});
									} else {
										def.resolve();
									}
								}).fail(function () {
									def.reject("Failed to reload SAP Attachments");
								});
							} else {
								if (!core.getModel("currentState").getProperty("/isQuote") && !!core.getModel("currentSalesDocument").getProperty(
										"/ReferencedBy")) {
									vc._checkForRelatedAttachments(core.getModel("currentSalesDocument").getProperty("/ReferencedBy"))
										.done(function () {
											def.resolve();
										});
								} else {
									def.resolve();
								}
							}
						}).fail(function (msg) {
							def.reject(msg);
						}).always(function () {
							vc.view.setModel(core.getModel("currentAttachments"), "currentAttachments");
						});
				});

			return deferred.promise();
		},
		_checkForRelatedAttachments: function (refDocId) {
			var deferred = $.Deferred(function (def) {
				sharepoint.listDocuments(vc.currentCustomerID, refDocId, vc.orgData)
					.done(function (attachments) {
						var currentAttachments = core.getModel("currentAttachments").getData(),
							documentCategory = core.getModel("currentSalesDocument").getProperty("/DocumentCategory"),
							attachmentsInSAP = core.getModel("currentSalesDocumentAttachments"),
							newAttachment = false,
							absoluteUrl;

						_.each(attachments, function (attachment) {
							absoluteUrl = sharepoint.absoluteUrl(attachment.ServerRelativeUrl);
							if (absoluteUrl.indexOf("?") !== -1) {
								absoluteUrl += "&web=1";
							} else {
								absoluteUrl += "?web=1";
							}
							attachment.isRelated = true;
							currentAttachments.push(attachment);
							if (!_.findWhere(attachmentsInSAP.getData(), {
									DocumentDes: attachment.Name
								})) { // if not in SAP yet...add it as a link
								//	console.log("Document (from Quote) " + attachment.Name + " not found in SAP Attachments: ");
								_.each(attachmentsInSAP.getData(), function (sapAttachment) {
									//	console.log(sapAttachment.DocumentDes);
								});
								attachmentsInSAP.getData().push({
									DocumentCategory: documentCategory,
									AttachmentLink: absoluteUrl,
									DocumentDes: attachment.Name,
									SalesDocumentID: vc.currentSalesDocumentID
								}); //push new record
								core.getModel().createEntry("/SalesDocumentSet(SalesDocumentID='" + vc.currentSalesDocumentID + "')/AttachmentsLink", {
									DocumentCategory: documentCategory,
									AttachmentLink: absoluteUrl,
									DocumentDes: attachment.Name,
									SalesDocumentID: vc.currentSalesDocumentID
								});
								newAttachment = true;
								//	console.log("Document " + attachment.Name + " (from Quote) attached in SAP as " + absoluteUrl);
							}
							core.getModel("currentAttachments").setData(currentAttachments);
						});

						if (newAttachment) {
							core.getModel().submitChanges();
							vc._reloadSAPAttachments(vc.currentSalesDocumentID).done(function () {
								//	core.getModel("currentAttachments").setData(currentAttachments);
								def.resolve();
							}).fail(function () {
								def.reject("Failed to reload SAP Attachments");
							});
						} else {
							core.getModel("currentAttachments").setData(currentAttachments);
							def.resolve();
						}
					}).fail(function (msg) {
						def.reject(msg);
					});
			});

			return deferred.promise();
		},
		_attachValidationHandlers: function () {
			// attach handlers for validation errors

			sap.ui.getCore().attachValidationError(function (evt) {
				var control = evt.getParameter("element"),
					errMsg = "";
				if (control && control.setValueState) {
					control.setValueState("Error");
					if (control.getValueStateText) {
						errMsg = control.getValueStateText();
					}

					errMsg = (errMsg !== "") ? errMsg : "Invalid Value";

					control.setTooltip(errMsg);
				}
			});
			sap.ui.getCore().attachValidationSuccess(function (evt) {
				var control = evt.getParameter("element");
				if (control && (control.setValueState) && (control.setTooltip)) {
					control.setValueState("None");
					control.setTooltip();
				}
			});
		},

		_canEdit: function () {
			return !(core.getModel("currentState").getProperty("/isQuote") && ((core.getModel("currentSalesDocument").getProperty("/Status") ==
				"C") || (core.getModel("currentSalesDocument").getProperty("/Status") == "B")));
		},

		_setCurrentDocumentStates: function () {
			var doc = core.getModel("currentSalesDocument").getData(),
				details = core.getModel("currentSalesDocumentLines").getData(),
				unsubmittedDetails = _.filter(details, function (row) {
					return (!!row.ItemCategory && row.ItemCategory[0] !== "Y") || (!!row.ReasonForRejection);
				}),
				currentState = core.getModel("currentState");

			currentState.setProperty("/outputType", "ZAN1");
			currentState.setProperty("/timezone", new Date().toString().match(/\(([A-Za-z\s].*)\)/)[1]);
			currentState.setProperty("/timezoneOffset", new Date().toString().match(/([-\+][0-9]+)\s/)[1]);
			currentState.setProperty("/LineCount", (details) ? details.length : 0);
			currentState.setProperty("/isQuote", doc.DocumentCategory === "B");
			currentState.setProperty("/isSalesOrder", doc.DocumentCategory === "C");
			currentState.setProperty("/isPendingSalesOrder", doc.DocumentCategory === "C" && doc.SalesOrderStatus !== "E0002");
			currentState.setProperty("/isSubmittedSalesOrder", doc.DocumentCategory === "C" && doc.SalesOrderStatus === "E0002");
			currentState.setProperty("/canDelete", currentState.getProperty("/isPendingSalesOrder"));

			currentState.setProperty("/isEditMode", false);
			currentState.setProperty("/isNotEditMode", true);
			currentState.setProperty("/canEdit", vc._canEdit());
			//						currentState.setProperty('/canEdit', (currentState.getProperty('/isQuote') || currentState.getProperty('/isPendingSalesOrder')));

			vc.view.setModel(currentState, "currentState");
		},

		_setupNewDocument: function () {
			var doc = core.getModel("currentSalesDocument"),
				customer = core.getModel("currentCustomer"),
				customerSelectItems = core.getModel("customerSelectItems"),
				shipTos = customerSelectItems.getProperty("/ShipTos") || [],
				billTos = customerSelectItems.getProperty("/BillTos") || [];

			doc.setProperty("/CustomerID", vc.currentCustomerID);
			doc.setProperty("/Vkorg", vc.orgData.substring(0, 4));
			doc.setProperty("/Vtweg", vc.orgData.substring(4, 6));
			doc.setProperty("/Spart", vc.orgData.substring(6, 8));
			doc.setProperty("/PriceDate", doc.getProperty("/ValidFrom"));
			doc.setProperty("/ShipToID", customerSelectItems.getProperty("/DefaultShipToID"));
			doc.setProperty("/BillToID", customerSelectItems.getProperty("/DefaultBillToID"));
			doc.setProperty("/PayerID", customerSelectItems.getProperty("/DefaultPayerID"));
			if (Boolean(customerSelectItems.getProperty("EndCustomers"))) {
				doc.setProperty("/EndCustomerID", customerSelectItems.getProperty("/DefaultEndCustomerID"));
			}
			doc.setProperty("/ShippingConditionID", customer.getProperty("/ShippingConditionID"));
			vc.handleAddDetailLine();
			vc._toggleEdit(true);
			vc._determineExchangeRate(doc, doc.getData());
		},

		handleDragOver: function (event) {
			event.stopPropagation();
			event.preventDefault();
			event.originalEvent.dataTransfer.dropEffect = "copy";
		},

		handleDropFile: function (event) {
			var dialog = vc.view.byId("detailLineImportConfirmDialog"),
				files = event.originalEvent.dataTransfer.files;

			event.stopPropagation();
			event.preventDefault();

			if (vc.currentTab === "attachments") {
				if (parseInt(vc.currentSalesDocumentID) === 0) {
					sap.m.MessageToast.show("You must save the new document to SAP before you can add attachments.");
					return;
				}
				if ((!!files) && files.length > 0) {
					if (files[0].name.length > 45) {
						MessageBox.show("Attachment's name should not exceeds 45 characters. Please rename it to 45 characters and try again", {
							icon: MessageBox.Icon.ERROR,
							title: "Attachment Name Length restriction Error",
							actions: MessageBox.Action.OK
						});
						sap.m.MessageToast.show("Failed to load the attachment due to its length constraint.");
						return;
					}

					vc.page.setBusyIndicatorDelay(0);
					vc.page.setBusy(true);

					setTimeout(function () {
						var reader = new FileReader();
						reader.onload = function (result) {
							var fileData = "",
								model = core.getModel(),
								byteArray = new Uint8Array(result.target.result);
							if (result.target.readyState === FileReader.DONE) { // DONE == 2
								for (var i = 0; i < byteArray.byteLength; i++) {
									fileData += String.fromCharCode(byteArray[i]);
								}
								sharepoint.uploadDocument(vc.currentCustomerID, vc.currentSalesDocumentID, result.target.result, files[0].name, vc.orgData)
									.done(function (relativeUrl) {
										var documentCategory = core.getModel("currentSalesDocument").getProperty("/DocumentCategory"),
											attachmentsInSAP = core.getModel("currentSalesDocumentAttachments"),
											newAttachment = false,
											absoluteUrl = sharepoint.absoluteUrl(relativeUrl);
										if (absoluteUrl.indexOf("?") !== -1) {
											absoluteUrl += "&web=1";
										} else {
											absoluteUrl += "?web=1";
										}
										if (!_.findWhere(attachmentsInSAP.getData(), {
												DocumentDes: files[0].name
											})) { // if not in SAP yet...add it as a link
											attachmentsInSAP.getData().push({
												DocumentCategory: documentCategory,
												AttachmentLink: absoluteUrl,
												DocumentDes: files[0].name,
												SalesDocumentID: vc.currentSalesDocumentID
											}); //push new record
											model.createEntry("/SalesDocumentSet(SalesDocumentID='" + vc.currentSalesDocumentID + "')/AttachmentsLink", {
												DocumentCategory: documentCategory,
												AttachmentLink: absoluteUrl,
												DocumentDes: files[0].name,
												SalesDocumentID: vc.currentSalesDocumentID
											});
											newAttachment = true;
											//		console.log("Document " + files[0].name + " attached in SAP as " + absoluteUrl);
										}
										if (newAttachment) {
											model.submitChanges();
										}
										vc._refreshAttachments();
									}).fail(function (msg) {
										MessageToast.show(msg);
									}).always(function () {
										vc.page.setBusy(false);
									});
							}
						};
						reader.onerror = function () {
							var msg = "Could not load the requested file to Sharepoint";
							vc.page.setBusy(false);
							MessageToast.show(msg);
						};
						reader.readAsArrayBuffer(files[0]);
					});
				}
			} else {
				if (!vc._isEmpty()) {
					dialog.removeAllButtons();

					dialog.addStyleClass("sapUiSizeCompact");
					dialog.addButton(new sap.m.Button({
						text: "Append",
						press: function () {
							dialog.close();
							vc._doImportFile(files, true);
						}
					}));
					dialog.addButton(new sap.m.Button({
						text: "Replace",
						press: function () {
							dialog.close();
							vc._doImportFile(files);
						}
					}));
					dialog.addButton(new sap.m.Button({
						text: "Cancel",
						press: function () {
							dialog.close();
						}
					}));

					dialog.open();
				} else {
					//_deleteBlankDetailLines( );
					vc._doImportFile(files);
				}
			}
		},

		_doImportFile: function (files, append) {
			var reader = new FileReader();

			reader.onload = (function (file) {
				return function (e) {
					var errors = [],
						missingAddresses = [];

					if (e.target.readyState === FileReader.DONE) { // DONE == 2
						if (!vc.view.getModel("currentState").getProperty("/isEditMode")) {
							vc._toggleEdit(true);
						}
						//view.getModel('currentSalesDocumentLines').setData([]);
						importer.ImportFromCCW(e.target.result, vc.view.getModel("currentSalesDocument"),
								vc.view.getModel("currentSalesDocumentLines"), errors, missingAddresses,
								vc._createNewLine, vc._lookupPartID, vc._determineItemCategoryForDropShip, append)
							.fail(function (msg) {
								MessageBox.show(msg, {
									icon: MessageBox.Icon.ERROR,
									title: "Import Error",
									actions: MessageBox.Action.OK
								});
							})
							.always(function () {
								vc.busyDlg.close();
								if (errors && errors.length !== 0) {
									vc._presentImportErrors(errors);
								} else {
									if (missingAddresses && missingAddresses.length !== 0) {
										vc._presentAddressErrors(missingAddresses);
									} else {
										vc._calculateTotals();
									}
								}
							});
					}
				};
			})(files[0]);

			reader.onerror = (function () {
				vc.busyDlg.close();
			})();

			vc.busyDlg.setText("Attempting to import file.");
			vc.busyDlg.open();

			setTimeout(function () {
				try {
					reader.readAsText(files[0]);
				} catch (err) {
					vc.busyDlg.close();
				}
			});
		},

		_presentImportErrors: function (errors) {
			var dialog = vc.view.byId("detailLineItemsImportErrorsDialog");

			dialog.addStyleClass("sapUiSizeCompact");

			vc.view.setModel(new sap.ui.model.json.JSONModel(_.uniq(errors, function (error) {
				return error.CustomerPartID;
			})), "importErrors");

			dialog.open();
		},

		_presentAddressErrors: function (errors) {
			var dialog = vc.view.byId("detailLineItemsAddressErrorsDialog");
			//		title = vc.view.byId("detailLineItemsAddressErrorsDialog-title");

			dialog.addStyleClass("sapUiSizeCompact");
			//						title.addStyleClass("");

			vc.view.setModel(new sap.ui.model.json.JSONModel(_.uniq(errors)), "addressErrors");

			dialog.open();
		},

		_deleteBlankDetailLines: function () {
			var detailLinesModel = vc.view.getModel("currentSalesDocumentLines"),
				detailLines = jQuery.extend(true, [], detailLinesModel.getData()),
				lengthB4 = detailLines.length;

			detailLines = _.filter(detailLines, function (line) {
				return (!!line.MaterialID);
			});

			if (!!detailLinesModel && (lengthB4 > detailLines.length)) {
				detailLinesModel.setData(detailLines);
			}
		},

		handleCancelImportErrorDialog: function () {
			var dialog = vc.view.byId("detailLineItemsImportErrorsDialog");
			dialog.close();
		},

		handleCancelAddressErrorDialog: function () {
			var dialog = vc.view.byId("detailLineItemsAddressErrorsDialog");
			dialog.close();
		},

		handleEmailMasterData: function () {
			var dialog = vc.view.byId("detailLineItemsImportErrorsDialog"),
				material = vc.view.getModel("importErrors").getData(),
				extNotes = vc.view.byId("ExtNotes").getValue(),
				body = "",
				i = 0,
				l = 0;

			l = (Boolean(material)) ? material.length : 0;

			for (i = 0; i < l; i++) {
				body += "MFRNR:" + material[i].ManufacturerID;
				body += "MFRPN:" + material[i].CustomerPartID;
				body += "STEXT:" + material[i].Description;
				body += "PRICE:" + material[i].ListPrice + "\n";
			}

			if ((extNotes) && extNotes.length !== 0) {
				body += "Note:\n";
				body += extNotes;
			}

			dialog.close();

			//	sap.m.URLHelper.triggerEmail("masterdata@gdt.com","Missing Material",body);  
			//Begin of Change: 09/06/16 : SXVASAMSETTI Trigger mail from SAP : Implemented due to restriction in web-browser to send mail with large data                		
			vc._sendMailFromSAP(body, true);
		},
		_sendMailFromSAP: function (MailBodyContent, refresh) {
			var deferred = $.Deferred(function (defer) {
				datacontext.EmailNotification.send(MailBodyContent, refresh).done(function (data) {
					defer.resolve();
				}).fail(function (msg) {
					defer.reject(msg);
				});
			}).done(function () {
				sap.m.MessageToast.show("Email has been sent successfully");
			}).fail();
			return deferred;
		},
		//-->Export Wrong Part IDs  

		handleExportErrorPartIDs: function () {
			var export1 = new Export({
				exportType: new ExportTypeCSV({
					charset: "utf-16"
				}),
				models: vc.view.getModel("importErrors"),
				rows: {
					path: "/"
				},
				columns: [{
					name: "Line #",
					template: {
						content: {
							path: "StructuredLineID"
						}
					}
				}, {
					name: "Qty",
					template: {
						content: {
							path: "QTY"
						}
					}
				}, {
					name: "Manufacturer ID",
					template: {
						content: {
							path: "ManufacturerID"
						}
					}
				}, {
					name: "Manufacturer",
					template: {
						content: {
							path: "ManufacturerID",
							formatter: formatter.mfrName
						}
					}
				}, {
					name: "Part # Requested",
					template: {
						content: {
							path: "CustomerPartID"
						}
					}
				}, {
					name: "Description",
					template: {
						content: {
							path: "Description"
						}
					}
				}, {
					name: "List Price",
					template: {
						content: {
							path: "ListPrice"
						}
					}
				}]
			});

			var row = new sap.ui.core.util.ExportRow("Notes", {
				cells: [new sap.ui.core.util.ExportCell({
					content: "Note"
				}), new sap.ui.core.util.ExportCell({
					content: "Please Take care"
				})]
			});

			export1.addRow(row);
			var dateTime = new Date().toLocaleString().split(",").join("_").replace(/\s+/g, "");
			var fileNameExt = (vc.view.getModel("currentSalesDocument").getProperty("/SalesDocumentID") === "0000000000") ? "New Document" : vc
				.view.getModel("currentSalesDocument").getProperty("/SalesDocumentID");
			export1.saveFile(fileNameExt + "_PartIDs_ImportError_" + dateTime).always(function () {
				vc.destroy();
			});
		},

		//End of Change: 09/06/16: SXVASAMSETTI                   
		handleDetailLineNotes: function (event) {
			var dialog = vc.view.byId("detailLineNotesDialog"),
				source = event.getSource(),
				binding = source.getBinding("color"),
				context = binding.getContext(),
				model = binding.getModel(),
				row = model.getProperty(context.getPath()),
				saveRow = jQuery.extend(true, {}, row);

			dialog.removeAllButtons();

			dialog.addStyleClass("sapUiSizeCompact");
			dialog.addButton(new sap.m.Button({
				text: "OK",
				enabled: "{currentState>/isEditMode}",
				press: function () {
					var hasNotes = (row.VendorDeliveryNotes || row.BillingNotes) ? true : false;

					model.setProperty(context.getPath() + "/HasNotesFlag", hasNotes);
					dialog.close();
				}
			}));
			dialog.addButton(new sap.m.Button({
				text: "Cancel",
				press: function () {
					model.setProperty(context.getPath(), saveRow);

					dialog.close();
				}
			}));

			vc.view.setModel(new sap.ui.model.json.JSONModel(row), "currentLine");

			dialog.open();
		},

		_makeTotalConfiguredItemLikeThis: function (row, model, propertyNames, vendorID) {
			var ultimateParentLineID = vc._findUltimateParentLineID(row, model.getData()),
				configuredItemRows = vc._createIndexChainFromParent(ultimateParentLineID, model.getData(), []),
				properties;

			if (typeof propertyNames === "string") {
				properties = [propertyNames];
			} else {
				properties = propertyNames;
			}

			_.each(configuredItemRows, function (item, index, list) {
				_.each(properties, function (property) {
					var val = row[property];
					if (!model.getProperty("/" + item + "/MarkedAsDeleted") && (!vendorID || (model.getProperty("/" + item + "/VendorID") ===
							vendorID))) {
						if (property === "ItemCategory") {
							if (formatter.itemCategoryToStaging(row.ItemCategory)) {
								val = vc._determineItemCategoryForStaging(model.getProperty("/" + item));
							} else {
								if (formatter.itemCategoryToDropShip(row.ItemCategory)) {
									val = vc._determineItemCategoryForDropShip(model.getProperty("/" + item));
								} else {
									val = vc._determineItemCategoryForBroughtIn(model.getProperty("/" + item));
								}
							}

						}
						if (property === "DummyLineId") {
							val = model.getProperty("/" + item + "/SalesDocumentLineID") + row.ShipToID;
						}

						model.setProperty("/" + item + "/" + property, val);
					}
				});
			});

		},

		_makeChildItemsLikeThis: function (row, model, propertyNames) {
			var children = vc._findAllChildren(row.SalesDocumentLineID, model.getData()),
				properties;

			if (typeof propertyNames === "string") {
				properties = [propertyNames];
			} else {
				properties = propertyNames;
			}

			_.each(children, function (item, index, list) {
				var rowIdx = _.findIndex(model.getData(), function (row) {
					return row.SalesDocumentLineID === item.SalesDocumentLineID;
				});
				_.each(properties, function (property) {
					var val = row[property];
					if (!model.getProperty("/" + rowIdx + "/MarkedAsDeleted")) {
						if (property === "ItemCategory") {
							if (formatter.itemCategoryToStaging(row.ItemCategory)) {
								val = vc._determineItemCategoryForStaging(model.getProperty("/" + rowIdx));
							} else {
								if (formatter.itemCategoryToDropShip(row.ItemCategory)) {
									val = vc._determineItemCategoryForDropShip(model.getProperty("/" + rowIdx));
								} else {
									val = vc._determineItemCategoryForBroughtIn(model.getProperty("/" + rowIdx));
								}
							}

						}
						model.setProperty("/" + rowIdx + "/" + property, val);
					}
				});
			});

		},

		_createIndexChainFromParent: function (parentLineID, rows, array) {
			var idx = _.findIndex(rows, {
				SalesDocumentLineID: parentLineID
			});

			if (idx !== -1) {
				array.push(idx);
				_.each(rows, function (row, index, list) {
					if (row.ParentLineID === parentLineID) {
						array = vc._createIndexChainFromParent(row.SalesDocumentLineID, list, this);
					}
				}, array);
			}

			return array;
		},

		_findUltimateParentLineID: function (row, rows) {
			var parentLine = null;

			if (!row.ParentLineID || parseInt(row.ParentLineID) === 0) {
				return row.SalesDocumentLineID;
			}

			parentLine = _.findWhere(rows, {
				SalesDocumentLineID: row.ParentLineID
			});

			if (!parentLine) {
				return row.SalesDocumentLineID;
			}

			return vc._findUltimateParentLineID(parentLine, rows);
		},

		_isEmpty: function () {
			var details = vc.view.getModel("currentSalesDocumentLines").getData();

			if (!details || details.length === 0) {
				return true;
			}

			if (details.length > 1) {
				return false;
			}

			if (!details[0].MaterialID) {
				return true;
			}

			return false;
		},

		handleChangeHeaderCustomerPOID: function (event) {
			var source = event.getSource(),
				binding = source.getBinding("value"),
				row = {},
				customerPOID = source.getValue(),
				lineModel = vc.view.getModel("currentSalesDocumentLines"),
				lines = lineModel.getData();

			if (Boolean(customerPOID)) {
				customerPOID = customerPOID;
				binding.setValue(customerPOID);
			}

			for (var i = 0, len = (Boolean(lines)) ? lines.length : 0; i < len; i++) {
				row = lines[i];
				if (!row.WBSElement) {
					row.CustomerPOID = customerPOID;
				}
			}

			lineModel.refresh(true);

		},

		handleChangeHeaderReqDate: function (event) {
			var source = event.getSource(),
				binding = source.getBinding("dateValue"),
				row = {},
				reqdate = binding.getValue(),
				lineModel = vc.view.getModel("currentSalesDocumentLines"),
				lines = lineModel.getData();

			for (var i = 0, len = (Boolean(lines)) ? lines.length : 0; i < len; i++) {
				row = lines[i];
				if (!row.WBSElement) {
					row.DeliveryDate = reqdate;
				}
			}

			lineModel.refresh(true);

		},

		_findPartnerID: function (value, collection) {
			var partner = _.findWhere(
				_.map(core.getModel("customerSelectItems").getProperty("/" + collection), function (n) {
					return {
						PartnerID: n.PartnerID,
						text: ((n.PartnerID) ? parseInt(n.PartnerID, 10) + " - " : "") + ((n.PartnerName) ? n.PartnerName : "") + ((n.Street) ? ", " +
							n.Street : "") + ((n.Street2) ? ", " + n.Street2 : "") + ((n.Street3) ? ", " + n.Street3 : "") + ((n.Street4) ? ", " + n.Street4 :
							"") + ((n.City) ? ", " + n.City : "") + ((n.State) ? ", " + n.State : "") + ((n.Zip) ? ", " + n.Zip : "") + ((n.Country) ?
							", " + n.Country : "")
					};
				}), {
					text: value
				});

			return (partner) ? partner.PartnerID : 0;
		},

		handleChangeHeaderShipTo: function (event) {
			var source = event.getSource(),
				row = {},
				model = vc.view.getModel("currentSalesDocument"),
				lineModel = vc.view.getModel("currentSalesDocumentLines"),
				partnerID = vc._findPartnerID(source.getValue(), "ShipTos"),
				lines = lineModel.getData();

			if (!partnerID) {
				source.setTooltip("Ship To Party does not exist.  Please select from the displayed options.");
				source.setValueState(sap.ui.core.ValueState.Error);
				event.preventDefault();
				return;
			}

			source.setValueState(sap.ui.core.ValueState.None);
			source.setTooltip();

			model.setProperty("/ShipToID", partnerID);
			model.setProperty("/Shstaddrid", "");

			sap.m.MessageBox.confirm("Do you wish to reset all detail lines to this Ship To address?", function (confirmation) {
				if (confirmation !== "CANCEL") {
					for (var i = 0, len = (Boolean(lines)) ? lines.length : 0; i < len; i++) {
						row = lines[i];
						if (!row.WBSElement) {
							row.ShipToID = partnerID;
							row.Shstaddrid = "";
						}
					}

					lineModel.refresh(true);
				}
			}, "Change all detail lines?");
		},

		handleChangeHeaderBillTo: function (event) {
			var source = event.getSource(),
				model = vc.view.getModel("currentSalesDocument"),
				partnerID = vc._findPartnerID(source.getValue(), "BillTos");

			if (!partnerID) {
				source.setTooltip("Bill To Party does not exist.  Please select from the displayed options.");
				source.setValueState(sap.ui.core.ValueState.Error);
				event.preventDefault();
				return;
			}

			source.setValueState(sap.ui.core.ValueState.None);
			source.setTooltip();

			model.setProperty("/BillToID", partnerID);

		},

		handleChangeHeaderPayer: function (event) {
			var source = event.getSource(),
				model = vc.view.getModel("currentSalesDocument"),
				partnerID = vc._findPartnerID(source.getValue(), "Payers");

			if (!partnerID) {
				source.setTooltip("Payer does not exist.  Please select from the displayed options.");
				source.setValueState(sap.ui.core.ValueState.Error);
				event.preventDefault();
				return;
			}

			source.setValueState(sap.ui.core.ValueState.None);
			source.setTooltip();

			model.setProperty("/PayerID", partnerID);

		},

		handleChangeHeaderEndCustomer: function (event) {
			var source = event.getSource(),
				model = vc.view.getModel("currentSalesDocument"),
				partnerID = vc._findPartnerID(source.getValue(), "EndCustomers");

			if (!partnerID) {
				source.setTooltip("End Customer does not exist.  Please select from the displayed options.");
				source.setValueState(sap.ui.core.ValueState.Error);
				event.preventDefault();
				return;
			}

			source.setValueState(sap.ui.core.ValueState.None);
			source.setTooltip();

			model.setProperty("/EndCustomerID", partnerID);

		},

		handleSuggestPartner: function (event) {
			var term = event.getParameter("suggestValue"),
				source = event.getSource(),
				binding = source.getBinding("value"),
				partners = null,
				path = binding.getPath(),
				suggestions = [];

			if (!path && !!binding.getBindings()) {
				binding = binding.getBindings()[0];
				path = binding.getPath();
			}
			if (path && path[0] !== "/") {
				path = "/" + path;
			}

			if (path === "/DummyLineId") {
				path = "/ShipToID";
			}; // this is from Items

			switch (path) {
			case "/ShipToID":
				partners = vc.view.getModel("customerSelectItems").getData()["ShipTos"];
				break;
			case "/BillToID":
				partners = vc.view.getModel("customerSelectItems").getData()["BillTos"];
				break;
			case "/PayerID":
				partners = vc.view.getModel("customerSelectItems").getData()["Payers"];
				break;
			case "/EndCustomerID":
				partners = vc.view.getModel("customerSelectItems").getData()["EndCustomers"];
				break;
			}

			if (partners) {
				suggestions = $.grep(partners, function (n) {
					var target = ((n.PartnerID) ? parseInt(n.PartnerID, 10) + " - " : "") + ((n.PartnerName) ? n.PartnerName : "") + ((n.Street) ?
						", " + n.Street : "") + ((n.Street2) ? ", " + n.Street2 : "") + ((n.Street3) ? ", " + n.Street3 : "") + ((n.Street4) ? ", " +
						n.Street4 : "") + ((n.City) ? ", " + n.City : "") + ((n.State) ? ", " + n.State : "") + ((n.Zip) ? ", " + n.Zip : "") + ((n.Country) ?
						", " + n.Country : "");
					return target.match(new RegExp(term, "i"));
				});
			}

			source.destroySuggestionItems();
			for (var i = 0, len = (Boolean(suggestions)) ? suggestions.length : 0; i < len; i++) {
				source.addSuggestionItem(new sap.ui.core.Item({
					text: parseInt(suggestions[i].PartnerID, 10) + " - " + suggestions[i].PartnerName + ((suggestions[i].Street) ? ", " +
						suggestions[i].Street : "") + ((suggestions[i].Street2) ? ", " + suggestions[i].Street2 : "") + ((suggestions[i].Street3) ?
						", " + suggestions[i].Street3 : "") + ((suggestions[i].Street4) ? ", " + suggestions[i].Street4 : "") + ((suggestions[i].City) ?
						", " + suggestions[i].City : "") + ((suggestions[i].State) ? ", " + suggestions[i].State : "") + ((suggestions[i].Zip) ?
						", " + suggestions[i].Zip : "") + ((suggestions[i].Country) ? ", " + suggestions[i].Country : "")
				}));
			}
		},

		handleMfrHelp: function (controller) {
			vc.inputId = controller.oSource.sId;
			// create value help dialog
			if (!vc._valueHelpDialog) {
				vc._valueHelpDialog = sap.ui.xmlfragment(
					"gdt.salesui.s4.fragment.DetailMfrSelectDialog",
					vc
				);
				vc.view.addDependent(vc._valueHelpDialog);
			}

			// open value help dialog
			vc._valueHelpDialog.open();
		},

		handleMfrHelpSearch: function (evt) {
			var value = evt.getParameter("value");
			var filter = new sap.ui.model.Filter(
				"ManufacturerName",
				sap.ui.model.FilterOperator.Contains, value
			);
			evt.getSource().getBinding("items").filter([filter]);
		},

		handleMfrHelpClose: function (evt) {
			var selectedItem = evt.getParameter("selectedItem"),
				details = vc.view.getModel("currentSalesDocumentLines");
			if (selectedItem) {

				var control = vc.view.byId(vc.inputId),
					rowid = control.data("rowid"),
					row = {},
					binding = control.getBinding("value");
				binding.setValue(selectedItem.getDescription());
				if (binding.getPath() === "ManufacturerID") {
					row = vc._findRow(rowid)[0];
					row.VendorID = selectedItem.getDescription();
					details.refresh(false);
				}
			}
			evt.getSource().getBinding("items").filter([]);
		},

		_pad: function (n, width, z) {
			var paddingChar = z || "0",
				stringToPad = n + "";
			return stringToPad.length >= width ? stringToPad : new Array(width - stringToPad.length + 1).join(paddingChar) + stringToPad;
		},

		handleAddDetailLine: function () {
			var details = vc.view.getModel("currentSalesDocumentLines"),
				detailsArray = details.getData(),
				ui5tbl = vc.view.byId("lineItemsTable"),
				tbl = $("#" + vc.view.byId("lineItemsTable").getId()),
				startRow = ui5tbl.getFirstVisibleRow(),
				numRows = $(tbl).find("tr:not(:has(th))").length;

			detailsArray.push(vc._createNewLine());
			details.refresh(false);

			setTimeout(function () {
				if (startRow < detailsArray.length - numRows) {
					ui5tbl.setFirstVisibleRow(detailsArray.length - numRows);
				}
			}, 1000);
		},

		_createNewLine: function (detailsArray) {
			var salesDocument = (Boolean(vc.view.getModel("currentSalesDocument"))) ? vc.view.getModel("currentSalesDocument") : core.getModel(
					"currentSalesDocument"),
				salesDocumentID = salesDocument.getProperty("/SalesDocumentID"),
				deliveryDate = salesDocument.getProperty("/RequestedDeliveryDate"),
				shipToID = salesDocument.getProperty("/ShipToID"),
				wbsElement = salesDocument.getProperty("/WBSElement"),
				otstAddressID = salesDocument.getProperty("/OTSTAddressID"),
				otstCity = salesDocument.getProperty("/OTSTCity"),
				otstName = salesDocument.getProperty("/OTSTName"),
				otstPhone = salesDocument.getProperty("/OTSTPhone"),
				otstState = salesDocument.getProperty("/OTSTState"),
				otstStreet = salesDocument.getProperty("/OTSTStreet"),
				otstZip = salesDocument.getProperty("/OTSTZip"),
				customerPOID = salesDocument.getProperty("/CustomerPOID"),
				maxLineNum = 0,
				newLine = jQuery.extend(true, {}, core.getModel("blankDetailLine").getData()),
				userid = core.getModel("systemInfo").getProperty("/Uname"),
				today = new Date(Date.now()),
				maxStructuredLineNum = 0;

			if (!detailsArray) {
				detailsArray = (Boolean(vc.view.getModel("currentSalesDocumentLines"))) ? vc.view.getModel("currentSalesDocumentLines").getData() :
					core.getModel("currentSalesDocumentLines").getData();
			}

			for (var key in detailsArray) {
				var lineNum = (Boolean(detailsArray[key].SalesDocumentLineID)) ? parseInt(detailsArray[key].SalesDocumentLineID) : 0,
					// Begin of Change : SXVASAMSETTI : Number of Line Items
					//structuredLineNum = (!!detailsArray[key].StructuredLineID) ? parseInt(detailsArray[key].StructuredLineID.substring(0,detailsArray[key].StructuredLineID.indexOf('.'))) : 0;
					structuredLineNum = (Boolean(detailsArray[key].StructuredLineID)) ? parseInt(detailsArray[key].StructuredLineID) : 0;
				// End of Change : SXVASAMSETTI				
				if (lineNum > maxLineNum) {
					maxLineNum = lineNum;
				}
				if (structuredLineNum > maxStructuredLineNum) {
					maxStructuredLineNum = structuredLineNum;
				}
			}

			newLine.QTY = "1";
			newLine.SmartNetDuration = "";
			newLine.MaterialGroup = "Z2"; // Default to Hardware
			newLine.SalesDocumentLineID = vc._pad(maxLineNum + 10, 6);
			newLine.StructuredLineID = (maxStructuredLineNum + 1).toString() + ".0";
			newLine.SalesDocumentID = salesDocumentID;
			newLine.SalesDocumentID = salesDocument.getProperty("/SalesDocumentID");
			newLine.CustomerPOLineID = (maxLineNum + 10).toString();
			newLine.DeliveryDate = deliveryDate;
			newLine.ShipToID = shipToID;
			newLine.DummyLineId = newLine.SalesDocumentLineID + newLine.ShipToID;
			newLine.ItemCategory = vc._determineItemCategoryForDropShip(newLine);
			newLine.WBSElement = wbsElement;

			newLine.OTSTAddressID = otstAddressID;
			newLine.OTSTCity = otstCity;
			newLine.OTSTName = otstName;
			newLine.OTSTPhone = otstPhone;
			newLine.OTSTState = otstState;
			newLine.OTSTStreet = otstStreet;
			newLine.OTSTZip = otstZip;

			newLine.Shstaddrid = salesDocument.getProperty("/Shstaddrid");
			newLine.Shstname = salesDocument.getProperty("/Shstname");
			newLine.Shststreet = salesDocument.getProperty("/Shststreet");
			newLine.Shststreet2 = salesDocument.getProperty("/Shststreet2");
			newLine.Shststreet3 = salesDocument.getProperty("/Shststreet3");
			newLine.Street4 = salesDocument.getProperty("/Street4");
			newLine.Shstcity = salesDocument.getProperty("/Shstcity");
			newLine.Shststate = salesDocument.getProperty("/Shststate");
			newLine.Shstzip = salesDocument.getProperty("/Shstzip");
			newLine.Shstcountry = salesDocument.getProperty("/Shstcountry");

			newLine.CustomerPOID = customerPOID;
			newLine.CreatedBy = userid;
			newLine.CreatedOn = today;
			newLine.UpdatedBy = userid;
			newLine.LastUpdatedOn = today;
			newLine.Selected = true;
			return newLine;
		},

		handleDeleteButtonPress: function () {
			var currentState = core.getModel("currentState"),
				currentDocument = core.getModel("currentSalesDocument");

			sap.m.MessageBox.confirm("Are you sure you wish to delete vc " +
				(currentState.getProperty("/isQuote") ? "Quote?" : "Sales Order?") +
				".  this operation cannot be undone!",
				function (confirmation) {
					if (confirmation !== "CANCEL") {
						datacontext.salesdocuments.remove(currentDocument.getProperty("/SalesDocumentID")).done(function () {
							core.getModel("currentState").setProperty("/isEditMode", false);
							core.getModel("currentState").setProperty("/isNotEditMode", true);
							vc.eventBus.publish("master", "salesDocAltered", currentDocument.getData());
							vc._exit();
						}).fail(function (err) {
							var uniqueList = err.split("\n").filter(function (item, i, allItems) {
								return i === allItems.indexOf(item);
							}).join(",");
							var msg;
							if (uniqueList) {
								msg = uniqueList;
							}
							MessageBox.show((msg) ? msg : "SalesUI Could not delete vc Document from SAP.", {
								icon: MessageBox.Icon.ERROR,
								title: "SAP Error",
								actions: MessageBox.Action.OK,
								onClose: null
							});
						});
					}
				}, "Confirm Delete Document");
		},

		_deleteDetailLines: function () {
			var deferred,
				currentDocumentLines = core.getModel("currentSalesDocumentLines"),
				rows = currentDocumentLines.getData(),
				linesToDelete = _.where(rows, {
					DeletedFlag: true
				}),
				l = (Boolean(linesToDelete)) ? linesToDelete.length : 0;

			deferred = $.Deferred(function (def) {
				if (l > 0) {
					sap.m.MessageBox.confirm("Are you sure you wish to delete these " + l + " line items?", function (confirmation) {
						if (confirmation !== "CANCEL") {
							_.each(rows, function (row) {
								if (!!row.DeletedFlag && !!row.ReasonForRejection) {
									row.MarkedAsDeleted = true;
									row.DeletedFlag = false;
								}
							});
							currentDocumentLines.setData(_.reject(rows, function (row) {
								return row.DeletedFlag;
							}));
							vc.view.setModel(core.getModel("currentSalesDocumentLines"), "currentSalesDocumentLines");
							vc._calculateTotals();
							def.resolve();
						} else {
							def.reject("Delete lines canceled");
						}
					}, "Confirm Delete Line");
				} else {
					def.resolve();
				}
			});

			return deferred.promise();
		},

		handlePartIDHelp: function (event) {
			var dialog = vc.view.byId("detailLinePartSearchDialog"),
				busy = vc.view.byId("partSearchBusy"),
				searchFn = null,
				source = event.getSource(),
				binding = source.getBinding("value"),
				context = binding.getContext(),
				model = binding.getModel(),
				row = model.getProperty(context.getPath()),
				saveRow = jQuery.extend(true, {}, row),
				OrgData = core.getModel("userPref").getData(),
				manufacturerPartID = source.getValue().toUpperCase();

			dialog.addStyleClass("sapUiSizeCompact");

			dialog.attachEventOnce("confirm", null, function (evt) {
				var mfrPartID = evt.getParameter("selectedItem").getCells()[0].getText(),
					mfrID = _.findWhere(vc.view.getModel("globalSelectItems").getProperty("/Manufacturers"), {
						ManufacturerName: evt.getParameter("selectedItem").getCells()[1].getText()
					}).ManufacturerID;

				model.setProperty(context.getPath() + "/" + binding.getPath(), mfrPartID);
				if (binding.getPath() === "CustomerPartID" && model.getProperty(context.getPath() + "/ManufacturerID") !== mfrID) {
					model.setProperty(context.getPath() + "/ManufacturerID", mfrID);
				}
				source.setValue(mfrPartID);
				vc._doChangePartID(source);
			});

			searchFn = function (evt) {
				var value = evt.getParameter("value");

				value = value.toUpperCase();

				busy.open();
				setTimeout(function () {
					core.getModel().read("/MaterialsSet?$filter=CustomerId eq '' and Vkorg eq '" + OrgData.Vkorg + "' and Vtweg eq '" + OrgData.Vtweg +
						"' and ManufacturerNo eq '" + row.ManufacturerID + "' and ManufacturerPartId eq'" + value + "'and ALL eq 'S'", {
							success: function (data, response) {
								var globalSelectItems = vc.view.getModel("globalSelectItems");
								data.results.unshift({
									MfrpartId: "",
									Description: "",
									ListPrice: "",
									ManufacturerNo: ""
								});
								globalSelectItems.setProperty("/MaterialsSet", data.results);
								setTimeout(function () {
									busy.close();
								});
							},
							error: function (data, response) {
								setTimeout(function () {
									busy.close();
								});
							}

						});
				});

				dialog.attachEventOnce("search", null, searchFn);
				dialog.attachEventOnce("change", null, searchFn);
			};

			event.getParameters().value = manufacturerPartID;
			searchFn(event);

			dialog.attachEventOnce("cancel", null, function () {
				model.setProperty(context.getPath(), saveRow);
			});

			setTimeout(function () {
				core.getModel().read("/MaterialsSet?$filter=CustomerId eq '' and Vkorg eq '" + OrgData.Vkorg + "' and Vtweg eq '" + OrgData.Vtweg +
					"' and ManufacturerNo eq '" + row.ManufacturerID + "' and ManufacturerPartId eq'" + manufacturerPartID + "'and ALL eq 'S'", {
						success: function (data, response) {
							var globalSelectItems = vc.view.getModel("globalSelectItems");
							data.results.unshift({
								MfrpartId: "",
								Description: "",
								ListPrice: "",
								ManufacturerNo: ""
							});
							globalSelectItems.setProperty("/MaterialsSet", data.results);
							dialog.setBusy(false);
						},
						error: function (data, response) {
							dialog.setBusy(false);
						}

					});
			});

			dialog.open(manufacturerPartID);
		},

		handleChangePartID: function (event) {
			vc._doChangePartID(event.getSource());
		},

		_calculateExtendedValue: function (row, qty, unitValue) {
			var extendedValue = unitValue * qty;

			return Math.round(extendedValue * 100.0) / 100.0; // round to pennies
		},

		_lookupPartID: function (row, manufacturerPartID, override, isCustomerPartID, success, fail, localOnly) {
			var key = {
					CustomerID: core.getModel("currentCustomer").getProperty("/CustomerID"),
					ManufacturerID: row.ManufacturerID,
					MaterialID: "",
					MfrPartID: (Boolean(manufacturerPartID)) ? (($.isNumeric(manufacturerPartID)) ? manufacturerPartID.toUpperCase().trim().replace(
						/^0+/, '') : manufacturerPartID.toUpperCase().trim()) : ''
				},
				copyRow = jQuery.extend(true, {}, row),
				def = null,
				localVal = null,
				successFn = function (data, success, deferred) {
					var listPrice = parseFloat((override) ? data.ListPrice : row.ListPrice),
						materialID = (Boolean(data.MaterialID)) ? data.MaterialID.replace(/^0+/, '') : null,
						vdrMatch = null,
						mfr = null,
						mfrs = vc.view.getModel("globalSelectItems").getData()["Manufacturers"] || [],
						vdrs = vc.view.getModel("globalSelectItems").getData()["Vendors"] || [],
						gdtDiscount = parseFloat((override) ? ((Boolean(data.GDTDiscount)) ? data.GDTDiscount : 0.00) : row.GDTDiscount),
						gdtDiscountPercent = (listPrice !== 0) ? (gdtDiscount * -100 / listPrice) : 0.00,
						qty = parseFloat(row.QTY),
						unitCost = Math.round((listPrice + gdtDiscount) * 100.0) / 100.0,
						customerDiscount = parseFloat((override) ? ((Boolean(data.CustomerDiscount)) ? data.CustomerDiscount : 0.00) : row.CustomerDiscount),
						customerDiscountPercent = (listPrice !== 0) ? (customerDiscount * -100 / listPrice) : 0.00,
						unitPrice = Math.round((listPrice + customerDiscount) * 100.0) / 100.0,
						extendedCost,
						extendedPrice,
						grossProfit,
						grossProfitPercentage;

					if (!override) {
						if (Boolean(row.GDTDiscountPercent)) {
							gdtDiscountPercent = row.GDTDiscountPercent;
							gdtDiscount = Math.round(listPrice * gdtDiscountPercent) / -100.0;
							unitCost = Math.round((listPrice + gdtDiscount) * 100.0) / 100.0;
						}

						if (Boolean(row.CustomerDiscountPercent)) {
							customerDiscountPercent = row.CustomerDiscountPercent;
							customerDiscount = Math.round(listPrice * customerDiscountPercent) / -100.0;
							unitPrice = Math.round((listPrice + customerDiscount) * 100.0) / 100.0;
						}
					}

					extendedCost = vc._calculateExtendedValue(row, qty, unitCost);
					extendedPrice = vc._calculateExtendedValue(row, qty, unitPrice);
					grossProfit = extendedPrice - extendedCost;
					grossProfitPercentage = (extendedPrice > 0) ? Math.round(((grossProfit / extendedPrice) * 100.0) * 1000.0) / 1000.0 : 0.0;

					if (materialID && materialID !== "") {
						row.MaterialGroup = data.MaterialGroup;
						row.MARAMaterialGroup = data.MARA_MaterialGroup;
						row.EDelivery = data.EDelivery;
						row.ListPrice = listPrice.toString();
						row.UnitCost = unitCost.toString();
						row.ExtendedCost = extendedCost.toString();
						row.UnitPrice = unitPrice.toString();
						row.ExtendedPrice = extendedPrice.toString();
						row.GrossProfitPercentage = grossProfitPercentage.toString();
						row.GrossProfit = grossProfit.toString();
						row.GDTDiscount = gdtDiscount.toString();
						row.CustomerDiscount = customerDiscount.toString();
						row.GDTDiscountPercent = gdtDiscountPercent.toString();
						row.CustomerDiscountPercent = customerDiscountPercent.toString();
						if (isCustomerPartID) {
							row.ManufacturerID = data.ManufacturerID;
							row.CustomerPartID = data.MfrPartID;
							row.CustomerMaterialID = materialID;
							row.ManufacturerPartID = row.CustomerPartID;
							row.MaterialID = materialID;
							row.Description = (override) ? data.Description : (row.Description) ? row.Description : data.Description;
							if (!row.VendorID) {
								row.VendorID = data.DefaultVendorID;
								if (!row.VendorID) {
									mfr = _.findWhere(mfrs, {
										ManufacturerID: row.ManufacturerID
									});
									if (mfr) {
										vdrMatch = _.findWhere(vdrs, {
											SortL: mfr.SortL
										});
										if (vdrMatch) {
											row.VendorID = vdrMatch.ManufacturerID;
										}
									}
								}
							} else if (row.VendorID === "Error") {
								row.VendorID = "";
							}
						} else {
							row.MaterialID = materialID;
							row.ManufacturerPartID = data.MfrPartID;
						}
					} else {
						if (!isCustomerPartID) {
							row.MaterialID = null;
						} else {
							row.CustomerMaterialID = null;
						}
					}

					if (formatter.itemCategoryToStaging(row.ItemCategory)) {
						row.ItemCategory = vc._determineItemCategoryForStaging(row);
					} else {
						if (formatter.itemCategoryToDropShip(row.ItemCategory)) {
							row.ItemCategory = vc._determineItemCategoryForDropShip(row);
						} else {
							row.ItemCategory = vc._determineItemCategoryForBroughtIn(row);
						}
					}

					if (Boolean(success)) {
						success(row);
					}

					if (Boolean(deferred)) {
						deferred.resolve(row);
					}

					return row;
				},
				failFn = function (data, fail, deferred) {
					var response = null,
						message = "",
						error = {},
						errordetails = [],
						msg = "SalesUI Could not fetch the material details for " + manufacturerPartID + " from SAP.";

					if (data && data.response && data.response.body) {
						response = $.parseJSON(data.response.body);
					}

					if (response && response.error) {
						error = response.error;
						if (error.innererror && error.innererror.errordetails && error.innererror.errordetails.length > 0) {
							errordetails = error.innererror.errordetails;
							for (var i = 0, len = errordetails.length; i < len; i++) {
								if (errordetails[i].message && errordetails[i].message.length > 0) {
									if (message.length !== 0) {
										message += "\n";
									}
									message += errordetails[i].message;
								}
							}
							msg = message;
						} else {
							if (response.error.message && response.error.message.value) {
								msg = response.error.message.value;
							}
						}
					}

					if (Boolean(fail)) {
						fail(row);
					}

					if (Boolean(deferred)) {
						deferred.resolve(row); // Do not reject promise...otherwise all other updates will fail.
						sap.m.MessageToast.show(msg);
					}

					return row;
				};

			if (key.MfrPartID.length === 0) {
				if (!localOnly) {
					return $.Deferred(function (defer) {
						defer.resolve(row);
					});
				}
				return null;
			}

			if (key.MfrPartID.length === 9 && parseInt(key.MfrPartID).toString() === key.MfrPartID) { // GDT SAP Material ID
				key.MaterialID = key.MfrPartID;
				key.MfrPartID = "";
			}

			if (!localOnly) {
				def = $.Deferred(function (deferred) {
					datacontext.materials.get(key)
						.done(function (data) {
							successFn(data, success, deferred);
						}).fail(function (data) {
							failFn(data, fail, deferred);
						});
				});
				return def.promise();
			}

			localVal = datacontext.materials.getLocal(key);

			if (Boolean(localVal)) {
				return successFn(localVal);
			}

			return failFn("Material " + key.MfrPartID + " not found");

		},

		_doChangePartID: function (source) {

			var binding = source.getBinding("value"),
				context = binding.getContext(),
				rowModel = binding.getModel(),
				row = (context) ? rowModel.getProperty(context.getPath()) : rowModel.getData(),
				copyRow = jQuery.extend(true, {}, row),
				manufacturerPartID = source.getValue().toUpperCase(),
				page = vc.view.byId("detailPage"),
				isCustomerPartID = (binding.getPath() === "CustomerPartID");

			page.setBusyIndicatorDelay(0);
			page.setBusy(true);

			setTimeout(function () {

				vc._lookupPartID(row, manufacturerPartID, true, isCustomerPartID, function (data) {
					if ((isCustomerPartID && data.CustomerMaterialID) || (!isCustomerPartID && data.MaterialID)) {
						source.setValueState(sap.ui.core.ValueState.None);
						source.setTooltip();

						data.HasDistroFlag = (data.ManufacturerID !== data.VendorID || vc._pad(data.MaterialID, 18) !== vc._pad(data.CustomerMaterialID,
							18));

						/// Restrict to add Materials with 4 Series to UI					
						if (row.ItemCategory === "ZPFS" || row.ItemCategory === "YTAO" || row.ItemCategory === "ZTAO") {

							copyRow.CustomerPartID = "";
							copyRow.CustomerMaterialID = "";
							copyRow.ManufacturerPartID = "";
							copyRow.ManufacturerID = "";
							copyRow.ShipToID = "";
							MessageBox.show(
								"Sales UI does not allow you to add materials starts with 4 Series ( Professional Services ). These materials are only maintained from SAP GUI by Projects/Launch team", {
									icon: MessageBox.Icon.ERROR,
									title: "Authorizaton Issue",
									actions: MessageBox.Action.OK,
									onClose: null
								});
							if (context) {
								rowModel.setProperty(context.getPath(), copyRow);
							} else {
								rowModel.setData(copyRow);
							}
							page.setBusy(false);
							return;
						}

						if (context) {
							rowModel.setProperty(context.getPath(), data);
						} else {
							rowModel.setData(data);
						}

						if (formatter.itemCategoryToStaging(data.ItemCategory)) {
							data.ItemCategory = vc._determineItemCategoryForStaging(data);
						} else {
							if (formatter.itemCategoryToDropShip(data.ItemCategory)) {
								data.ItemCategory = vc._determineItemCategoryForDropShip(data);
							} else {
								data.ItemCategory = vc._determineItemCategoryForBroughtIn(data);
							}
						}
						vc._calculateTotals();
					} else {
						source.setTooltip(
							"Part number does not exist in the Master Data for this Manufacturer.  If you believe it is correct, please contact the Master Data Maintenance group."
						);
						source.setValueState(sap.ui.core.ValueState.Error);
					}
					page.setBusy(false);
				}, function () {
					source.setTooltip(
						"Part number does not exist in the Master Data for this Manufacturer.  If you believe it is correct, please contact the Master Data Maintenance group."
					);
					source.setValueState(sap.ui.core.ValueState.Error);
					page.setBusy(false);
				});
			});
		},

		_findTrForRow: function (row) {
			var ui5tbl = vc.view.byId("lineItemsTable"),
				data = vc.view.getModel("currentSalesDocumentLines").getData(),
				startRow = ui5tbl.getFirstVisibleRow(),
				lastRow = 0,
				//	numRows = (data) ? data.length : 0,
				tbl = $('#' + vc.view.byId("lineItemsTable").getId()),
				currentDocumentLines = vc.view.getModel("currentSalesDocumentLines").getData(),
				rowidx = _.findIndex((currentDocumentLines) ? vc.view.getModel("currentSalesDocumentLines").getData() : [], {
					StructuredLineID: row.StructuredLineID
				});

			if (!tbl || rowidx < 0) {
				return null;
			}

			if (rowidx < startRow) {
				return null;
			}

			rowidx -= startRow;
			rowidx = rowidx + 1; // S/4 hana Change

			lastRow = $(tbl).find('tr:not(:has(th))').length - 1;

			if (rowidx > lastRow) {
				return null;
			}

			return $(tbl).find('tr:not(:has(th))')[rowidx];
		},

		_findTrForRowInUnfrozenSection: function (row) {
			var ui5tbl = vc.view.byId("lineItemsTable"),
				data = vc.view.getModel("currentSalesDocumentLines").getData(),
				startRow = ui5tbl.getFirstVisibleRow(),
				lastRow = 0,
				//	numRows = (data) ? data.length : 0,
				tbl = $("#" + vc.view.byId("lineItemsTable").getId()),
				$parent = $(tbl).closest("div"),
				$tbls = $parent.find("table"),
				currentDocumentLines = vc.view.getModel("currentSalesDocumentLines").getData(),
				rowidx = _.findIndex((currentDocumentLines) ? vc.view.getModel("currentSalesDocumentLines").getData() : [], {
					SalesDocumentLineID: row.SalesDocumentLineID
				});

			if (!tbl || rowidx < 0) {
				return null;
			}

			if ($tbls.length <= 1) {
				return null;
			}

			if (rowidx < startRow) {
				return null;
			}

			rowidx -= startRow;

			lastRow = $($tbls[1]).find("tr:not(:has(th))").length - 1;

			if (rowidx > lastRow) {
				return null;
			}

			return $($tbls[1]).find("tr:not(:has(th))")[rowidx];
		},

		_setErrorInRowIndicator: function (tr, on, classname) {
			var $tr = $(tr);

			if (on) {
				if ($tr && !$tr.hasClass(classname)) {
					$tr.addClass(classname);
				}
			} else {
				if ($tr && $tr.hasClass(classname)) {
					$tr.removeClass(classname);
				}
			}

		},

		handleChangeLineID: function (event) {
			var source = event.getSource(),
				binding = source.getBinding("value"),
				context = binding.getContext(),
				model = binding.getModel(),
				row = model.getProperty(context.getPath()),
				parentRow = {},
				_rows = [],
				ui5tbl = vc.view.byId("lineItemsTable"),
				tbl = $("#" + vc.view.byId("lineItemsTable").getId()),
				startRow = ui5tbl.getFirstVisibleRow(),
				newStartRow,
				numRows = $(tbl).find("tr:not(:has(th))").length,
				vcRowIdx = _.findIndex(model.getData(), function (line) {
					return line.SalesDocumentLineID === row.SalesDocumentLineID;
				}),
				vcRowNewIdx,
				refreshAllLines = false,
				params = {
					parentLineID: "",
					rows: [],
					sortedRows: [],
					result: false
				},
				structuredLineID = source.getValue(),
				parentPartIdx = (structuredLineID && structuredLineID.lastIndexOf) ? structuredLineID.lastIndexOf(".") : -1,
				topParentPartIdx = (structuredLineID && structuredLineID.indexOf) ? structuredLineID.indexOf(".") : -1,
				parentPart = (parentPartIdx > 0) ? structuredLineID.substring(0, parentPartIdx) : "",
				childPart = (parentPartIdx > 0) ? structuredLineID.substring(parentPartIdx + 1) : structuredLineID,
				canonicalLineID = (structuredLineID.lastIndexOf(".") !== -1 && parseInt(structuredLineID.substring(structuredLineID.lastIndexOf(
					".") + 1)) === 0) ? structuredLineID.substring(0, structuredLineID.lastIndexOf(".")) : structuredLineID;

			if (!(parentPartIdx === -1 || (parentPartIdx === topParentPartIdx && parseInt(childPart) === 0))) {
				// vc line id indicates that there is a parent line
				_rows = vc._findRowByStructuredLineID(parentPart);
				if (!!_rows && _rows.length >= 1) {
					parentRow = _rows[0];
					row.ParentLineID = parentRow.SalesDocumentLineID;
				} else {
					source.setTooltip("Line  refers to a non-existent parent (' + parentPart + ')");
					source.setValueState(sap.ui.core.ValueState.Error);
					event.preventDefault();
					source.focus();
					return false;
				}
			} else {
				row.ParentLineID = "000000";
			}

			_rows = vc._findRowByStructuredLineID(canonicalLineID);

			if (!!_rows && _rows.length !== 1) {
				source.setTooltip(
					"Duplicate line number (be aware that line number ' + canonicalLineID + ' is considered the same as line number ' + canonicalLineID + '.0)"
				);
				source.setValueState(sap.ui.core.ValueState.Error);
				event.preventDefault();
				source.focus();
				return false;
			}

			//model.setProperty(context.getPath(),row);

			if (vc._renumberChildren(row.SalesDocumentLineID, structuredLineID)) {
				refreshAllLines = true;
			}

			params.rows = $.extend(true, [], vc.view.getModel("currentSalesDocumentLines").getData());
			params.parentLineID = "000000";

			params = vc._reorderChildren(params);

			vc.view.byId("detailPage").setBusyIndicatorDelay(0);

			if (params.sortedRows && params.sortedRows.length > 0) {
				_rows = params.sortedRows;
				vc._repointLines(_rows);
				vc.view.getModel("currentSalesDocumentLines").setData(_rows);
			} else {
				if (refreshAllLines) {
					vc.view.getModel("currentSalesDocumentLines").refresh(true);
				}
			}

			vcRowNewIdx = _.findIndex(_rows, function (line) {
				return line.StructuredLineID === structuredLineID;
			});

			if (vcRowNewIdx !== vcRowIdx) { // Row has moved on screen so find it again.
				console.log("Old Start " + startRow);
				console.log("Old Row Idx " + vcRowIdx);
				console.log("Pos was " + (vcRowIdx - startRow));
				console.log("New Row Idx " + vcRowNewIdx);
				console.log("New Start " + (vcRowNewIdx - (vcRowIdx - startRow)));
				newStartRow = vcRowNewIdx - (vcRowIdx - startRow);

				if (newStartRow < 0) {
					event.preventDefault();
					event.cancelBubble();
					setTimeout(function () {
						ui5tbl.setFirstVisibleRow(0);
						setTimeout(function () {
							$($($(tbl).find("tr:not(:has(th))")[(vcRowIdx - startRow) + newStartRow]).find("input")[2]).focus();
						}, 500);
					}, 0);
				} else {
					if (newStartRow > (_rows.length - numRows)) {
						ui5tbl.setFirstVisibleRow(_rows.length - numRows);
						setTimeout(function () {
							$($($(tbl).find("tr:not(:has(th))")[(numRows - 1)]).find("input")[2]).focus();
						}, 500);
					} else {
						ui5tbl.setFirstVisibleRow(newStartRow);
					}
				}
			}
		},
		_repointLines: function (rows) {

			// vc method returns Re-ordering of line Items which causing wrong Parent ID: added below line to return without executing the statment
			if (!(core.getModel("currentState").getProperty("/isQuote") &&
					parseInt(core.getModel("currentSalesDocument").getProperty("/SalesDocumentID")) === 0)) {
				return rows;
			} // Added by SXVASAMSETTI :03/25/16			
			var lineNoLookup = [],
				newLineNo = "",
				oldLineNo = "",
				lineIdx = 1;

			for (var i = 0, len = (Boolean(rows)) ? rows.length : 0; i < len; i++) {
				oldLineNo = rows[i].SalesDocumentLineID;
				newLineNo = ((lineIdx++) * 10).toString();
				lineNoLookup[oldLineNo] = newLineNo;
				rows[i].SalesDocumentLineID = newLineNo;
				rows[i].DummyLineId = rows[i].SalesDocumentLineID + rows[i].ShipToID;
				if (lineNoLookup[rows[i].ParentLineID]) {
					rows[i].ParentLineID = lineNoLookup[rows[i].ParentLineID];
				}
			}
		},
		_renumberChildren: function (parentLineID, parentStructuredID) {
			var canonicalParentLineID = (parentStructuredID.lastIndexOf(".") !== -1 && parseInt(parentStructuredID.substring(parentStructuredID
					.lastIndexOf(".") + 1)) === 0) ? parentStructuredID.substring(0, parentStructuredID.lastIndexOf(".")) : parentStructuredID,
				children = vc._findLinesByParentLineID(parentLineID),
				child = {},
				structuredLineID = "",
				parentPartIdx = 0,
				parentPart = "",
				childOfZero = false,
				childPart = "";

			if (!children || children.length === 0) {
				return false;
			}

			for (var i = 0, len = children.length; i < len; i++) {
				child = children[i];
				structuredLineID = child.StructuredLineID;
				parentPartIdx = (structuredLineID && structuredLineID.lastIndexOf) ? structuredLineID.lastIndexOf(".") : -1;
				parentPart = (parentPartIdx > 0) ? structuredLineID.substring(0, parentPartIdx) : "";
				childPart = (parentPartIdx > 0) ? structuredLineID.substring(parentPartIdx + 1) : "";
				childOfZero = (parentPart.lastIndexOf(".") !== -1 && parseInt(parentPart.substring(parentPart.lastIndexOf(".") + 1)) === 0);
				if (childOfZero) {
					console.log(canonicalParentLineID);
				}
				child.StructuredLineID = canonicalParentLineID + ((childOfZero) ? ".0." : ".") + childPart;

				vc._renumberChildren(child.SalesDocumentLineID, child.StructuredLineID);
			}

			return true;
		},
		_reorderChildren: function (params) {
			var children = vc._findLinesByParentLineID(params.parentLineID, params.rows),
				len = (Boolean(children)) ? children.length : 0,
				child = {},
				structuredLineID = "",
				canonicalLineID = "",
				originalLineIDOrder = [],
				sortedLineIDOrder,
				reordered = false;

			if (!children || children.length === 0) {
				return false;
			}

			for (var i = 0; i < len; i++) {
				child = children[i];
				structuredLineID = child.StructuredLineID;
				canonicalLineID = (structuredLineID.lastIndexOf(".") !== -1 && parseInt(structuredLineID.substring(structuredLineID.lastIndexOf(
					".") + 1)) === 0) ? structuredLineID.substring(0, structuredLineID.lastIndexOf(".")) : structuredLineID;
				originalLineIDOrder.push({
					canonicalLineID: canonicalLineID,
					row: child
				});
			}

			sortedLineIDOrder = $.extend(true, [], originalLineIDOrder).sort(vc._srt({
				key: "canonicalLineID",
				dotted: true
			}));

			for (i = 0; i < len; i++) {
				if (sortedLineIDOrder[i].canonicalLineID !== originalLineIDOrder[i].canonicalLineID) {
					reordered = true;
				}
			}

			for (i = 0; i < len; i++) {
				child = (reordered) ? sortedLineIDOrder[i].row : originalLineIDOrder[i].row;
				params.sortedRows.push(child);
				params.parentLineID = child.SalesDocumentLineID;
				vc._reorderChildren(params);
			}

			params.result = params.result || reordered;

			return params;
		},
		_findAllChildren: function (parentLineID, rows) {
			var children = vc._findLinesByParentLineID(parentLineID, rows).sort(vc._srt({
					key: "SalesDocumentLineID",
					dotted: true
				})),
				arr = [],
				allChildren = [];

			if (!children || children.length === 0) {
				return allChildren;
			}

			for (var i = 0, len = children.length; i < len; i++) {
				allChildren.push(children[i]);
				arr = vc._findAllChildren(children[i].SalesDocumentLineID, rows);
				for (var j = 0, lenj = arr.length; j < lenj; j++) {
					allChildren.push(arr[j]);
				}
			}

			return allChildren;
		},
		_srt: function (sorton, descending) {
			var on = sorton && sorton.constructor === Object ? sorton : {};
			return function (a, b) {
				var atokens = [],
					btokens = [],
					pad = 0;
				if (on.string || on.key || on.dotted) {
					a = on.key ? a[on.key] : a;
					b = on.key ? b[on.key] : b;
					a = (on.string || on.dotted) ? String(a).toLowerCase() : a;
					b = (on.string || on.dotted) ? String(b).toLowerCase() : b;
					// if key is not present, move to the end
					if (on.key && (!b || !a)) {
						return !a && !b ? 1 : !a ? 1 : -1;
					}

					if (on.dotted) {
						atokens = a.split(".");
						btokens = b.split(".");

						if (atokens.length < btokens.length) {
							for (var i = 0, count = btokens.length - atokens.length; i < count; i++) {
								atokens.push('');
							}
						}
						if (btokens.length < atokens.length) {
							for (var i = 0, count = atokens.length - btokens.length; i < count; i++) {
								btokens.push('');
							}
						}
						a = "";
						b = "";
						for (var i = 0, count = atokens.length; i < count; i++) {
							pad = Math.max(atokens[i].length, btokens[i].length);

							a += vc._pad(atokens[i], pad);
							b += vc._pad(btokens[i], pad);
						}
					}
				}
				return descending ? ~~((on.string || on.dotted) ? b.localeCompare(a) : a < b) : ~~((on.string || on.dotted) ? a.localeCompare(b) :
					a > b);
			};
		},
		_findLinesByParentLineID: function (parentLineID, rows) {
			var currentSalesDocumentLines = rows || vc.view.getModel("currentSalesDocumentLines").getData();

			return $.grep(currentSalesDocumentLines, function (n) {
				return (n.ParentLineID === parentLineID);
			});
		},

		_isReadyForSubmission: function (details) {
			var isReadyForSubmission = true,
				lines = vc.view.getModel("currentSalesDocumentLines").getData();

			details.reason = "";

			_.each(lines, function (line) {
				var materialSeries = vc._determineMaterialSeries(line);

				if (!(materialSeries === vc.materialSerieProfessionalServices || materialSeries === vc.materialSeriePlaceHolder) && !line.VendorID) {
					isReadyForSubmission = false;
					details.reason += "VendorID missing for line " + line.StructuredLineID + ".\r\n";
				}
			});

			return isReadyForSubmission;
		},

		handleSubmitSalesOrder: function (event) {
			var msg = "",
				canSave = vc._canSave();

			if (Boolean(core.getModel("currentState").getProperty("/isEditMode"))) {
				if (canSave) {

					vc.busyDlg.setText("Saving document in SAP.");
					vc.busyDlg.open();

					setTimeout(function () {
						//_deleteDetailLines().done(fuction(){
						vc._checkSelectedLines().done(function () {
							//	core.getModel('beforeSaveSalesDocumentLines').setData( view.getModel('currentSalesDocumentLines').getData() );
							vc._doSave().done(function (id) {
								sap.m.MessageToast.show("Sales Document " + id + " has been saved.");
								vc._doSubmitSalesOrder();
							}).fail(function (msg) {
								sap.m.MessageBox.show((msg) ? msg : "SalesUI Could not save vc record to SAP.", {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "SAP Error",
									actions: sap.m.MessageBox.Action.OK,
									onClose: null
								});
							}).always(function () {
								vc.busyDlg.close();
							});
						}).fail(function () {
							vc.busyDlg.close();
						});
					}, 10);

				} else {
					msg = "Document cannnot be saved, please correct the highlighted errors and try again.";
					console.log(msg);
					MessageToast.show(msg);
				}
			} else {
				vc._doSubmitSalesOrder();
			}
		},
		_doSubmitSalesOrder: function () {
			var currentSalesDocument = vc.view.getModel("currentSalesDocument"),
				currentState = vc.view.getModel("currentState"),
				validityCheckDetails = {},
				lines = vc.view.getModel("currentSalesDocumentLines").getData();

			if (!vc._isReadyForSubmission(validityCheckDetails)) {
				sap.m.MessageToast.show("Sales Order cannot be submitted yet:\n" + ((validityCheckDetails.reason) ? validityCheckDetails.reason :
					"Unspecified reasons.") + "\n  Please address these issues and re-try.");
				return;
			}

			sap.m.MessageBox.confirm(
				"Submitting this Sales Order will automatically create the Purchase Requisitions.  All further changes will have to be made by Purchasing.  Are you sure you want to Submit this Sales Order?",
				function (confirmation) {
					if (confirmation === "OK") {
						currentState.setProperty("/isPendingSalesOrder", false);
						currentState.setProperty("/isSubmittedSalesOrder", true);
						for (var i = 0, len = (lines) ? lines.length : 0; i < len; i++) {
							if (formatter.itemCategoryToStaging(lines[i].ItemCategory)) {
								lines[i].ItemCategory = vc._determineItemCategoryForStaging(lines[i], true);
							} else {
								if (formatter.itemCategoryToDropShip(lines[i].ItemCategory)) {
									lines[i].ItemCategory = vc._determineItemCategoryForDropShip(lines[i], true);
								} else {
									lines[i].ItemCategory = vc._determineItemCategoryForBroughtIn(lines[i], true);
								}
							}
						}

						vc.busyDlg.setText("Submitting Sales Order in SAP. /n Please wait...");
						vc.busyDlg.open();

						setTimeout(function () {
							vc._doSave().fail(function (msg) {
								currentState.setProperty("/isPendingSalesOrder", true);
								currentState.setProperty("/isSubmittedSalesOrder", false);
								sap.m.MessageBox.show(msg, {
									icon: MessageBox.Icon.ERROR,
									title: "SAP Error",
									actions: MessageBox.Action.OK
								});
							}).always(function () {
								vc.busyDlg.close();
							});
						});
					}
				},
				"Confirm Submit Sales Order");
		},

		handleDetailSelect: function (event) {
			var salesDocument = vc.view.getModel("currentSalesDocument").getData();
			sap.ui.core.UIComponent.getRouterFor(vc).navTo(
				"detail", {
					orgData: salesDocument.Vkorg + salesDocument.Vtweg + salesDocument.Spart,
					salesDocId: vc.view.getModel("currentSalesDocument").getProperty("/SalesDocumentID"),
					customerId: vc.view.getModel("currentSalesDocument").getProperty("/CustomerID"),
					orderType: vc.view.getModel("currentSalesDocument").getProperty("/DocumentType"),
					tab: event.getParameter("selectedKey")
				}, true);
		},

		_calculateTotals: _.debounce(function () {
			var currentDocumentLines = vc.view.getModel("currentSalesDocumentLines"),
				materialSeries,
				totalHardwarePrice = 0,
				totalHardwareCost = 0,
				totalOtherPrice = 0,
				totalOtherCost = 0,
				totalHardwareGP,
				totalOtherGP,
				totalHardwareGPP,
				totalOtherGPP,
				totalPrice,
				totalCost,
				totalGPP,
				totalGP,
				totals = vc.view.getModel("currentTotals"),
				rows = (currentDocumentLines) ? currentDocumentLines.getData() : [];

			if (!totals) {
				return;
			}

			for (var key in rows) {

				materialSeries = vc._determineMaterialSeries(rows[key]);

				if (!rows[key].ReasonForRejection && !rows[key].MarkedForDeletion) {
					if (materialSeries === vc.materialSerieProfessionalServices) {
						totalOtherPrice += Math.round(parseFloat(rows[key].ExtendedPrice) * 100.0) / 100.0; // Round to pennies
						totalOtherCost += Math.round(parseFloat(rows[key].ExtendedCost) * 100.0) / 100.0; // Round to pennies
					} else {
						totalHardwarePrice += Math.round(parseFloat(rows[key].ExtendedPrice) * 100.0) / 100.0; // Round to pennies
						totalHardwareCost += Math.round(parseFloat(rows[key].ExtendedCost) * 100.0) / 100.0; // Round to pennies
					}
				}

				//      key = key + 1;
				vc._setErrorInRowIndicator(vc._findTrForRow(rows[key]), (rows[key].GrossProfit < 0), "negativeGP");
				vc._setErrorInRowIndicator(vc._findTrForRowInUnfrozenSection(rows[key]), (rows[key].GrossProfit < 0), "negativeGP");
				vc._setErrorInRowIndicator(vc._findTrForRow(rows[key]), (!!rows[key].ReasonForRejection && !rows[key].MarkedAsDeleted),
					"rejected");
				vc._setErrorInRowIndicator(vc._findTrForRowInUnfrozenSection(rows[key]), (!!rows[key].ReasonForRejection && !rows[key].MarkedAsDeleted),
					"rejected");
				vc._setErrorInRowIndicator(vc._findTrForRow(rows[key]), (!!rows[key].ReasonForRejection && !!rows[key].MarkedAsDeleted),
					"markedAsDeleted");
				vc._setErrorInRowIndicator(vc._findTrForRowInUnfrozenSection(rows[key]), (!!rows[key].ReasonForRejection && !!rows[key].MarkedAsDeleted),
					"markedAsDeleted");
				// Turn the background color of line item to Green if ItemCategory starts with 'Y' .submitted
				vc._setErrorInRowIndicator(vc._findTrForRow(rows[key]), ((rows[key].ItemCategory.substring(0, 1) === "Y" && rows[key].ReasonForRejection ===
					"") && !rows[key].MarkedAsDeleted), "submitted");
			}

			totalHardwareGP = Math.round((totalHardwarePrice - totalHardwareCost) * 100.0) / 100.0; // Round to pennies
			totalHardwareGPP = (totalHardwarePrice > 0) ? Math.round(((totalHardwareGP * 100.0) / totalHardwarePrice) * 1000.0) / 1000.0 : 0; // round to 3 dp
			totalOtherGP = Math.round((totalOtherPrice - totalOtherCost) * 100.0) / 100.0; // Round to pennies
			totalOtherGPP = (totalOtherPrice > 0) ? Math.round(((totalOtherGP * 100.0) / totalOtherPrice) * 1000.0) / 1000.0 : 0; // round to 3 dp
			totalPrice = Math.round((totalHardwarePrice + totalOtherPrice) * 100.0) / 100.0; // Round to pennies
			totalCost = Math.round((totalHardwareCost + totalOtherCost) * 100.0) / 100.0; // Round to pennies
			totalGP = Math.round((totalPrice - totalCost) * 100.0) / 100.0; // Round to pennies
			totalGPP = (totalPrice > 0) ? Math.round(((totalGP * 100.0) / totalPrice) * 1000.0) / 1000.0 : 0; // round to 3 dp

			totals.setProperty("/HWRevenue", totalHardwarePrice);
			totals.setProperty("/HWCost", totalHardwareCost);
			totals.setProperty("/HWGP", totalHardwareGP);
			totals.setProperty("/HWGPP", totalHardwareGPP);
			totals.setProperty("/ServicesRevenue", totalOtherPrice);
			totals.setProperty("/ServicesCost", totalOtherCost);
			totals.setProperty("/ServicesGP", totalOtherGP);
			totals.setProperty("/ServicesGPP", totalOtherGPP);
			totals.setProperty("/TotalRevenue", totalPrice);
			totals.setProperty("/TotalCost", totalCost);
			totals.setProperty("/TotalGP", totalGP);
			totals.setProperty("/TotalGPP", totalGPP);

			totals.refresh(true);
		}, 100),

		handleSelectOrderTypesToCreateSO: function (event) {
			if (!vc._OrderTypesPopover) {
				vc._OrderTypesPopover = sap.ui.xmlfragment("OrderTypesPopover", "gdt.salesui.s4.fragment.DetailCreateSalesOrderTypesActionSheet",
					vc);
				vc.getView().addDependent(vc._OrderTypesPopover);
			}

			// delay because addDependent will do a async rerendering and the popover will immediately close without it
			var oButton = event.getSource();
			jQuery.sap.delayedCall(0, vc, function () {
				vc._OrderTypesPopover.openBy(oButton);
			});
		},

		handleSalesOrderTypeSelect: function (event) {

			var oCtx = event.getSource().getBinding("title").getBindings()[0].getContext();
			var oModel = event.getSource().getBinding("title").getBindings()[0].getModel();
			var row = oModel.getProperty(oCtx.getPath());

			core.getModel("userPref").setProperty("/docType", row.Value2);
			vc._OrderTypesPopover.close();

			vc.handleCreateSalesOrderAfterSelectSoType(event);

		},

		handleCreateSalesOrder: function (event) {
			//	vc.handleSelectOrderTypesToCreateSO(event);	 will be implemented in Future 

			// currently it is defined for Ducument Type as ZOR1  	
			core.getModel("userPref").setProperty("/docType", "ZOR1");
			vc.handleCreateSalesOrderAfterSelectSoType(event);
		},

		handleCreateSalesOrderAfterSelectSoType: function (event) {

			var currentSalesDocument = vc.view.getModel("currentSalesDocument"),
				customerPOID = currentSalesDocument.getProperty("/CustomerPOID"),
				msg = "",
				canSave = vc._canSave();

			if (Boolean(core.getModel("currentState").getProperty("/isEditMode"))) {
				if (vc._isDirty() && canSave) {

					vc.busyDlg.setText("Saving document in SAP.");
					vc.busyDlg.open();

					setTimeout(function () {
						//_deleteDetailLines().done(fuction(){
						vc._checkSelectedLines().done(function () {
							vc._doSave().done(function (id) {
								MessageToast.show("Sales Document " + id + " has been saved.");
								vc.view.byId("createSalesOrderDialog").open();
								vc.view.byId("createSalesOrderCPOID").focus();
								if (customerPOID && customerPOID !== null) {
									vc.view.byId("createSalesOrderOK").setEnabled(true);
								} else {
									vc.view.byId("createSalesOrderOK").setEnabled(false);
								}
							}).fail(function (msg) {
								MessageBox.show((msg) ? msg : "SalesUI Could not save this record to SAP.", {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "SAP Error",
									actions: sap.m.MessageBox.Action.OK,
									onClose: null
								});
							}).always(function () {
								vc.busyDlg.close();
							});
						}).fail(function () {
							vc.busyDlg.close();
						});
					}, 10);

				} else {
					if (!canSave) {
						msg = "Document cannnot be saved, please correct the highlighted errors and try again.";
						console.log(msg);
						sap.m.MessageToast.show(msg);
					} else {
						msg = "No changes have been made, Save cancelled.";
						console.log(msg);
						sap.m.MessageToast.show(msg);
						vc._toggleEdit(true);
					}
				}
			} else {
				vc.view.byId("createSalesOrderDialog").open();
				vc.view.byId("createSalesOrderCPOID").focus();
				if (customerPOID && customerPOID !== null) {
					vc.view.byId('createSalesOrderOK').setEnabled(true);
				} else {
					vc.view.byId('createSalesOrderOK').setEnabled(false);
				}
			}
		},

		handleCreateSalesOrderCPOIDChange: function (event, a, b, c) {
			var source = event.getSource(),
				value = source.getValue();

			if (value && value != null) {
				//Begin of Change:Check Duplicate PO: ;02/16/16				
				if (value.length > 1) {
					value = encodeURIComponent(value);
					vc._checkDuplicatePO(value);
				} else {
					vc._clearWarning();
				}
				// End of Change:				
				vc.view.byId("createSalesOrderOK").setEnabled(true);
			} else {
				vc.view.byId("createSalesOrderOK").setEnabled(false);
			}
		},

		//--Begin of Change:Once confirmed,revert to normal state of UI	:- 02/16/16  
		_clearWarning: function () {
			vc.view.byId("Warning").setText("").removeStyleClass("warning");
			vc.view.byId("createSalesOrderCPOID").setValueState("None");
		},
		//--End of Change	

		handleConfirmCreateSalesOrder: function (event) {
			var today = new Date(Date.now()),
				salesDocumentLines = vc.view.getModel("currentSalesDocumentLines"),
				currentSalesDocument = vc.view.getModel("currentSalesDocument"),
				currentState = vc.view.getModel("currentState"),
				lines = [],
				tbl = vc.view.byId("lineItemsTable"),
				userid = core.getModel("systemInfo").getProperty("/Uname"),
				customerPOID = currentSalesDocument.getProperty("/CustomerPOID");

			vc.view.byId("createSalesOrderDialog").close();

			//--Begin of Change:Once confirmed,revert to normal state of UI	:- 02/16/16  		
			vc._clearWarning();
			//--End of Change	

			vc._toggleEdit(true);

			currentSalesDocument.setProperty("/ReferencedBy", currentSalesDocument.getProperty("/SalesDocumentID"));
			currentSalesDocument.setProperty("/SalesDocumentID", "0000000000");
			currentSalesDocument.setProperty("/CreatedBy", userid);
			currentSalesDocument.setProperty("/DocumentDate", null);
			currentSalesDocument.setProperty("/CreatedOn", today);
			currentSalesDocument.setProperty("/DocumentCategory", "C");
			currentSalesDocument.setProperty("/DocumentType", core.getModel("userPref").getProperty("/docType"));
			// -- Initialize custom Config Values
			dataLoader.InitDocItemCatConfigValues(currentSalesDocument.getData());

			//--- Setting Router Hash tag to Sales DocType	
			//	var sHash = window.location.hash;
			//	var start = sHash.indexOf("orderType") + "orderType".length + 1;
			//	var end   = start + 4;
			//	var docType = sHash.substring(start,end);
			//	sHash.replace("/"+ docType +"/g", core.getModel("userPref").getProperty("/docType"));
			//	window.location.replace(sHash||window.location.href);

			vc._setDefaultRouteOption(currentSalesDocument);

			currentState.setProperty("/isQuote", false);
			currentState.setProperty("/isSalesOrder", true);
			currentState.setProperty("/isPendingSalesOrder", true);
			currentState.setProperty("/isSubmittedSalesOrder", false);
			currentState.setProperty("/isAttachmentsNeedSave", true);
			lines = salesDocumentLines.getData();

			_.each(lines, function (line) {
				line.SalesDocumentID = "0000000000";
				line.CustomerPOID = customerPOID;
				line.CreatedBy = userid;
				line.CreatedOn = today;
				if (formatter.itemCategoryToStaging(line.ItemCategory)) {
					line.ItemCategory = vc._determineItemCategoryForStaging(line);
				} else {
					if (formatter.itemCategoryToDropShip(line.ItemCategory)) {
						line.ItemCategory = vc._determineItemCategoryForDropShip(line);
					} else {
						line.ItemCategory = vc._determineItemCategoryForBroughtIn(line);
					}
				}
			});

			salesDocumentLines.refresh(true);

			tbl.setFirstVisibleRow(0);
			vc._resizeTable();
			MessageToast.show("Edit new Sales Order and Save or Cancel when done");
		},
		// Begin of Insert: Populating default routing, Shipping method while creating sales order 		
		_setDefaultRouteOption: function (currentSalesDocument) {
			if (currentSalesDocument.getProperty("/SalesDocumentID") === "0000000000") {
				var routeOptions = core.getModel("routeOptions").getData();
				var defaultFlag;
				for (var i = 0; i < routeOptions.length; i++) {
					var routeOption = routeOptions[i];
					var shippingMethodValues = routeOption.ShippingRouteSet.results;
					var ShippingMethodValue = _.findWhere(shippingMethodValues, {
						Default: "X"
					});
					if (ShippingMethodValue) {

						currentSalesDocument.setProperty("/Account", ShippingMethodValue.Account);
						currentSalesDocument.setProperty("/RouteOptionID", ShippingMethodValue.Routeoption);
						currentSalesDocument.setProperty("/ShippingConditionID", ShippingMethodValue.Vsbed);
						currentSalesDocument.setProperty("/Scaccode", ShippingMethodValue.Scaccode);
						defaultFlag = "X";
						break;

					}
				}
				if (defaultFlag === undefined) {
					var routeOptionC = _.findWhere(routeOptions, {
						RouteOptionID: "C"
					});
					if (routeOptionC) {
						var shippingMethodValuesC = routeOptionC.ShippingRouteSet.results;
						var ShipMethodValue = _.findWhere(shippingMethodValuesC, {
							Vsbed: "30"
						}); //Vsbed: "30"
						if (ShipMethodValue) {
							currentSalesDocument.setProperty("/Account", ShipMethodValue.Account);
							currentSalesDocument.setProperty("/RouteOptionID", ShipMethodValue.Routeoption);
							currentSalesDocument.setProperty("/ShippingConditionID", ShipMethodValue.Vsbed);
							currentSalesDocument.setProperty("/Scaccode", ShipMethodValue.Scaccode);
						}
					}
				}
			}

		},
		// End of Insert: Populating default routing, Shipping method while creating sales order 		
		handleCancelCreateSalesOrder: function () {
			//Begin of Change:Clear the values & states: ;02/16/16			
			vc._clearWarning();
			vc.view.byId("createSalesOrderCPOID").setValue("");
			//End of Change
			vc.view.byId("createSalesOrderDialog").close();
		},

		handleCopyQuote: function () {
			var today = new Date(Date.now()),
				today_plus30 = new Date(Date.now()),
				lines = [],
				userid = core.getModel("systemInfo").getProperty("/Uname"),
				header = vc.view.getModel("currentSalesDocument").getData(),
				salesDocumentLines = vc.view.getModel("currentSalesDocumentLines");

			today_plus30.setDate(today_plus30.getDate() + 30);

			vc._toggleEdit(true);
			header.SalesDocumentID = "0000000000";
			header.CreatedBy = userid;
			header.CreatedOn = today;
			header.Description = "";
			header.HeaderText = "";
			header.RequestedBy = "";
			header.ValidFrom = today;
			header.PriceDate = today;
			header.ValidTo = today_plus30;
			header.ShipToID = header.CustomerID;
			header.Shstaddrid = "";
			header.Notes = "";
			header.PurchasingNotes = "";
			header.WarehouseNotes = "";
			header.BOLNotes = "";
			header.BillingNotes = "";
			header.Attention = "";

			lines = _.filter(salesDocumentLines.getData(), function (line) {
				return !line.WBSElement;
			});

			lines.forEach(function (line) {
				line.SalesDocumentID = "0000000000";
				line.ShipToID = header.CustomerID;
				line.Shstaddrid = "";
				line.VendorDeliveryNotes = "";
				line.BillingNotes = "";
				line.HasNotesFlag = false;
				line.DealID = "";
				line.CreatedBy = userid;
				line.CreatedOn = today;
				line.CreatedBy = userid;
				line.LastUpdatedOn = today;
				line.UpdatedBy = userid;
				vc._determineItemCategoryForDropShip(line);
			});

			vc.view.getModel("currentSalesDocument").setData(header);
			salesDocumentLines.setData(lines);
			vc._calculateTotals();

			MessageToast.show("Edit new quote and Save or Cancel when done");
		},

		//*****************************************************************************************************                    
		//---------------------------------L A Y O U T -- V A R I A N T----------------------------------------
		//		                                    Begin of Code Change
		//*****************************************************************************************************                                       
		handleSelectVariant: function (event) {
			variantHandler._setDefaultVariantLayout(null, event.getParameter("key"), vc.view);
		},
		handleCancelVariant: function (event) {
			vc._oVariantCreateDialog.close();
		},

		handleConfirmCreateVariant: function (event) {
			if (vc.view.getModel("variantFields").getData().length === 0) {
				return MessageToast.show("Please select fields for Variant or Cancel to continue");
			}
			if (!vc._oVariantNameSaveDialog) {
				vc._oVariantNameSaveDialog = sap.ui.xmlfragment("gdt.salesui.s4.fragment.DetailLineItemVariantNamePopUpDialog", vc);
				vc.view.addDependent(vc._oVariantNameSaveDialog);
			}
			core.byId("idVariantName").setValue("");
			core.byId("idVariantDefault").setSelected(false);
			core.byId("idVariantGlobal").setSelected(false);
			vc._oVariantNameSaveDialog.open();
		},

		handleVariantNameSave: function () {
			variantHandler.handleSaveAndSetVariant(event, vc.view);
		},

		handleVariantNameCancel: function () {
			vc.view.getController()._oVariantNameSaveDialog.close();
		},

		handleFieldSort: function (event) {
			var aSorters = [];
			var oLayoutFieldTable = event.getSource().getParent().getParent();
			var oBinding = oLayoutFieldTable.getBinding("items");
			aSorters.push(new sap.ui.model.Sorter("order"));
			oBinding.sort(aSorters);
		},

		handleManageVariant: function (event) {
			variantHandler.manageVariant(event, vc.view);
		},
		handleAddFieldtoVariant: function (event) {
			variantHandler.addFieldtoVariant(event, vc);
		},
		handleRemoveFieldFromVariant: function (event) {
			variantHandler.removeFieldFromVariant(event, vc);

		},
		handleMoveUpFieldInVariant: function (event) {
			variantHandler.moveUpFieldInVariant(event, vc);
		},
		handleMoveDownFieldInVariant: function (event) {
			variantHandler.moveDownFieldInVariant(event, vc);
		},
		//*****************************************************************************************************                    
		//---------------------------------L A Y O U T -- V A R I A N T----------------------------------------
		//		                                     End of code Change
		//*****************************************************************************************************                             

		//**************************************************************************************************
		//      C O P Y  O F  S A L E S  O R D E R   &   C O P Y  O F SO L I N E  I T E M S
		//                            -->  Begin of Change  <--		
		//**************************************************************************************************		
		//Begin of Change:SXVASAMSETTI:Copy SO Selection
		//Begin of Change: Copy of Selected SO Items and append to the list :SXVASAMSETTI			
		handleCopyPopupToggleSelection: function (event) {
			var salesDocumentLines = vc.view.getModel("currentCopySalesDocumentLines");
			var lines = salesDocumentLines.getData();
			lines.forEach(function (line) {
				if (event.mParameters.pressed) {
					line.Selected = true;
				} else {
					line.Selected = false;
				}
			});
			salesDocumentLines.setData(lines);
		},

		handleCopy: function (event) {
			var actionSheet = vc.view.byId("copyActionSheet");

			if (actionSheet.isOpen()) {
				actionSheet.close();
			} else {
				actionSheet.openBy(event.getSource());
			}
		},

		//Begin of Change: Sales Order Copy		
		handleCopySODialog: function () {
			var today = new Date(Date.now()),
				today_plus30 = new Date(Date.now()),
				lines = [],
				userid = core.getModel("systemInfo").getProperty("/Uname"),
				header = vc.view.getModel("currentSalesDocument").getData(),
				salesDocumentLines = vc.view.getModel("currentSalesDocumentLines");

			today_plus30.setDate(today_plus30.getDate() + 30);

			vc._toggleEdit(true);
			header.ReferencedBy = header.SalesDocumentID;
			header.SalesDocumentID = "0000000000";
			header.CreatedBy = userid;
			header.CreatedOn = today;
			header.Description = "";
			header.HeaderText = "";
			header.RequestedBy = "";
			header.ValidFrom = today;
			header.PriceDate = today;
			header.ValidTo = today_plus30;
			header.ShipToID = header.CustomerID;
			header.Shstaddrid = "";
			header.Notes = "";
			header.PurchasingNotes = "";
			header.WarehouseNotes = "";
			header.BOLNotes = "";
			header.BillingNotes = "";
			header.Attention = "";

			lines = _.filter(salesDocumentLines.getData(), function (line) {
				return !line.WBSElement;
			});

			lines.forEach(function (line) {
				line.SalesDocumentID = "0000000000";
				line.ShipToID = header.CustomerID;
				line.Shstaddrid = "";
				line.VendorDeliveryNotes = "";
				line.BillingNotes = "";
				line.HasNotesFlag = false;
				line.DealID = "";
				line.CreatedBy = userid;
				line.CreatedOn = today;
				line.LastUpdatedOn = today;
				line.UpdatedBy = userid;
				line.ItemCategory = line.ItemCategory.replace("Y", "Z");
				//  _determineItemCategoryForDropShip(line);
			});

			vc.view.getModel("currentSalesDocument").setData(header);
			salesDocumentLines.setData(lines);
			vc._calculateTotals();

			MessageToast.show("Edit new SO and Save or Cancel when done");
		},
		//End of Change: Sales Order Copy
		handleCopyDsToBroughtIn: function () {
			MessageToast.show("This Feature is currently not available");
		},
		handleCopyBroughtInToDs: function () {
			MessageToast.show("This Feature is currently not available");
		},
		//Begin of Change: Sales Order Line Items Copy		
		handleCopySOLineItemsDialog: function () {

			var copyLines = (JSON.parse(JSON.stringify(vc.view.getModel("currentSalesDocumentLines").getData())));
			copyLines.forEach(function (line) {
				line.Selected = false;
			});
			vc.view.getModel("currentCopySalesDocumentLines").setData(copyLines);

			vc._oDialog = sap.ui.xmlfragment("gdt.salesui.s4.fragment.DetailLineItemsCopyDialog", vc);
			vc.getView().addDependent(vc._oDialog);

			var ofooter = vc._oDialog._oDialog._oToolbar;
			if (ofooter.getContent().length === 2) {
				var oConfirmBtn = new sap.m.Button({
					id: "copyConfirmBtn",
					press: vc.handleConfirmCopySOLines.bind(vc),
					text: "Confirm",
					type: "Accept"
				});
				ofooter.addContent(oConfirmBtn);
			}
			vc._oDialog.open();
		},

		handleCopyClose: function () {
			vc._oDialog.destroy();
		},

		handleSearchPartID: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("CustomerPartID", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},

		/*	handleCopyPopupToggleSelection : function(event){
			 var salesDocumentLines = view.getModel('currentCopySalesDocumentLines');
			 var lines = salesDocumentLines.getData();	
				lines.forEach(function (line){			
					   if(event.mParameters.pressed){line.Selected = true;}
					   else{line.Selected = false}		
					  } );
				salesDocumentLines.setData( lines );			
			},*/

		handleConfirmCopySOLines: function () {

			var today = new Date(Date.now()),
				today_plus30 = new Date(Date.now()),
				lines = [],
				itemIDs = [],
				checkID = "",
				lineLevels = 0,
				copyLines = [],
				selectedLines = [],
				maxLine;
			today_plus30.setDate(today_plus30.getDate() + 30);

			lines = vc.view.getModel("currentSalesDocumentLines").getData();
			selectedLines = _.filter(vc.view.getModel("currentCopySalesDocumentLines").getData(), function (line) {
				return line.Selected;
			});
			if (selectedLines.length === 0) {
				MessageToast.show("Please select line items");
				return;
			}
			//	    copyLines = (JSON.parse(JSON.stringify(selectedLines))); //Cloning the data ie,,copy of data
			maxLine = _.max(lines, function (line) {
				return line.ZZLineID;
			});
			var maxLineID = Math.trunc(maxLine.ZZLineID);
			var maxSDLineID = parseInt(maxLine.SalesDocumentLineID);
			var parentLineID;
			var decimalVal = 0;
			var userid = core.getModel("systemInfo").getProperty("/Uname");
			selectedLines.forEach(function (line) {
				/*			line.SalesDocumentID = '0000000000';
							line.ShipToID = header.CustomerID;
							line.VendorDeliveryNotes = '';
							line.BillingNotes = '';
							line.HasNotesFlag = false;
							line.DealID = ''; */

				maxSDLineID = parseInt(maxSDLineID);
				line.CustomerPOLineID = (maxSDLineID + 10).toString();
				line.SalesDocumentLineID = maxSDLineID = vc._pad(maxSDLineID + 10, 6);
				line.DummyLineId = line.SalesDocumentLineID + line.ShipToID;
				line.DeletedFlag = false;
				//* Forming structure Line ID
				itemIDs = line.ZZLineID.split(".");
				if (checkID !== itemIDs[0]) {
					maxLineID++;
					checkID = itemIDs[0];
					decimalVal = 0;
				}

				lineLevels = line.ZZLineID.split(".");
				for (var n = 1; n < lineLevels.length; n++) {
					if (n === 1) {
						line.StructuredLineID = maxLineID + "." + lineLevels[n];
						continue;
					}
					line.StructuredLineID = line.StructuredLineID + "." + lineLevels[n];
				}
				if (n === 1) {
					line.StructuredLineID = maxLineID;
				}
				line.ZZLineID = line.StructuredLineID = line.StructuredLineID.toString();
				line.DeliveryDate = new Date(line.DeliveryDate);
				line.CreatedBy = userid;
				line.CreatedOn = today;
				line.CreatedBy = userid;
				line.LastUpdatedOn = today;
				line.UpdatedBy = userid;
				if (line.SmartNetEndDate) {
					line.SmartNetEndDate = new Date(line.SmartNetEndDate);
				}
				if (line.SmartNetBeginDate) {
					line.SmartNetBeginDate = new Date(line.SmartNetBeginDate);
				}
				line.ItemCategory = line.ItemCategory.replace("Y", "Z");
				//			_determineItemCategoryForDropShip(line,false);
				lines.push(line);

			});

			vc.view.getModel("currentSalesDocumentLines").setData(lines);

			vc._reassignParentId();
			vc._calculateTotals();
			//view.byId('detailLineItemSelectDialog').exit();
			vc._oDialog.destroy();
			sap.m.MessageToast.show("Line Items are copied and appended to the List");
		},

		_reassignParentId: function () {
			var lines = vc.view.getModel("currentSalesDocumentLines").getData();
			_.each(lines, function (line) {
				var parentPartIdx = (line.StructuredLineID && line.StructuredLineID.lastIndexOf) ? line.StructuredLineID.lastIndexOf(".") : -1,
					topParentPartIdx = (line.StructuredLineID && line.StructuredLineID.indexOf) ? line.StructuredLineID.indexOf(".") : -1,
					parentPart = (parentPartIdx > 0) ? line.StructuredLineID.substring(0, parentPartIdx) : "",
					childPart = (parentPartIdx > 0) ? line.StructuredLineID.substring(parentPartIdx + 1) : line.StructuredLineID;

				if (!(parentPartIdx === -1 || (parentPartIdx === topParentPartIdx && parseInt(childPart) === 0))) {
					// vc line id indicates that there is a parent line
					var _rows = vc._findRowByStructuredLineID(parentPart);
					if (!!_rows && _rows.length >= 1) {
						var parentRow = _rows[0];
						line.ParentLineID = parentRow.SalesDocumentLineID;
					}
				} else {
					line.ParentLineID = "000000";
				}
			});
			vc.view.getModel("currentSalesDocumentLines").setData(lines);
		},

		//End of Change: Copy SO: SXVASAMSETTI			
		//**************************************************************************************************
		//C O P Y  O F  S A L E S  O R D E R   &   C O P Y  O F SO L I N E  I T E M S
		//                      -->  End of Change  <--		
		//**************************************************************************************************		

		_toggleEdit: function (confirmation) {
			var currentState = vc.view.getModel("currentState"),
				documentModel = vc.view.getModel("currentSalesDocument"),
				linesModel = vc.view.getModel("currentSalesDocumentLines"),
				customerModel = vc.view.getModel("currentCustomer"),
				unsubmittedDetails,
				docCat = "",
				isEditMode = !currentState.getProperty('/isEditMode'),
				currentDocumentCopy,
				currentLinesCopy,
				currentCustomerCopy,
				currentCustomerID;

			if (!confirmation || confirmation === "CANCEL") {
				return;
			}
			currentState.setProperty("/isAttachmentsNeedSave", false);
			currentState.setProperty("/isEditMode", isEditMode);
			currentState.setProperty("/isNotEditMode", !isEditMode);
			currentState.setProperty("/canEdit", (isEditMode === false) && vc._canEdit());

			if (isEditMode) {
				vc.copies.setProperty("/currentDocumentCopy", jQuery.extend(true, {}, documentModel.getData()));
				vc.copies.setProperty("/currentLinesCopy", jQuery.extend(true, [], linesModel.getData()));
				vc.copies.setProperty("/currentCustomerCopy", jQuery.extend(true, {}, customerModel.getData()));
			} else {
				currentDocumentCopy = vc.copies.getProperty("/currentDocumentCopy");
				currentLinesCopy = vc.copies.getProperty("/currentLinesCopy");
				currentCustomerCopy = vc.copies.getProperty("/currentCustomerCopy");
				currentCustomerID = customerModel.getData().CustomerID;

				if (currentDocumentCopy && currentDocumentCopy.SalesDocumentID) {
					vc._deleteBlankDetailLines();
					dataLoader.InitDocItemCatConfigValues(currentDocumentCopy);
					documentModel.setData(currentDocumentCopy);
					linesModel.setData(currentLinesCopy);
					customerModel.setData(currentCustomerCopy);
					docCat = vc.view.getModel("currentSalesDocument").getProperty("/DocumentCategory");
					currentState.setProperty("/isQuote", docCat === "B");
					currentState.setProperty("/isSalesOrder", docCat === "C");
					currentState.setProperty("/isPendingSalesOrder", documentModel.getProperty("/DocumentCategory") === "C" && documentModel.getProperty(
						"/SalesOrderStatus") !== "E0002");
					currentState.setProperty("/isSubmittedSalesOrder", documentModel.getProperty("/DocumentCategory") === "C" && documentModel.getProperty(
						"/SalesOrderStatus") === "E0002");
					currentState.setProperty("/canDelete", currentState.getProperty("/isPendingSalesOrder"));
					vc.copies.setProperty("/currentDocumentCopy", null);
					vc.copies.setProperty("/currentLinesCopy", []);
					vc.copies.setProperty("/currentCustomerCopy", null);
					if (parseInt(core.getModel("currentSalesDocument").getProperty("/SalesDocumentID")) === 0) {
						vc.handleNavButtonPress();
					}
				} else {
					vc.splitApp.toDetail(vc.splitApp.getInitialDetail());
					vc.splitApp.showMaster();
					vc.currentSalesDocumentID = null;
					vc.router.navTo("master", {
						from: "customer",
						orgData: vc.orgData,
						customerId: currentCustomerID
					}, true);
				}
			}

		},

		_canSave: function () {
			var lines = vc.view.getModel("currentSalesDocumentLines").getData(),
				retVal = true;

			_.each(lines, function (line) {
				vc._parentIDFix(line);

				// Last minute validation checks here
			});

			return retVal;
		},

		_parentIDFix: function (line) {
			if (line.ParentLineID === "000000" || line.ParentLineID === "0") {
				line.ParentLineID = "";
			}

			return;
		},

		handleOutputTypeSelectDefault: function () {
			var defaultButton = (core.getModel("currentState").getProperty("/isQuote")) ? vc.view.byId("defaultOutputTypeQ") : vc.view.byId(
				"defaultOutputTypeSO");

			defaultButton.focus(true);
		},

		//PDF Display
		handleOutputRequest: function (event) {
			var actionSheet = vc.view.byId("outputActionSheet");

			if (actionSheet.isOpen()) {
				actionSheet.close();
			} else {
				actionSheet.openBy(event.getSource());
			}
		},

		// Begin of changes:SXVASAMSETTI; Partial Submission changes
		//Display Delete Options
		handleDeleteRequest: function (event) {
			var actionSheet = vc.view.byId("deleteActionSheet");

			if (actionSheet.isOpen()) {
				actionSheet.close();
			} else {
				actionSheet.openBy(event.getSource());
			}
		},

		handleToggleSelection: function (event) {
			var salesDocumentLines = vc.view.getModel("currentSalesDocumentLines");
			var lines = salesDocumentLines.getData();
			lines.forEach(function (line) {
				if ((line.ItemCategory.substring(0, 1) === "Z") || (!!line.ReasonForRejection && !line.MarkedAsDeleted)) {
					if (event.getSource().getSelected()) {
						line.Selected = true;
					} else {
						line.Selected = false;
					}
				}
			});
			salesDocumentLines.setData(lines);
		},

		handleSelectColumn: function (event) {
			var source = event.getSource();
			source.setShowColumnVisibilityMenu(true);
			source.setEnableColumnFreeze(true);
			if (event.mParameters.column.sId.indexOf("SELECTIONID") >= 0 ||
				event.mParameters.column.sId.indexOf("DROPSHIP") >= 0 ||
				event.mParameters.column.sId.indexOf("STAGE") >= 0) {
				source.setShowColumnVisibilityMenu(false);
				source.setEnableColumnFreeze(false);
			}

		},

		handleValidateEmail: function (event) {
			var regx =
				/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			if (!regx.test(event.mParameters.newValue)) {
				vc.view.byId("ElicenseEmail").setValueState("Error");
				vc.view.byId("ElicenseEmail").setValueStateText("Please Enter Valid Email Id");
				return;
			}
			vc.view.byId("ElicenseEmail").setValueState();
		},
		handleOpenDeleteDialog: function (event) {
			if (event.oSource.sId.indexOf("DeleteLineItems") >= 0) {
				if (vc._checkIsLinesAreSelected()) {
					vc.handleSaveButtonPress("DELETE_LINES");
				}
			} else {
				vc.handleDeleteButtonPress();
			}
		},

		handleCancelDeleteDialog: function () {

			vc.view.byId("deleteDialogID").close();
			MessageToast.show("Deletion Cancelled");
		},

		_checkIsLinesAreSelected: function () {
			if (_.findWhere(core.getModel("currentSalesDocumentLines").getData(), {
					Selected: true
				})) {
				return true;
			}
			MessageToast.show("Please Select lines");
			return false;
		},

		_checkSelectedLines: function (action) {
			var deferred, l, msg, rejmsg, popupmsg, popupmsgTitle,
				currentDocumentLines = core.getModel("currentSalesDocumentLines"),
				rows = currentDocumentLines.getData();
			if (action === "DELETE_LINES") {
				var selectedLines = _.filter(rows, function (row) {
					return (row.Selected && (row.ItemCategory.substring(0, 1) === "Z") || (row.Selected && !!row.ReasonForRejection && !row.MarkedAsDeleted));
				});
				l = (Boolean(selectedLines)) ? selectedLines.length : 0;
				msg = "Are you sure you wish to delete these " + l + " line items?";
				rejmsg = "Deletion of lines are canceled";
				popupmsgTitle = "Confirm Deletion";
			} else {
				// For save, all lines to be selected by default
				_.each(rows, function (row) {
					row.Selected = true;
				});
				var unSelectedLines = _.filter(rows, function (row) {
					return (row.Selected === false && row.ItemCategory.substring(0, 1) === "Z");
				});
				l = (Boolean(unSelectedLines)) ? unSelectedLines.length : 0;
				msg = "Some Line Items(~ " + l + ") are not selected which will not be saved. Do you still want to continue?";
				rejmsg = "Saving lines are canceled";
				popupmsgTitle = "Confirm Save Document";
			}

			deferred = $.Deferred(function (def) {
				if (l > 0) {

					MessageBox.confirm(msg, function (confirmation) {
						if (confirmation !== "CANCEL") {
							if (action === "DELETE_LINES") {
								_.each(rows, function (row) {
									if (!!row.Selected && !!row.ReasonForRejection) {
										row.MarkedAsDeleted = true;
										row.Selected = false;
									}
								});
								currentDocumentLines.setData(_.reject(rows, function (row) {
									return (row.Selected && ((row.ItemCategory.substring(0, 1) === "Z") || !!row.ReasonForRejection));
								}));

							} else {
								currentDocumentLines.setData(_.filter(rows, function (row) {
									return row.Selected;
								}));

							}

							vc.view.setModel(core.getModel("currentSalesDocumentLines"), "currentSalesDocumentLines");
							vc._calculateTotals();
							def.resolve();
						} else {
							def.reject(rejmsg);
						}
					}, popupmsgTitle);
				} else {
					def.resolve();
				}
			});

			return deferred.promise();
		},

		// End of change: SXVASAMSETTI, Partial Submission Changes		

		handleDetailedSOConfirmationPDFRequest: function () {
			vc._doOutput("ZBA5", "P");
		},

		handleSummarySOConfirmationPDFRequest: function () {
			vc._doOutput("ZBA6", "P");
		},

		handleStdQuotePDFRequest: function () {
			vc._doOutput((core.getModel("currentState").getProperty("/isQuote")) ? "ZAN1" : "ZBA1", "P");
		},

		handleDetailedQuotePDFRequest: function () {
			vc._doOutput((core.getModel("currentState").getProperty("/isQuote")) ? "ZAN2" : "ZBA2", "P");
		},

		handleEngineeringQuotePDFRequest: function () {
			vc._doOutput("ZAN3", "P");
		},

		handleDetailedEngineeringQuotePDFRequest: function () {
			vc._doOutput("ZAN4", "P");
		},

		handleBudgetSheetPDFRequest: function () {
			vc._doOutput("ZBA4", "P");
		},

		handleExcelExportRequest: function () {
			vc._doOutput("ZAN4", "E");
		},

		handleEDIOutputRequest: function () {
			vc._doOutput("ZBA0", "P");
		},

		handleEngineeringQuoteSummaryPDFRequest: function () {
			vc._doOutput("ZAN5", "P");
		},

		handleDetailedEngineeringQuoteSummaryPDFRequest: function (event) {
			vc._doOutput("ZAN6", "P");
		},

		_doOutput: function (outputType, fileType) {
			var salesDocument = vc.view.getModel("currentSalesDocument"),
				salesDocumentID = salesDocument.getProperty("/SalesDocumentID"),
				customerID = salesDocument.getProperty("/CustomerID"),
				shipToID = salesDocument.getProperty("/ShipToID"),
				docCat = salesDocument.getProperty("/DocumentCategory"),
				model = core.getModel(),
				//docCat = view.getModel('currentSalesDocument').getProperty('/DocumentCategory');

				sRead = "/PrintDocumentSet(CustomerID='" + customerID + "',DocumentNo='" + salesDocumentID + "',DocCat='" + docCat +
				"',FileType='" + fileType + "',OutputType='" + outputType + "')/$value";
			window.open(model.sServiceUrl + sRead);

		},

		handleOpenSharepointLibrary: function () {
			var baseUrl = sharepoint.fullyReferenceRelativeUrl("sites/SAPDocs/Documents/Forms/AllItems.aspx?RootFolder=");
			sharepoint.ensureSalesDocFolder(vc.currentCustomerID, vc.currentSalesDocumentID, vc.orgData).done(function (root) {
				sap.m.URLHelper.redirect(baseUrl + encodeURIComponent(root), true);
			});
		},

		handleExportToExcelRequest: function () {
			var data = new sap.ui.model.json.JSONModel(_.filter(core.getModel("currentSalesDocumentLines").getData(), function (row) {
					return (!row.DeletedFlag && !row.MarkedAsDeleted && !row.ReasonForRejection);
				})),
				xprt = new sap.ui.core.util.Export({
					exportType: new sap.ui.core.util.ExportTypeCSV({
						charset: "utf-16"
					}),
					models: data,
					rows: {
						path: "/"
					},
					columns: [{
						name: "Line",
						template: {
							content: {
								path: "StructuredLineID"
							}
						}
					}, {
						name: "Ref Ln",
						template: {
							content: {
								path: "CustomerPOLineID"
							}
						}
					}, {
						name: "Qty",
						template: {
							content: {
								path: "QTY"
							}
						}
					}, {
						name: "Ordered",
						template: {
							content: {
								path: "QtyOrdered"
							}
						}
					}, {
						name: "Received",
						template: {
							content: {
								path: "QtyReceived"
							}
						}
					}, {
						name: "Shipped",
						template: {
							content: {
								path: "QtyShipped"
							}
						}
					}, {
						name: "Billed",
						template: {
							content: {
								path: "QtyBilled"
							}
						}
					}, {
						name: "Manufacturer",
						template: {
							content: {
								path: "ManufacturerID"
							}
						}
					}, {
						name: "Part # Requested",
						template: {
							content: {
								path: "ManufacturerPartID"
							}
						}
					}, {
						name: "Description",
						template: {
							content: {
								path: "Description"
							}
						}
					}, {
						name: "Vendor",
						template: {
							content: {
								path: "VendorID"
							}
						}
					}, {
						name: "Part # To Order",
						template: {
							content: {
								path: "CustomerPartID"
							}
						}
					}, {
						name: "List Price",
						template: {
							content: {
								path: "ListPrice"
							}
						}
					}, {
						name: "GDT Disc.",
						template: {
							content: {
								path: "GDTDiscount"
							}
						}
					}, {
						name: "GDT Disc. %",
						template: {
							content: {
								path: "GDTDiscountPercent"
							}
						}
					}, {
						name: "Unit Cost",
						template: {
							content: {
								path: "UnitCost"
							}
						}
					}, {
						name: "Ext. Cost",
						template: {
							content: {
								path: "ExtendedCost"
							}
						}
					}, {
						name: "Cust. Disc.",
						template: {
							content: {
								path: "CustomerDiscount"
							}
						}
					}, {
						name: "Cust. Disc. %",
						template: {
							content: {
								path: "CustomerDiscountPercent"
							}
						}
					}, {
						name: "Unit Price",
						template: {
							content: {
								path: "UnitPrice"
							}
						}
					}, {
						name: "Ext. Price",
						template: {
							content: {
								path: "ExtendedPrice"
							}
						}
					}, {
						name: "GP",
						template: {
							content: {
								path: "GrossProfit"
							}
						}
					}, {
						name: "GP %",
						template: {
							content: {
								path: "GrossProfitPercentage"
							}
						}
					}, {
						name: "ItemCategory",
						template: {
							content: {
								path: "ItemCategory"
							}
						}
					}, {
						name: "ShipToID",
						template: {
							content: {
								path: "ShipToID"
							}
						}
					}, {
						name: "Deal ID / DART",
						template: {
							content: {
								path: "DealID"
							}
						}
					}, {
						name: "Delivery Date",
						template: {
							content: {
								path: "DeliveryDate"
							}
						}
					}, {
						name: "CCW Quote #",
						template: {
							content: {
								path: "ExternalQuoteID"
							}
						}
					}, {
						name: "SmartNet Line Type",
						template: {
							content: {
								path: "SmartNetLineType"
							}
						}
					}, {
						name: "SmartNet Part # Covered",
						template: {
							content: {
								path: "SmartNetCoveredMaterial"
							}
						}
					}, {
						name: "SmartNet S/N",
						template: {
							content: {
								path: "SmartNetCoveredSerialNumber"
							}
						}
					}, {
						name: "SmartNet Old S/N",
						template: {
							content: {
								path: "SmartNetReplacedSerialNumber"
							}
						}
					}, {
						name: "SmartNet Contract #",
						template: {
							content: {
								path: "SmartNetContractNumber"
							}
						}
					}, {
						name: "SmartNet Service Level",
						template: {
							content: {
								path: "SmartNetServiceLevel"
							}
						}
					}, {
						name: "SmartNet Begin Date",
						template: {
							content: {
								path: "SmartNetBeginDate"
							}
						}
					}, {
						name: "SmartNet End Date",
						template: {
							content: {
								path: "SmartNetEndDate"
							}
						}
					}, {
						name: "SmartNet Duration",
						template: {
							content: {
								path: "SmartNetDuration"
							}
						}
					}, {
						name: "WBSElement",
						template: {
							content: {
								path: "WBSElement"
							}
						}
					}]
				});

			xprt.saveFile(core.getModel("currentSalesDocument").getProperty("/SalesDocumentID")).always(function () {
				vc.destroy();
			});

			//data.saveFile(core.getModel('currentSalesDocument').getProperty('/SalesDocumentID'));

			//	var salesDocument = view.getModel('currentSalesDocument'),
			//	salesDocumentID = salesDocument.getProperty('/SalesDocumentID'),
			//	shipToID = salesDocument.getProperty('/ShipToID');
			//
			//	docCat = salesDocument.getProperty('/DocumentCategory');
			//	//docCat = view.getModel('currentSalesDocument').getProperty('/DocumentCategory');
			//
			//	sRead = "/PrintDocumentSet(CustomerID='" + shipToID + "',DocumentNo='" + salesDocumentID + "',DocCat='" + docCat + "',FileType='E')/$value";
			//
			//	var hyperlink = document.createElement('a');
			//	hyperlink.href = model.sServiceUrl + sRead;
			//	hyperlink.target = '_blank';
			//	hyperlink.download = 'DocumentNo_'+ salesDocumentID + '.xls' || model.sServiceUrl + sRead;
			//
			//	var mouseEvent = new MouseEvent('click', {
			//		view: window,
			//		bubbles: true,
			//		cancelable: true,
			//	});
			//
			//	hyperlink.dispatchEvent(mouseEvent);
			//	(window.URL || window.webkitURL).revokeObjectURL(hyperlink.href);
			//	//var pom = document.createElement('a');
			////	pom.setAttribute('sRead', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
			////	pom.setAttribute('download', 'filename');
			// //   pom.click();
			////	window.open(model.sServiceUrl + sRead );
			//
		},

		// Added by SXVASAMSETTI				
		handleExportSoAvailableQty: function () {
			var Export1 = new Export({
				exportType: new ExportTypeCSV({
					charset: "utf-16"
				}),
				models: vc.view.getModel("soAvailableQty"),
				rows: {
					path: "/"
				},
				columns: [{
						name: "Sales Doc.",
						template: {
							content: {
								path: "Vbeln"
							}
						}
					}, {
						name: "Item",
						template: {
							content: {
								path: "Posnr"
							}
						}
					}, {
						name: "HgLvIt",
						template: {
							content: {
								path: "Uepos"
							}
						}
					}, {
						name: "Line ID",
						template: {
							content: {
								path: "Ccwline"
							}
						}
					}, {
						name: "Material",
						template: {
							content: {
								path: "Matnr"
							}
						}
					}, {
						name: "Manufacturer Part No.",
						template: {
							content: {
								path: "Mfrpn"
							}
						}
					}, {
						name: "Order Qty",
						template: {
							content: {
								path: "Kwmeng"
							}
						}
					}, {
						name: "Recd Qty",
						template: {
							content: {
								path: "Recd"
							}
						}
					}, {
						name: "Shpd Qty",
						template: {
							content: {
								path: "Posted"
							}
						}
					}, {
						name: "Total Stock",
						template: {
							content: {
								path: "Lbkum"
							}
						}
					}, {
						name: "OpenSR Qty",
						template: {
							content: {
								path: "Opensr"
							}
						}
					}, {
						name: "Dlv. Qty",
						template: {
							content: {
								path: "Lfimg"
							}
						}
					}, {
						name: "Open Qty",
						template: {
							content: {
								path: "Openq"
							}
						}
					}, {
						name: "Unit",
						template: {
							content: {
								path: "Uom"
							}
						}
					}, {
						name: "Plant",
						template: {
							content: {
								path: "Werks"
							}
						}
					}, {
						name: "ItCa.",
						template: {
							content: {
								path: "Pstyv"
							}
						}
					}, {
						name: "Rejected?",
						template: {
							content: {
								path: "Abgru",
								formatter: formatter.isRejected
							}
						}
					}

				]
			});
			Export1.saveFile(core.getModel("currentSalesDocument").getProperty("/SalesDocumentID") + "_SalesOrderAvailableQuantity").always(
				function () {
					vc.destroy();
				});
		},

		// PDF Print
		handlePrintRequest: function () {
			var salesDocument = vc.view.getModel("currentSalesDocument"),
				salesDocumentID = salesDocument.getProperty("/SalesDocumentID"),
				shipToID = salesDocument.getProperty("/ShipToID"),
				docCat = salesDocument.getProperty("/DocumentCategory"),
				model = core.getModel(),
				//docCat = view.getModel('currentSalesDocument').getProperty('/DocumentCategory');

				sRead = "/PrintDocumentSet(CustomerID='" + shipToID + "',DocumentNo='" + salesDocumentID + "',DocCat='" + docCat +
				"',FileType='P')/$value";
			var lvprrint = window.open(model.sServiceUrl + sRead);
			lvprrint.print();
		},
		handleBSDialogCloseButton: function (oEvent) {
			oEvent.getSource().getParent().close();
		},

		_findRow: function (lineid) {
			var currentSalesDocumentLines = vc.view.getModel("currentSalesDocumentLines");

			return $.grep(currentSalesDocumentLines.getData(), function (n) {
				return n.SalesDocumentLineID === lineid;
			});
		},

		_findRowByStructuredLineID: function (structuredLineID) {
			var currentSalesDocumentLines = vc.view.getModel("currentSalesDocumentLines");

			if (!structuredLineID || structuredLineID.length === 0) {
				return [];
			}

			return $.grep(currentSalesDocumentLines.getData(), function (n) {
				return !n.MarkedAsDeleted && !n.DeletedFlag && ((n.StructuredLineID === structuredLineID) || (n.StructuredLineID ===
					structuredLineID + ".0") || (n.StructuredLineID + ".0" === structuredLineID));
			});
		},

		//	handleDetailDeleteSelect = function(event) {
		handleDetailOnSelectLines: function (event) {
			var source = event.getSource(),
				binding = source.getBinding("selected"),
				context = binding.getContext(),
				model = binding.getModel(),
				currentState = vc.view.getModel("currentState"),
				rows = vc.view.getModel("currentSalesDocumentLines"),
				rowsArray = rows.getData(),
				children,
				l,
				idx = -1,
				i,
				row = model.getProperty(context.getPath());

			if (!!row.ItemCategory && (row.ItemCategory.substring(0, 1) === "Y" && !row.ReasonForRejection)) {
				return;
			}

			children = vc._findAllChildren(row.SalesDocumentLineID, rowsArray);

			l = (Boolean(children)) ? children.length : 0;

			for (i = 0; i < l; i++) {
				idx = _.indexOf(rowsArray, children[i]);
				if (idx !== -1) {
					//children[i].DeletedFlag = row.DeletedFlag;
					children[i].Selected = row.Selected;
					rows.setProperty("/" + idx, children[i]);
				}
			}
			//   _calculateTotals();
		},
		//	Begin of Change: SXVASAMSETTI : 04/12/16		
		handleDropShipSelectAll: function (event) {
			vc.view.byId("STAGE_CHECK").setSelected(false);
			var tableModel = vc.view.getModel("currentSalesDocumentLines");
			var tabledata = tableModel.getData();
			_.each(tabledata, function (row) {
				if ((row.ItemCategory.substring(0, 1) === "Z") || (!!row.ReasonForRejection && !row.MarkedAsDeleted)) {
					row.Dsb = (event.getParameter("selected")) ? "D" : "";
					row.ItemCategory = (event.getParameter("selected")) ? vc._determineItemCategoryForDropShip(row) : vc._determineItemCategoryForBroughtIn(
						row);
				}
			});
			tableModel.setData(tabledata);
		},
		handleStagingSelectAll: function (event) {
			vc.view.byId("DROPSHIP_CHECK").setSelected(false);
			var tableModel = vc.view.getModel("currentSalesDocumentLines");
			var tabledata = tableModel.getData();
			_.each(tabledata, function (row) {
				if ((row.ItemCategory.substring(0, 1) === "Z") || (!!row.ReasonForRejection && !row.MarkedAsDeleted)) {
					row.Dsb = (event.getParameter("selected")) ? "S" : "";
					row.ItemCategory = (event.getParameter("selected")) ? vc._determineItemCategoryForStaging(row) : vc._determineItemCategoryForBroughtIn(
						row);
				}
			});
			tableModel.setData(tabledata);
		},
		// End of Change: SXVASAMSETTI:	

		handleDropShipSelect: function (event) {
			var source = event.getSource(),
				binding = source.getBinding("selected"),
				context = binding.getContext(),
				model = binding.getModel(),
				row = model.getProperty(context.getPath());
			row.Dsb = (event.getParameter("selected")) ? "D" : "";
			row.ItemCategory = (event.getParameter("selected")) ? vc._determineItemCategoryForDropShip(row) : vc._determineItemCategoryForBroughtIn(
				row);

			model.setProperty(context.getPath(), row);

			vc._makeTotalConfiguredItemLikeThis(row, model, ["ItemCategory", "Dsb"]);
		},

		handleStagingSelect: function (event) {
			var source = event.getSource(),
				binding = source.getBinding("selected"),
				context = binding.getContext(),
				model = binding.getModel(),
				row = model.getProperty(context.getPath());
			row.Dsb = (event.getParameter("selected")) ? "S" : "";
			row.ItemCategory = (event.getParameter("selected")) ? vc._determineItemCategoryForStaging(row) : vc._determineItemCategoryForBroughtIn(
				row);

			model.setProperty(context.getPath(), row);

			vc._makeTotalConfiguredItemLikeThis(row, model, ["ItemCategory", "Dsb"]);
		},

		_determineMaterialSeries: function (row) {
			var materialSeries = (row && row.MaterialID) ? row.MaterialID : "";

			materialSeries = materialSeries.replace(/^0+/, "");
			if (!!materialSeries && materialSeries.length > 1) {
				materialSeries = materialSeries.substring(0, 1);
			}

			return parseInt(materialSeries);
		},

		_determineItemCategoryForStaging: function (row, isSubmitted) {
			var currentState = vc.view.getModel("currentState"),
				isQuote = currentState.getProperty("/isQuote"),
				//	edelivery = (Boolean(row.EDelivery)) ? (row.EDelivery === "EDELIVERY") : false,
				materialSeries = vc._determineMaterialSeries(row);

			/*		if (edelivery) return (_determineItemCategoryForDropShip(row, isSubmitted));*/
			var ic = vc._determineItemCategoryFromCustomConfig("ST", (Boolean(materialSeries)) ? materialSeries : "*", isSubmitted)
			if (ic !== "") {
				return ic;
			}

			if (!!materialSeries && materialSeries === vc.materialSeriePlaceHolder) { // Non-Corporial - Roll-up, Discount, Trade-in etc.
				return (isQuote) ? "ZGDT" : (isSubmitted) ? "YGDT" : "ZGDT";
			}
			if (!materialSeries || materialSeries === vc.materialSeriesHardware) { // Hardware
				return (isQuote) ? "ZHBC" : ((isSubmitted) ? "YBAC" : "ZBAC");
			}

			if (materialSeries === vc.materialSeriesFinishedGoods) { // Finished Goods
				return (isQuote) ? "AGN" : ((isSubmitted) ? "YTAN" : "ZTAN");
			}

			// Professional Services
			return (isQuote) ? "ZPFS" : ((isSubmitted) ? "YTAO" : "ZTAO");

		},

		_determineItemCategoryForDropShip: function (row, isSubmitted) {
			var currentState = vc.view.getModel("currentState"),
				isQuote = currentState.getProperty("/isQuote"),
				materialSeries = vc._determineMaterialSeries(row);

			var ic = vc._determineItemCategoryFromCustomConfig("DS", (Boolean(materialSeries)) ? materialSeries : "*", isSubmitted);
			if (ic !== "") {
				return ic;
			}

			if (!!materialSeries && materialSeries === vc.materialSeriePlaceHolder) { // Non-Corporial - Roll-up, Discount, Trade-in etc.
				return (isQuote) ? "ZGDT" : (isSubmitted) ? "YGDT" : "ZGDT";
			}
			if (!materialSeries || materialSeries === vc.materialSeriesHardware) { // Hardware
				return (isQuote) ? "ZHDS" : ((isSubmitted) ? "YB1" : "ZB1");
			}

			if (materialSeries === vc.materialSeriesFinishedGoods) { // Finished Goods
				return (isQuote) ? "AGN" : ((isSubmitted) ? "YTAN" : "ZTAN");
			}

			// Professional Services
			return (isQuote) ? "ZPFS" : ((isSubmitted) ? "YTAO" : "ZTAO");
		},

		_determineItemCategoryForBroughtIn: function (row, isSubmitted) {
			var currentState = vc.view.getModel("currentState"),
				isQuote = currentState.getProperty("/isQuote"),
				//	edelivery = (!!row.EDelivery) ? (row.EDelivery === "EDELIVERY") : false,
				materialSeries = vc._determineMaterialSeries(row);

			/*	if (edelivery) return (_determineItemCategoryForDropShip(row, isSubmitted));*/

			var ic = vc._determineItemCategoryFromCustomConfig("", (Boolean(materialSeries)) ? materialSeries : "*", isSubmitted);
			if (ic !== "") {
				return ic;
			}

			if (!!materialSeries && materialSeries === vc.materialSeriePlaceHolder) { // Non-Corporial - Roll-up, Discount, Trade-in etc.
				return (isQuote) ? "ZGDT" : (isSubmitted) ? "YGDT" : "ZGDT";
			}
			if (!materialSeries || materialSeries === vc.materialSeriesHardware) { // Hardware
				return (isQuote) ? "ZHBI" : ((isSubmitted) ? "YBAB" : "ZBAB");
			}

			if (materialSeries === vc.materialSeriesFinishedGoods) { // Finished Goods
				return (isQuote) ? "AGN" : ((isSubmitted) ? "YTAN" : "ZTAN");
			}

			// Professional Services
			return (isQuote) ? "ZPFS" : ((isSubmitted) ? "YTAO" : "ZTAO");

		},

		_determineItemCategoryFromCustomConfig: function (process, matSeries, isSubmitted) {

			var ic;
			var itemCategoryValues = core.getModel("docItemCatValues").getData();

			ic = _.find(itemCategoryValues, function (ic) {
				return (ic.MaterialSeries == matSeries && (ic.IsSoSubmitted == ((isSubmitted) ? "X" : "")) && ic.Gdtprocess == process);
			});

			return (Boolean(ic)) ? ic.ItemCategory : "";

		},

		handleChangeDetailLineShipTo: function (event) {
			var source = event.getSource(),
				//binding = source.getBinding('value').getBindings()[0],
				binding = source.getBinding("value"),
				context = binding.getContext(),
				model = binding.getModel(),
				partnerID = vc._findPartnerID(source.getValue(), "ShipTos"),
				row = model.getProperty(context.getPath()),
				forceRefresh = false;

			if (("" + binding.getValue() === "ONETIME") && (binding.getValue() !== source.getValue())) {
				row.OTSTAddressID = "0000000000";
				row.OTSTName = "";
				row.OTSTStreet = "";
				row.OTSTStreet2 = "";
				row.OTSTStreet3 = "";
				row.OTSTCity = "";
				row.OTSTState = "";
				row.OTSTZip = "";
				row.OTSTCountry = "";
				row.OTSTPhone = "";
				forceRefresh = true;
			}
			if (!partnerID) {
				source.setTooltip("Ship To Party does not exist.  Please select from the displayed options.");
				source.setValueState(sap.ui.core.ValueState.Error);
				event.preventDefault();
				return;
			}

			source.setValueState(sap.ui.core.ValueState.None);
			source.setTooltip();

			row.ShipToID = partnerID;

			vc._makeTotalConfiguredItemLikeThis(row, model, ["ShipToID", "DummyLineId", "OTSTAddressID", "OTSTName", "OTSTStreet",
				"OTSTStreet2", "OTSTStreet3", "OTSTCity", "OTSTState", "OTSTZip", "OTSTCountry", "OTSTPhone"
			]);
			if (forceRefresh) {
				model.refresh(true);
			}

		},

		handleChangeDetailLineDealID: function (event) {
			var source = event.getSource(),
				binding = source.getBinding("value"),
				context = binding.getContext(),
				model = binding.getModel(),
				row = model.getProperty(context.getPath());

			row.DealID = source.getValue();

			vc._makeTotalConfiguredItemLikeThis(row, model, ["DealID"], row.VendorID);
		},

		// One Time Ship To
		handleViaHeaderPress: function () {
			var currentDocument = vc.view.getModel("currentSalesDocument");
			vc._popViaDialog(currentDocument.getData(), currentDocument, true);

		},

		// One Time Ship To
		handleViaDetailPress: function (event) {
			var source = event.getSource(),
				row = {},
				rowid = source.data("rowid"),
				currentDocumentLines = vc.view.getModel("currentSalesDocumentLines");

			if (!rowid) {
				return;
			}

			row = vc._findRow(rowid);

			vc._popViaDialog(row[0], currentDocumentLines, false);

		},

		handleCloseViaDialog: function (event) {
			var dialog = vc.view.byId("NewViaAddress"),
				currentVia = vc.view.getModel("currentVia"),
				zipMissing = !currentVia.getProperty("/Zip") && (!!currentVia.getProperty("/Name") || !!currentVia.getProperty("/Street") || !!
					currentVia.getProperty("/Street2") || !!currentVia.getProperty("/Street3") || !!currentVia.getProperty("/City") || !!currentVia.getProperty(
						"/State") || !!currentVia.getProperty("/Country") || !!currentVia.getProperty("/Phone")),
				nameMissing = !currentVia.getProperty("/Name") && (!!currentVia.getProperty("/Street") || !!currentVia.getProperty("/Street2") ||
					!!currentVia.getProperty("/Street3") || !!currentVia.getProperty("/City") || !!currentVia.getProperty("/State") || !!currentVia.getProperty(
						"/Country") || !!currentVia.getProperty("/Phone")),
				streetMissing = !currentVia.getProperty("/Street") && (!!currentVia.getProperty("/Name") || !!currentVia.getProperty("/Street2") ||
					!!currentVia.getProperty("/Street3") || !!currentVia.getProperty("/City") || !!currentVia.getProperty("/State") || !!currentVia.getProperty(
						"/Country") || !!currentVia.getProperty("/Phone")),
				cityMissing = !currentVia.getProperty("/City") && (!!currentVia.getProperty("/Name") || !!currentVia.getProperty("/Street") || !!
					currentVia.getProperty("/Street2") || !!currentVia.getProperty("/Street3") || !!currentVia.getProperty("/State") || !!currentVia.getProperty(
						"/Country") || !!currentVia.getProperty("/Phone")),
				stateMissing = !currentVia.getProperty("/State") && (!!currentVia.getProperty("/Name") || !!currentVia.getProperty("/Street") || !
					!currentVia.getProperty("/Street2") || !!currentVia.getProperty("/Street3") || !!currentVia.getProperty("/City") || !!currentVia.getProperty(
						"/Country") || !!currentVia.getProperty("/Phone"));

			var _required = function (field, message) {
				sap.m.MessageToast.show(message);
				event.preventDefault();
				event.cancelBubble();
				vc.view.byId(field).setValueState(sap.ui.core.ValueState.Error);

			};

			if (zipMissing) {
				_required("OTSTZip", "One Time Ship To (Via) address cannot be saved without a zip code.");
			} else {
				vc.view.byId("OTSTZip").setValueState(sap.ui.core.ValueState.None);
			}
			if (nameMissing) {
				_required("OTSTName", "One Time Ship To (Via) address cannot be saved without a name.");
			} else {
				vc.view.byId("OTSTName").setValueState(sap.ui.core.ValueState.None);
			}
			if (streetMissing) {
				_required("OTSTStreet", "One Time Ship To (Via) address cannot be saved without a street.");
			} else {
				vc.view.byId("OTSTStreet").setValueState(sap.ui.core.ValueState.None);
			}
			if (cityMissing) {
				_required("OTSTCity", "One Time Ship To (Via) address cannot be saved without a city.");
			} else {
				vc.view.byId("OTSTCity").setValueState(sap.ui.core.ValueState.None);
			}
			if (stateMissing) {
				_required("OTSTState", "One Time Ship To (Via) address cannot be saved without a state.");
			} else {
				vc.view.byId("OTSTState").setValueState(sap.ui.core.ValueState.None);
			}
			if (!zipMissing && !nameMissing && !streetMissing && !cityMissing && !stateMissing) {
				dialog.close();
			} else {
				return false;
			}
		},

		_popViaDialog: function (via, model, allDetails) {
			var currentVia = vc.view.getModel("currentVia"),
				currentViaCopy = {},
				dialog = vc.view.byId("NewViaAddress");

			if (!!via.OTSTAddressID || !!via.OTSTZip) {
				currentVia.setProperty("/ID", via.OTSTAddressID);
				currentVia.setProperty("/Name", via.OTSTName);
				currentVia.setProperty("/Street", via.OTSTStreet);
				currentVia.setProperty("/Street2", via.OTSTStreet2);
				currentVia.setProperty("/Street3", via.OTSTStreet3);
				currentVia.setProperty("/City", via.OTSTCity);
				currentVia.setProperty("/State", via.OTSTState);
				currentVia.setProperty("/Country", via.OTSTCountry);
				currentVia.setProperty("/Zip", via.OTSTZip);
				currentVia.setProperty("/Phone", via.OTSTPhone);
			} else {
				currentVia.setProperty("/ID", "0000000000");
				currentVia.setProperty("/Name", "");
				currentVia.setProperty("/Street", "");
				currentVia.setProperty("/Street2", "");
				currentVia.setProperty("/Street3", "");
				currentVia.setProperty("/City", "");
				currentVia.setProperty("/State", "");
				currentVia.setProperty("/Country", "");
				currentVia.setProperty("/Zip", "");
				currentVia.setProperty("/Phone", "");
			}

			currentViaCopy = jQuery.extend(true, {}, currentVia.getData());

			var _processViaData = function (event, data) {
				var currentVia = vc.view.getModel("currentVia"),
					linesModel = vc.view.getModel("currentSalesDocumentLines"),
					lines = linesModel.getData(),
					row = {};

				if (!vc._deepCompare(currentVia.getData(), data.oldVia)) {
					//					data.via.OTSTAddressID = currentVia.getProperty('/ID');
					data.via.OTSTAddressID = "0000000000";
					data.via.OTSTName = currentVia.getProperty("/Name");
					data.via.OTSTStreet = currentVia.getProperty("/Street");
					data.via.OTSTStreet2 = currentVia.getProperty("/Street2");
					data.via.OTSTStreet3 = currentVia.getProperty("/Street3");
					data.via.OTSTCity = currentVia.getProperty("/City");
					data.via.OTSTState = currentVia.getProperty("/State");
					data.via.OTSTCountry = currentVia.getProperty("/Country");
					data.via.OTSTZip = currentVia.getProperty("/Zip");
					data.via.OTSTPhone = currentVia.getProperty("/Phone");

					vc._makeTotalConfiguredItemLikeThis(data.via, data.model, ["OTSTAddressID", "OTSTName", "OTSTStreet", "OTSTStreet2",
						"OTSTStreet3", "OTSTCity", "OTSTState", "OTSTCountry", "OTSTZip", "OTSTPhone"
					]);
					data.model.refresh(true);
				}

				if (data.allDetails) {
					for (var i = 0, len = (Boolean(lines)) ? lines.length : 0; i < len; i++) {
						row = lines[i];
						row.OTSTAddressID = currentVia.getProperty("/ID");
						row.OTSTName = currentVia.getProperty("/Name");
						row.OTSTStreet = currentVia.getProperty("/Street");
						row.OTSTStreet2 = currentVia.getProperty("/Street2");
						row.OTSTStreet3 = currentVia.getProperty("/Street3");
						row.OTSTCity = currentVia.getProperty("/City");
						row.OTSTState = currentVia.getProperty("/State");
						row.OTSTCountry = currentVia.getProperty("/Country");
						row.OTSTZip = currentVia.getProperty("/Zip");
						row.OTSTPhone = currentVia.getProperty("/Phone");
					}

					linesModel.refresh(true);
				}

				dialog.detachAfterClose(_processViaData, vc);
			};
			dialog.attachAfterClose({
				oldVia: currentViaCopy,
				via: via,
				model: model,
				allDetails: allDetails
			}, _processViaData, vc);
			dialog.open();

		},

		handleEditCancelButtonPress: function () {

			var currentState = vc.view.getModel("currentState"),
				isEditMode = !currentState.getProperty("/isEditMode");

			if (isEditMode) {
				vc._toggleEdit(true);
			} else {
				if (vc._isDirty()) {
					MessageBox.confirm("Changes have been made, are you sure you wish to discard them?", vc._toggleEdit, "Confirm Cancel Edit");
				} else {
					vc._toggleEdit(true);
				}
			}
		},

		_isDirty: function () {
			var currentDocumentCopy = vc.copies.getProperty("/currentDocumentCopy"),
				currentCustomerCopy = vc.copies.getProperty("/currentCustomerCopy"),
				currentLinesCopy = vc.copies.getProperty("/currentLinesCopy"),
				lines = vc.view.getModel("currentSalesDocumentLines").getData(),
				toOmit = ["LineItems", "ExchangeRate"], //,"Currency"
				detailLinesDifferent = false;

			if (!currentDocumentCopy || !currentCustomerCopy || !currentLinesCopy) {
				return true;
			}

			currentLinesCopy = _.reject(currentLinesCopy, function (line) {
				return !line.MaterialID;
			});
			lines = _.reject(lines, function (line) {
				return !line.MaterialID;
			});

			if (_.reject(currentLinesCopy, function (line) {
					return !line.MaterialID;
				}).length !== _.reject(lines, function (line) {
					return !line.MaterialID;
				}).length) {
				return true;
			}

			if (currentDocumentCopy.DocumentCategory === "B") {
				toOmit.push("RequestedDeliveryDate"); // User cannot see vc change so don't enforce if quote.
			}

			_.each(currentLinesCopy, function (line) {
				var newLine = _.findWhere(lines, {
					SalesDocumentLineID: line.SalesDocumentLineID
				});

				if (!newLine) {
					detailLinesDifferent = (Boolean(line.ManufacturerPartID)) ? true : detailLinesDifferent;
				} else {
					vc._parentIDFix(line);
					vc._parentIDFix(newLine);
					if (!_.isEqual(line, newLine)) {
						detailLinesDifferent = true;
					}
				}
			});

			return !_.isEqual(_.omit(currentDocumentCopy, toOmit), _.omit(vc.view.getModel("currentSalesDocument").getData(), toOmit)) ||
				!_.isEqual(vc.view.getModel("currentCustomer").getData(), currentCustomerCopy) ||
				detailLinesDifferent;

		},

		// Save Button
		handleSaveButtonPress: function (event) {
			var msg = "",
				canSave = vc._canSave();

			//if (_isDirty() && canSave) {
			if (function () {
					if (event !== "DELETE_LINES") {
						return (vc._isDirty() && canSave);
					}
					return true;
				}()) {
				if (event === "DELETE_LINES") {
					vc.busyDlg.setText("Deleting Document Line Items in SAP");
				} else {
					vc.busyDlg.setText("Saving document in SAP.");
				}
				vc.busyDlg.open();

				setTimeout(function () {
					//_deleteDetailLines().done(fuction(){
					vc._checkSelectedLines(event).done(function () {
						vc._doSave().done(function (id) {
							MessageToast.show("Sales Document " + id + " has been saved.");
							if (sap.ui.getCore().getModel("currentState").getProperty("/isSalesOrder") && sap.ui.getCore().getModel("currentState").getProperty(
									"/isAttachmentsNeedSave")) {
								vc._refreshAttachments();
								sap.ui.getCore().getModel("currentState").setProperty("/isAttachmentsNeedSave", false);
								if (core.getModel("currentState").getProperty("/isSalesOrder") && !vc.view.byId("idSoAvailableQty").getVisible()) {
									vc.view.byId("idSoAvailableQty").setVisible(true);
								}
							}
						}).fail(function (msg) {
							MessageBox.show((msg) ? msg : "SalesUI Could not save this record to SAP.", {
								icon: MessageBox.Icon.ERROR,
								title: "SAP Error",
								actions: MessageBox.Action.OK,
								onClose: null
							});
						}).always(function () {
							vc.busyDlg.close();
						});
					}).fail(function () {
						vc.busyDlg.close();
					});
				}, 10);

			} else {
				if (!canSave) {
					msg = "Document cannnot be saved, please correct the highlighted errors and try again.";
					console.log(msg);
					MessageToast.show(msg);
				} else {
					msg = "No changes have been made, Save cancelled.";
					console.log(-10, msg);
					MessageToast.show(msg);
					vc._toggleEdit(true);
				}
			}
		},

		handleSaveAndExitButtonPress: function (event) {
			var msg = '',
				startupMsg,
				canSave = vc._canSave();

			if (vc._isDirty() && canSave) {

				vc.busyDlg.setText("Saving document in SAP.");
				vc.busyDlg.open();

				setTimeout(function () {
					//_deleteDetailLines().done(fuction(){
					vc._checkSelectedLines().done(function () {
						vc._doSave().done(function (id) {
							MessageToast.show("Sales Document " + id + " has been saved.");
						}).fail(function (msg) {
							MessageBox.show((startupMsg) ? startupMsg : "SalesUI Could not save this record to SAP.", {
								icon: MessageBox.Icon.ERROR,
								title: "SAP Error",
								actions: MessageBox.Action.OK,
								onClose: null
							});
						}).always(function () {
							vc.busyDlg.close();
						});
					}).fail(function () {
						vc.busyDlg.close();
					});
				}, 10);

			} else {
				if (!canSave) {
					msg = "Document cannnot be saved, please correct the highlighted errors and try again.";
					MessageToast.show(msg);
				} else {
					msg = "No changes have been made, Save cancelled.";
					vc._toggleEdit(true);
					vc._exit();
					MessageToast.show(msg);
				}
			}
		},

		_doSave: function (exit) {
			var currentState = vc.view.getModel('currentState'),
				deferred = null,
				linesCopy = [];

			deferred = $.Deferred(function (def) {
				var timeout = 0,
					unsubmitted,
					currentLines = vc.view.getModel("currentSalesDocumentLines"),
					currentSalesDocument = vc.view.getModel("currentSalesDocument"),
					newSalesDocument = currentSalesDocument.getData();

				delete newSalesDocument._bCreate;

				vc._deleteBlankDetailLines();

				if (!newSalesDocument.RequestedDeliveryDate || newSalesDocument.RequestedDeliveryDate < Date.now()) {
					newSalesDocument.RequestedDeliveryDate = new Date(Date.now());
				}

				if (newSalesDocument.HeaderText && newSalesDocument.HeaderText.length > 40) {
					newSalesDocument.HeaderText = newSalesDocument.HeaderText.substring(0, 40);
				}

				_.each(currentLines.getData(), function (line) {
					vc._parentIDFix(line);
					if (line.MaterialID) {
						line.MaterialID = vc._pad(line.MaterialID, 18);
					}
					if (line.CustomerMaterialID) {
						line.CustomerMaterialID = vc._pad(line.CustomerMaterialID, 18);
					}
				});

				// Delete 4 Series Materials(Professional Services) from UI to avoid any changes as these materials only handled from SAP GUI by Launch Team					
				//					newSalesDocument.LineItems = _.reject(currentLines.getData(),function(line){ return ( line.ItemCategory == 'ZPFS' || line.ItemCategory == 'YTAO' ||  line.ItemCategory == 'ZTAO') });
				newSalesDocument.LineItems = currentLines.getData();
				unsubmitted = _.find(newSalesDocument.LineItems, function (row) {
					return (!!row.ItemCategory && row.ItemCategory.substring(0, 1) !== "Y") || (!!row.ReasonForRejection && !row.MarkedAsDeleted);
				});
				if (!!unsubmitted && unsubmitted.length !== 0) {
					newSalesDocument.SalesOrderStatus = "E0001";
				} else {
					newSalesDocument.SalesOrderStatus = "E0002";
				}
				//	console.log("initiating Save...");
				datacontext.salesdocuments.create(newSalesDocument).done(function (data) {
					var msg = "";

					vc.busyDlg.setText("Document " + data.SalesDocumentID + " created, reloading from SAP.");
					//		console.log("Save successful.");

					if (data.SalesDocumentID && data.CustomerID) {
						core.getModel("ciscoPayload").setData([]); // Initialize Cisco Payload
						currentState.setProperty("/isEditMode", false);
						currentState.setProperty("/isNotEditMode", true);
						currentState.setProperty("/canEdit", vc._canEdit());
						//								currentState.setProperty('/canEdit', (currentState.getProperty('/isQuote') || currentState.getProperty('/isPendingSalesOrder')));
						vc.copies.setProperty("/currentDocumentCopy", null);
						vc.copies.setProperty("/currentLinesCopy", []);
						vc.copies.setProperty("/currentCustomerCopy", null);

						if (!exit) {
							setTimeout(function () {
								vc._refreshSalesDocumentFromServer(data.SalesDocumentID, true, data.DocumentType).done(function () {
									vc.eventBus.publish("master", "salesDocAltered", data);
									sap.ui.core.UIComponent.getRouterFor(vc.view).navTo("detail", {
										orgData: data.Vkorg + data.Vtweg + data.Spart,
										salesDocId: data.SalesDocumentID,
										customerId: data.CustomerID,
										orderType: data.DocumentType,
										refresh: true,
										tab: "lineItems"
									}, true);
									def.resolve(data.SalesDocumentID);
								}).fail(function () {
									MessageBox.show(
										"SalesUI Saved this record to SAP but could not retrieve it again.  You will be returned to the document selection list.  If Document " +
										data.SalesDocumentID + " is not in that list, wait a few seconds and hit the refresh button.", {
											icon: MessageBox.Icon.ERROR,
											title: "SAP Error",
											actions: MessageBox.Action.OK,
											onClose: function () {
												if (vc.page) {
													vc.splitApp.toDetail(vc.splitApp.getInitialDetail());
													vc.splitApp.showMaster();
												}
												vc.currentSalesDocumentID = null;
												core.getModel("currentSalesDocument").setProperty("/SalesDocumentID", "");
												sap.ui.core.UIComponent.getRouterFor(vc.view).navTo("master", {
													from: "detail",
													orgData: data.Vkorg + data.Vtweg + data.Spart,
													customerId: data.CustomerID
												}, true);
											}
										});
									def.resolve(data.SalesDocumentID);
								});
							}, timeout);
						} else {
							def.resolve(data.SalesDocumentID);
						}

					} else {
						if (data && data.error && data.error.message && data.error.message.value) {
							msg = data.error.message.value;
						}
						def.reject(msg);
					}
				}).fail(function (msg) {
					def.reject(msg);
					vc._toggleEdit();
				});
			});

			return deferred.promise();
		},

		//Begin of Change: To get the results of Duplicate PO :Change by SXVASAMSETTI, 02/16/16			
		_checkDuplicatePO: function (CustPOID) {
			datacontext.customersPO.get(CustPOID, true).done(function (data) {
				if (!(data.Exist === "")) {
					vc.view.byId("Warning").setText("The entered PO already exist").addStyleClass("warning");
					vc.view.byId("createSalesOrderCPOID").setValueState("Warning");

				} else {
					vc._clearWarning();
				}

			});
		},
		//End of Change		

		_deepCompare: function () {
			var i, l, leftChain = [],
				rightChain = [];

			function compare2Objects(x, y) {

				// remember that NaN === NaN returns false
				// and isNaN(undefined) returns true
				if (isNaN(x) && isNaN(y) && typeof x === "number" && typeof y === "number") {
					return true;
				}

				// Compare primitives and functions.
				// Check if both arguments link to the same object.
				// Especially useful on step when comparing prototypes
				if (x === y) {
					return true;
				}

				// Works in case when functions are created in constructor.
				// Comparing dates is a common scenario. Another built-ins?
				// We can even handle functions passed across iframes
				if ((typeof x === "function" && typeof y === "function") ||
					(x instanceof Date && y instanceof Date) ||
					(x instanceof RegExp && y instanceof RegExp) ||
					(x instanceof String && y instanceof String) ||
					(x instanceof Number && y instanceof Number)) {
					return x.toString() === y.toString();
				}

				// At last checking prototypes as good a we can
				if (!(x instanceof Object && y instanceof Object)) {
					return false;
				}

				if (x.isPrototypeOf(y) || y.isPrototypeOf(x)) {
					return false;
				}

				if (x.constructor !== y.constructor) {
					return false;
				}

				if (x.prototype !== y.prototype) {
					return false;
				}

				// Check for infinitive linking loops
				if (leftChain.indexOf(x) > -1 || rightChain.indexOf(y) > -1) {
					return false;
				}

				// Quick checking of one object beeing a subset of another.
				// todo: cache the structure of arguments[0] for performance
				for (var p in y) {
					if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
						return false;
					} else if (typeof y[p] !== typeof x[p]) {
						return false;
					}
				}

				for (var p in x) {
					if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
						return false;
					} else if (typeof y[p] !== typeof x[p]) {
						return false;
					}

					switch (typeof (x[p])) {
					case "object":
					case "function":

						leftChain.push(x);
						rightChain.push(y);

						if (!compare2Objects(x[p], y[p])) {
							return false;
						}

						leftChain.pop();
						rightChain.pop();
						break;
					default:
						if (x[p] !== y[p]) {
							return false;
						}
						break;
					}
				}

				return true;
			}

			if (arguments.length < 1) {
				return true;
			}

			for (i = 1, l = arguments.length; i < l; i++) {

				leftChain = []; //Todo: vc can be cached
				rightChain = [];

				if (!compare2Objects(arguments[0], arguments[i])) {
					return false;
				}
			}

			return true;
		},

		// Added by SXVASAMSETTI : 07/03/2017		
		handleSuggestCurrency: function (event, viewConroller) {
			var source = event.getSource(),
				term = event.getParameter("suggestValue") || source.getValue(),
				currencies = core.getModel("currencies").getData() || [],
				suggestions = [];

			suggestions = $.grep(currencies, function (n) {
				return n.Value.match(new RegExp(term, "i"));
			});

			source.destroySuggestionItems();
			for (var i = 0, len = (Boolean(suggestions)) ? suggestions.length : 0; i < len; i++) {
				source.addSuggestionItem(new sap.ui.core.Item({
					text: suggestions[i].Value + ' - ' + suggestions[i].Text
				}));
			}

		},

		handleChangeCurrency: function (event, viewConroller) {
			var source = event.getSource(),
				currency = source.getValue(),
				binding = source.getBinding('value'),
				context = binding.getContext(),
				model = binding.getModel(),
				data = (context) ? model.getProperty(context.getPath()) : model.getData(),
				sdHeader = $.extend(true, {}, data),
				currencies = core.getModel("currencies").getData() || [],
				found = false;

			//	source.setShowSuggestion(false);
			if (currency) {
				source.setValueState(sap.ui.core.ValueState.None);
				var results = $.grep(currencies, function (n) {
					return ((n.Value.toLowerCase() === currency.toLowerCase()) || (n.Value.toLowerCase() + ' - ' + n.Text.toLowerCase() ===
						currency.toLowerCase()));
				});
				if (!results || results.length === 0) {
					results = $.grep(currencies, function (n) {
						return n.Text.toLowerCase() === currency.toLowerCase();
					});
				}
				if (!!results && results.length === 1) {
					sdHeader.Currency = results[0].Value;
					this._determineExchangeRate(model, sdHeader);
					if (source.getValueState() === sap.ui.core.ValueState.Error) {
						source.setValueState(sap.ui.core.ValueState.None);
						source.setTooltip();
					}
					if (Boolean(context)) {
						model.setProperty(context.getPath(), sdHeader);
					} else {
						model.setData(sdHeader);
					}
					found = true;
				}

				if (!found) {
					source.setTooltip("Entered Unit of Currency(" + currency +
						") is not in Master Data.  If this is the correct name, please contact Master Data Management.");
					source.setValueState(sap.ui.core.ValueState.Error);
					return false;
				}
			} else {
				sdHeader.Currency = "";
				source.setTooltip("Currency is a required field, please enter.");
				source.setValueState(sap.ui.core.ValueState.Error);
				return false;
			}
			/*			$.sap.delayedCall(0, this, function () {
							source.setShowSuggestion(true);
			        			});	*/

		},
		handlePriceDateChange: function (event) {
			var source = event.getSource(),
				priceDate = source.getValue(),
				binding = source.getBinding("dateValue"),
				context = binding.getContext(),
				model = binding.getModel(),
				salesDoc = (context) ? model.getProperty(context.getPath()) : model.getData();

			if (Boolean(priceDate)) {
				source.setTooltip();
				source.setValueState(sap.ui.core.ValueState.None);
				this._determineExchangeRate(model, salesDoc);
			} else {
				source.setTooltip("Pricing Date is mandatory to calculate Exchange Rate");
				source.setValueState(sap.ui.core.ValueState.Error);
			}

		},

		_determineExchangeRate: function (salesDocmodel, salesDoc) {
			var priceDate = "";
			var date = new Date(salesDoc.PriceDate);
			priceDate = date.getFullYear();
			if (date.getMonth() < 10) {
				priceDate = priceDate + "0" + date.getMonth();
			} else {
				priceDate = priceDate + date.getMonth();
			}
			if (date.getDate() < 10) {
				priceDate = priceDate + "0" + date.getDate();
			} else {
				priceDate = priceDate + date.getDate();
			}

			var model = core.getModel();
			model.callFunction("/HelpValues", "GET", {
					helpName: "ExchangeRate",
					inputValue: salesDoc.Vkorg + "-" + salesDoc.Currency + "-" + priceDate
				}, null,
				function (data, response) { //success    			        
					if (response.statusCode >= 200 && response.statusCode <= 299) {
						var result = data.results[0];
						if (Boolean(result)) {
							salesDoc.ExchangeRate = result.Value.toString().replace(/\s+/g, "");
							if (!salesDoc.Currency) {
								salesDoc.Currency = result.Text;
							}
						}
						salesDocmodel.setData(salesDoc);
					} else {
						salesDocmodel.setData(salesDoc);
					}

				},
				function (data) { //error
					salesDocmodel.setData(salesDoc);
				},
				false // Async
			);

		},
		// Ended by SXVASAMSETTI : 07/03/2017

		handleSuggestMfr: function (event) {
			var term = event.getParameter("suggestValue"),
				source = event.getSource(),
				mfrs = vc.view.getModel("globalSelectItems").getData()["Manufacturers"] || [],
				vdrs = vc.view.getModel("globalSelectItems").getData()["Vendors"] || [],
				isMfr = (source.getBinding("value").getPath() === 'ManufacturerID'),
				suggestions = [];

			if (!Boolean(term)) {
				return;
			} else {
				if (term.length < 3) {
					return;
				}
			}

			suggestions = $.grep((isMfr) ? mfrs : vdrs, function (n) {
				return n.ManufacturerName.match(new RegExp(term, "i"));
			});

			source.destroySuggestionItems();
			for (var i = 0, len = (Boolean(suggestions)) ? suggestions.length : 0; i < len; i++) {
				source.addSuggestionItem(new sap.ui.core.Item({
					text: suggestions[i].ManufacturerName
				}));
			}
		},

		handleChangeMfrID: function (event) {
			var source = event.getSource(),
				manufacturerName = source.getValue(),
				binding = source.getBinding("value"),
				context = binding.getContext(),
				model = binding.getModel(),
				row = (context) ? model.getProperty(context.getPath()) : model.getData(),
				saveRow = $.extend(true, {}, row),
				mfrs = vc.view.getModel("globalSelectItems").getData()["Manufacturers"] || [],
				vdrs = vc.view.getModel("globalSelectItems").getData()["Vendors"] || [],
				results = [],
				vdrMatch = null,
				found = false,
				isMfr = (source.getBinding("value").getPath() === "ManufacturerID"),
				mfrorvendor = (binding.getPath() === "ManufacturerID") ? "Manufacturer" : "Vendor";

			if (manufacturerName) {
				source.setValueState(sap.ui.core.ValueState.None);
				results = $.grep((isMfr) ? mfrs : vdrs, function (n) {
					return n.ManufacturerName.toLowerCase() === manufacturerName.toLowerCase();
				});
				if (!results || results.length === 0) {
					results = $.grep((isMfr) ? mfrs : vdrs, function (n) {
						return n.ManufacturerID === manufacturerName;
					});
				}
				if (!!results && results.length === 1) {
					if (isMfr) {
						row.ManufacturerID = results[0].ManufacturerID;
						row.MaterialID = "";
						row.ManufacturerPartID = "";
						row.CustomerPartID = "";
						row.CustomerMaterialID = "";
						vdrMatch = _.findWhere(vdrs, {
							SortL: results[0].SortL
						});
						if (vdrMatch) {
							row.VendorID = vdrMatch.ManufacturerID;
						}
					} else {
						row.VendorID = results[0].ManufacturerID;
						if (row.VendorID !== saveRow.VendorID) {
							if (!row.ParentLineID || row.ParentLineID === "000000") {
								vc._makeTotalConfiguredItemLikeThis(row, model, ["VendorID"]);
							} else {
								if (row.ItemCategory.substring(0, 1) !== "Y") {
									MessageBox.show(
										"You have selected a different vendor for a child of a configured item.\nDoes vc item need to come to GDT for Staging?",
										MessageBox.Icon.WARNING,
										"Stage Configured Item?", [MessageBox.Action.YES, MessageBox.Action.NO],
										function (resp) {
											if (resp === "YES") {
												row.ItemCategory = vc._determineItemCategoryForStaging(row);
												vc._makeTotalConfiguredItemLikeThis(row, model, ["ItemCategory"]);
											}
										},
										MessageBox.Action.YES);
								}
							}
						}

					}
					if (source.getValueState() === sap.ui.core.ValueState.Error) {
						source.setValueState(sap.ui.core.ValueState.None);
						source.setTooltip();
					}
					if (isMfr) {
						model.setProperty(context.getPath(), row);
					} else {
						model.setProperty("/VendorID", results[0].ManufacturerID);
						//	    	             			model.setProperty('/HasDistroFlag', (row.ManufacturerID != row.VendorID || row.ManufacturerPartID != row.CustomerPartID));
					}
					found = true;
				}

				if (!found) {
					source.setTooltip(mfrorvendor + manufacturerName +
						" is not in Master Data.  If this is the correct name, please contact Master Data Management.");
					source.setValueState(sap.ui.core.ValueState.Error);
					return false;
				}
			} else {
				if (binding.getPath() === "ManufacturerID") {
					row.ManufacturerID = 0;
				} else {
					row.VendorID = 0;
				}
				source.setTooltip(mfrorvendor + " is a required field, please enter.");
				source.setValueState(sap.ui.core.ValueState.Error);
				return false;
			}
		},

		handleOutputTypeChanged: function (event) {
			var button = event.getParameter("button"),
				text = button.getText();

			switch (text.toLowerCase()) {
			case "std":
				core.getModel("currentState").setProperty("/outputType", "ZAN1");
				break;
			case "detailed":
				core.getModel("currentState").setProperty("/outputType", "ZAN2");
				break;
			case "engineering":
				core.getModel("currentState").setProperty("/outputType", "ZAN3");
				break;
			case "dtl.eng.":
				core.getModel("currentState").setProperty("/outputType", "ZAN4");
				break;
			}
		},

		handlePressBillingBlock: function (event) {
			var currentSalesDocument = vc.view.getModel("currentSalesDocument"),
				billingBlock = currentSalesDocument.getProperty("/BillingBlock");

			if (billingBlock === "") {
				MessageBox.confirm(
					"Setting a Billing Block will prevent any further billing activities against this Sales Order until it is cleared.  Are you sure you wish to set a Billing Block?",
					function (confirmation) {
						if (confirmation === "OK") {
							currentSalesDocument.setProperty("/BillingBlock", "Z1");
							vc._doSave();
						}
					},
					"Confirm Set Billing Block");
			} else {
				MessageBox.confirm(
					"Clearing this Billing Block allow this Sales Order to be billed to the customer when deliveries are complete or immediately if the deliveries are already complete.  Are you sure you wish to clear the Billing Block?",
					function (confirmation) {
						if (confirmation === "OK") {
							currentSalesDocument.setProperty("/BillingBlock", "");
							vc._doSave();
						}
					},
					"Confirm Clear Billing Block");
			}
		},

		_cleanDocument: function () {
			core.getModel("currentTotals").setData({});
			core.getModel("currentSalesDocumentLines").setData([]);
			core.getModel("currentSalesDocument").setData({});
			core.getModel("currentAttachments").setData([]);
			core.getModel("currentVia").setData({});

		},

		handleExitButtonPress: function () {
			vc._exit();
		},

		_exit: function () {
			if (core.getModel("currentState").getProperty("/isEditMode")) {
				MessageToast.show("Cannot exit to Customer selection page whilst in Edit Mode.");
				return false;
			}

			vc._cleanDocument();
			vc.splitApp.toDetail(vc.splitApp.getInitialDetail());
			vc.splitApp.showMaster();

			vc.router.navTo("customer", {
				from: "customer",
				orgData: vc.orgData,
				customerId: vc.currentCustomerID
			}, true);
		},

		handleNavButtonPress: function (event) {
			if (core.getModel("currentState").getProperty("/isEditMode")) {
				MessageToast.show("Cannot return to Document selection page whilst in Edit Mode.");
				return false;
			}

			vc._cleanDocument();
			vc.splitApp.toDetail(vc.splitApp.getInitialDetail());
			vc.splitApp.showMaster();

			if (Boolean(event)) {
				event.preventDefault();
			}
			vc.router.navTo("master", {
				from: "customer",
				orgData: vc.orgData,
				customerId: vc.currentCustomerID
			}, true);
		},

		handleRefresh: function () {
			if (core.getModel("currentState").getProperty("/isEditMode")) {
				MessageToast.show("Cannot refresh page whilst in Edit Mode.");
				return false;
			}

			vc._refreshSalesDocumentFromServer(core.getModel("currentSalesDocument").getProperty("/SalesDocumentID"), true, core.getModel(
				"currentSalesDocument").getProperty("/DocumentType"));
			var iconTabBar = vc.view.byId("iconTabBar");
			if (iconTabBar && (iconTabBar.getSelectedKey() === "docflow")) {
				vc._refreshDocumentFlowFromServer(core.getModel("currentSalesDocument").getProperty("/ReferencedBy") || core.getModel(
					"currentSalesDocument").getProperty("/SalesDocumentID"), true);
			}
		},

		handlePaste: function (event) {
			var e = event.originalEvent,
				data = (e.type === "paste") ? e.clipboardData.getData("text") : "",
				target = event.target,
				tbl = vc.view.byId("lineItemsTable"),
				rows = vc.view.getModel("currentSalesDocumentLines").getData(),
				//done = false,
				td = null,
				tr = null,
				body = null,
				startRow = tbl.getFirstVisibleRow(),
				//	lastRow = 0,
				numRows = (data) ? rows.length : 0,
				pasteRowNum = 0,
				pasteColNum = 0,
				tokens = [],
				tokencount = 0;

			if (numRows === 0) {
				return;
			}

			vc.page.setBusyIndicatorDelay(0);
			vc.page.setBusy(true);

			setTimeout(function () {
				var details = vc.view.getModel("currentSalesDocumentLines"),
					errors = [],
					detailsArray = _.map(details.getData(), _.clone);

				td = $(target).closest("td");

				if (td) {
					tr = $(td).closest("tr");
				}

				if (tr) {
					pasteColNum = _.findIndex(tr.children(), {
						id: $(td).attr("id")
					});
					body = tr.closest("tbody");
				}

				if (body) {
					var lastRow = body.children().length - 1;
					pasteRowNum = _.findIndex(body.children(), {
						id: $(tr).attr("id")
					});
				}

				if (core.getModel("currentState").getProperty("/isEditMode")) {
					tokens = _.without(data.split(/\r\n|\r|\n/g), ''); // split('\r');
					tokencount = tokens.length;

					tokens = _.map(tokens, function (token) { // strip commas and $ or % signs
						if (token.replace(/[^0-9$.,]/g, "") === token) {
							return token.replace(/[^0-9.]/g, "");
						}

						return token;
					});

					for (var i = 0; i < (tokencount - (numRows - (startRow + pasteRowNum))); i++) {
						detailsArray.push(vc._createNewLine(detailsArray));
					}
					setTimeout(function () {
						var c = _.find(tbl.getColumns(), function (col) {
								var colid = col.getAggregation("template").getId(),
									trgid = target.getAttribute("id").substring(0, colid.length);

								return colid === trgid;
							}),
							mfr = null,
							t = (c) ? c.getTemplate() : null,
							bindingInfo = (t) ? t.getBindingInfo('value') : null,
							parts = (bindingInfo) ? bindingInfo.parts : null,
							firstPart = (parts && parts.length > 0) ? parts[0] : null,
							keys = [],
							shipTos = core.getModel("customerSelectItems").getProperty("/ShipTos"),
							addressIDs = [],
							missingAddresses = [],
							customerID = core.getModel("currentCustomer").getProperty("/CustomerID"),
							path = (firstPart) ? firstPart.path : null;

						if (path) {
							if (path === "CustomerPartID" || path === "ManufacturerPartID") {
								_.each(tokens, function (token) {
									var key = {
										CustomerID: customerID,
										ManufacturerID: "0",
										MaterialID: "",
										MfrPartID: ($.isNumeric(token)) ? token.toUpperCase().trim().replace(/^0+/, "") : token.toUpperCase().trim()
									};

									if (key.MfrPartID.length === 9 && parseInt(key.MfrPartID).toString() === key.MfrPartID) { // GDT SAP Material ID
										key.MaterialID = key.MfrPartID;
										key.MfrPartID = "";
									}
									if (!!key.MaterialID || !!key.MfrPartID) {
										keys.push(key);
									}
								});
								keys = _.uniq(keys, function (key) {
									return key.MaterialID + key.MfrPartID;
								});
								keys = _.filter(keys, function (key) {
									return !datacontext.materials.getLocal(key);
								});
								if (keys.length > 0) {
									try {
										datacontext.materials.load(keys).done(function () {
											var result;
											_.each(detailsArray, function (r, i) {
												if ((i >= (startRow + pasteRowNum)) && ((i - (startRow + pasteRowNum)) < tokencount)) {
													result = vc._lookupPartID(detailsArray[i], tokens[i - (startRow + pasteRowNum)], true, (path === "CustomerPartID"),
														null, null, true);
													if (Boolean(result)) {
														if (Boolean(result.MaterialID)) {
															detailsArray[i] = result;
														} else {
															result.CustomerPartID = tokens[i - (startRow + pasteRowNum)];
															errors.push(result);
														}
													}
												}
											});
											if (errors.length === 0) {
												/// Restrict to add Materials with 4 Series to UI					
												var Seeries4Material = _.find(detailsArray, function (row) {
													return (row.ItemCategory === "ZPFS" || row.ItemCategory === "YTAO" || row.ItemCategory === "ZTAO");
												});
												if (Seeries4Material === undefined || (!!Seeries4Material && Seeries4Material.length === 0)) {
													details.setData(detailsArray);
													vc._calculateTotals();
												} else {
													sap.m.MessageBox.show(
														"Sales UI does not allow to add materials starts with 4 Series ( Professional Services ). These materials are only maintained from SAP GUI by Projects/Launch team.", {
															icon: MessageBox.Icon.ERROR,
															title: "Authorizaton Issue",
															actions: MessageBox.Action.OK,
															onClose: null
														});
													vc.page.setBusy(false);
													return;

												}
											} else {
												errors = _.uniq(errors, function (error) {
													return error.CustomerPartID;
												});
												vc._presentImportErrors(errors);
											}
											vc.page.setBusy(false);
										}).fail(function (msg) {
											sap.m.MessageToast.show(msg);
											vc.page.setBusy(false);
										});
									} catch (e) {
										MessageToast.show("Couldn't load the pasted part numbers.");
										vc.page.setBusy(false);
									}
								} else {
									_.each(detailsArray, function (r, i) {
										if ((i >= (startRow + pasteRowNum)) && ((i - (startRow + pasteRowNum)) < tokencount)) {
											detailsArray[i] = vc._lookupPartID(detailsArray[i], tokens[i - (startRow + pasteRowNum)], true, (path ===
												'CustomerPartID'), null, null, true);
										}
									});

									/// Restrict to add Materials with 4 Series to UI					
									var Seeries4Material = _.find(detailsArray, function (row) {
										return (row.ItemCategory === 'ZPFS' || row.ItemCategory === 'YTAO' || row.ItemCategory === 'ZTAO');
									});
									if (Seeries4Material === undefined || (!!Seeries4Material && Seeries4Material.length === 0)) {
										details.setData(detailsArray);
										vc._calculateTotals();
										vc.page.setBusy(false);
									} else {
										MessageBox.show(
											"Sales UI does not allow to add materials starts with 4 Series ( Professional Services ). These materials are only maintained from SAP GUI by Projects/Launch team.", {
												icon: MessageBox.Icon.ERROR,
												title: "Authorizaton Issue",
												actions: MessageBox.Action.OK,
												onClose: null
											});
										vc.page.setBusy(false);
										return;

									}
								}
							} else {
								if (path === "ShipToID") {
									_.each(tokens, function (token) {
										var address = addressHelper.find(token, shipTos);

										if (Boolean(address)) {
											addressIDs.push(address.PartnerID);
										} else {
											missingAddresses.push(token);
										}
									});
									if (missingAddresses.length === 0) {
										_.each(detailsArray, function (r, i) {
											if ((i >= (startRow + pasteRowNum)) && ((i - (startRow + pasteRowNum)) < tokencount)) {
												detailsArray[i][path] = addressIDs[i - (startRow + pasteRowNum)];
											}
										});
										details.setData(detailsArray);
										vc._calculateTotals();
										vc.page.setBusy(false);
									} else {
										missingAddresses = _.uniq(missingAddresses);
										vc._presentAddressErrors(missingAddresses);
										vc.page.setBusy(false);
									}
								} else {
									_.each(rows, function (r, i) {
										if ((i >= (startRow + pasteRowNum)) && ((i - (startRow + pasteRowNum)) < tokencount)) {
											switch (path) {
											case "ManufacturerID":
												mfr = _.findWhere(vc.view.getModel("globalSelectItems").getProperty("/Manufacturers"), {
													ManufacturerName: tokens[i - (startRow + pasteRowNum)]
												});
												detailsArray[i][path] = (Boolean(mfr)) ? mfr.ManufacturerID : "";
												break;
											case "VendorID":
												mfr = _.findWhere(vc.view.getModel("globalSelectItems").getProperty("/Vendors"), {
													ManufacturerName: tokens[i - (startRow + pasteRowNum)]
												});
												detailsArray[i][path] = (Boolean(mfr)) ? mfr.ManufacturerID : "";
												break;
											default:
												detailsArray[i][path] = tokens[i - (startRow + pasteRowNum)];
												break;
											}
										}
									});
									details.setData(detailsArray);
									vc._calculateTotals();
									vc.page.setBusy(false);
								}
							}
						}
					});
				}
			});
			event.preventDefault();
			event.stopPropagation();

		},

		handleClearRejected: function (event) {
			var source = event.getSource(),
				binding = source.getBinding("visible").getBindings()[0], // Complex binding expression
				context = binding.getContext(),
				model = binding.getModel(),
				row = model.getProperty(context.getPath());

			if (!core.getModel("currentState").getProperty("/isEditMode")) {
				return;
			}
			if (Boolean(row.WBSElement)) {
				return;
			}
			if (!row.ReasonForRejection) {
				return;
			}
			if (Boolean(row.MarkedAsDeleted)) {
				return;
			}
			if (Boolean(row.DeletedFlag)) {
				return;
			}

			sap.m.MessageBox.confirm(
				"Clearing the reason for rejection will resubmit this line to Procurement when you hit 'Save'.  Are you sure you wish to clear the reason for rejection?",
				function (confirmation) {
					if (confirmation !== "CANCEL") {
						model.setProperty(context.getPath() + "/ReasonForRejection", "");
						//	model.setProperty(context.getPath() + '/Selected', false);
						row = model.getProperty(context.getPath());
						vc._makeChildItemsLikeThis(row, model, "ReasonForRejection");
						vc._calculateTotals();
					}
				}, "Clear Reason for Rejection?");

		},

		handleChangeDetailLineDeliveryDate: function (event) {
			var source = event.getSource(),
				binding = source.getBinding("dateValue"),
				context = binding.getContext(),
				model = binding.getModel(),
				row = (context) ? model.getProperty(context.getPath()) : model.getData();

			vc._makeTotalConfiguredItemLikeThis(row, model, ["DeliveryDate"]);
		},

		handleChangeCustomerPOID: function (event) {
			var source = event.getSource(),
				binding = source.getBinding("value"),
				context = binding.getContext(),
				model = binding.getModel(),
				row = (context) ? model.getProperty(context.getPath()) : model.getData();

			vc._makeTotalConfiguredItemLikeThis(row, model, ["CustomerPOID"]);
		},

		handleSelectCOE: function (event) {
			var source = event.getSource(),
				//	currentDocument     = vc.view.getModel('currentSalesDocument').getData(),
				currentDocumentCopy = vc.copies.getProperty("/currentDocumentCopy");

			if (source.getSelected()) {
				vc.view.getModel("currentSalesDocument").setProperty("/PoSupplement", "Z000");
			} else {
				if (currentDocumentCopy.PoSupplement !== "Z000") {
					vc.view.getModel("currentSalesDocument").setProperty("/PoSupplement", currentDocumentCopy.PoSupplement);
				} {
					vc.view.getModel("currentSalesDocument").setProperty("/PoSupplement", "");
				}
			}

		},

		_getDialog: function () {
			var busyDlg = vc._CiscoPunchoutCredentialsDialog;
			// instantiate dialog
			if (!busyDlg) {
				busyDlg = vc._CiscoPunchoutCredentialsDialog = sap.ui.xmlfragment("gdt.salesui.s4.fragment.CiscoPunchoutCredentials", vc);
				vc.getView().addDependent(busyDlg);
			}
			return busyDlg;
		},

		handleCiscoPunchoutCCW: function (event) {
			if (vc._isDirty()) {

				MessageBox.show(
					"Changes have been made, Do you want to keep thes line items and append further line Items from Cisco Punchout?", {
						icon: MessageBox.Icon.INFORMATION,
						title: "Cisco Punchout Confirmation",
						actions: [MessageBox.Action.YES, MessageBox.Action.NO],
						onClose: vc._onCLoseCiscoPunchoutConfirmation
					}
				);

			} else {
				vc._ciscoPunchout();

			}

			return;
			vc._getDialog().open(null);
		},

		_onCLoseCiscoPunchoutConfirmation: function (oAction) {
			var reqid = Math.floor(Math.random() * 9000000000) + 1000000000;
			if (oAction === "YES") {

				vc._doSaveDraft(reqid).done(function (id) {
					vc._ciscoPunchout("af", reqid); // a = append f = function
				}).fail(function (msg) {
					sap.m.MessageBox.show((msg) ? msg : "SalesUI unable to keep Unsaved Lines", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "SAP Error",
						actions: sap.m.MessageBox.Action.OK,
						onClose: null
					});
				}).always(function () {

				});
			} else if (oAction === "NO") {

				vc._ciscoPunchout(null, reqid);
			}
		},

		_ciscoPunchout: function (fxn, i_reqid) {
			var reqid;
			if (Boolean(i_reqid)) {
				reqid = i_reqid;
			} else {
				reqid = Math.floor(Math.random() * 9000000000) + 1000000000;
			}
			if (Boolean(fxn)) {
				reqid = fxn + reqid; // a = append f = function
			} else {
				var lines = vc.view.getModel("currentSalesDocumentLines").getData(),
					lines = _.reject(lines, function (line) {
						return !line.MaterialID;
					});
				if (lines.length > 0) {
					reqid = 'af' + reqid; // a = append f = function
				} else {
					reqid = 'if' + reqid; // a = ignore f = function
				}
			}

			reqid = vc._reqType + 'f' + reqid; // f = function ( _reqType -> Q = Quote , E = Estimate )
			ciscoPunchOut.prepareCXMLDoc(null, vc, reqid);
		},

		_doSaveDraft: function (reqid, i_draftType, i_draftName) {
			var currentState = vc.view.getModel("currentState"),
				deferred = null,
				draftType = (Boolean(i_draftType)) ? i_draftType.toString() : "01",
				draftName = (Boolean(i_draftName)) ? i_draftName.toString() : "Cisco Punchout",
				linesCopy = [];

			deferred = $.Deferred(function (def) {
				var currentLinesData = vc.view.getModel("currentSalesDocumentLines").getData(),
					currentSalesDocumentData = vc.view.getModel("currentSalesDocument").getData(),
					currentPayloadData = core.getModel("ciscoPayload").getData();
				currentLinesData = _.reject(currentLinesData, function (line) {
					return !line.MaterialID;
				});
				currentLinesData.DummyLineId = currentLinesData.SalesDocumentLineID + currentLinesData.ShipToID;

				var currentLinesStringData = JSON.stringify(currentLinesData),
					currentSalesDocumentStringData = JSON.stringify(currentSalesDocumentData),
					currentPayloadStringData = JSON.stringify(currentPayloadData);

				if (Boolean(currentLinesStringData)) {
					console.log("DataExist");
					var draft = {
						"DraftId": "create",
						"DraftType": draftType, // 01 - Draft before Cisco Punchout or 02 - Sales UI Manual Draft
						"Kunnr": currentSalesDocumentData.CustomerID,
						"DraftName": draftName,
						"HDraft": currentSalesDocumentStringData,
						"IDraft": currentLinesStringData,
						"PDraft": currentPayloadStringData,
						"Reqid": reqid.toString(),
						"Ernam": "",
						"Vbeln": currentSalesDocumentData.SalesDocumentID,
						"PunchoutTime": new Date()
					};

					datacontext.draft.create(draft).done(function (data) {
						def.resolve(data);
					}).fail(function (msg) {
						def.reject(msg);

					});

				}

				//def.resolve(data.SalesDocumentID);
				//def.reject(msg);
			});

			return deferred.promise();
		},

		// Begin of changes:SXVASAMSETTI; Partial Submission changes
		//Display Delete Options
		handleCiscoPunchout: function (event) {
			var actionSheet = vc.view.byId("CiscoPunchoutActionSheet");

			if (actionSheet.isOpen()) {
				actionSheet.close();
			} else {
				actionSheet.openBy(event.getSource());
			}
		},

		handleCCWQuickQuote: function (event) {
			vc._reqType = "Q";
			vc.handleCiscoPunchoutCCW();
		},
		handleCCWEstimate: function (event) {
			vc._reqType = "E";
			vc.handleCiscoPunchoutCCW();
		},

		handleTriggerCiscoPunchout: function (event) {

			vc._getDialog().close();
			var ciscoPunchoutModel = vc.view.getModel("ciscoPunchout"),
				ciscoPunchoutData = ciscoPunchoutModel.getData();
			ciscoPunchOut.prepareCXMLDoc(ciscoPunchoutData, vc);
			return;
			/*			var deferred =  $.Deferred(function(defer) {
			        		vc.busyDlg.setText("Cisco Punchout out Initiated.Please wait until your Cart get trasferred.");
			        		vc.busyDlg.open();
			        	datacontext.ciscoPunchOut.get({"CiscoPw":ciscoPunchoutData.CiscoPw,"CiscoUserId":ciscoPunchoutData.CiscoUserId,"WebHookUrl":""},true).done( function(data){
			      
			          		defer.resolve(data );
			        	}).fail(function(msg){
			        		defer.reject(msg);
			        	});
			        	}).done(function(data){       		
			        		vc.busyDlg.close();
			        		var ciscoPunchoutModel = vc.view.getModel("ciscoPunchout");
			           		ciscoPunchoutModel.setData(data);
			           		ciscoPunchOut.prepareCXMLDoc();
			        	}).fail(function(msg){
			        		vc.busyDlg.close();
			         	   MessageBox.show( msg, {
									icon: MessageBox.Icon.ERROR,
									title: "Punchout Error",
									actions: MessageBox.Action.OK,
									onClose: null}); 	
			        		
			        	});
			        	return deferred;*/
			var checkEmail = function (email) {
				if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
					return (true);
				}
				alert("You have entered an invalid email address!");
				return (false);
			};

		},
		handleCancelCiscoPunchout: function (event) {
			vc._getDialog().close();
		}

	});

});