/* global _:true */
/* global gdt:true */
sap.ui.define([
		"gdt/salesui/s4/util/Controller",
		"sap/ui/core/Core",
		"gdt/salesui/s4/util/Formatter",
		"gdt/salesui/s4/data/DataLoader",
		"gdt/salesui/s4/data/DataContext",
		"sap/m/MessageBox"
	],
	function (Controller,
		core,
		formatter,
		loader,
		datacontext,
		MessageBox,
		vc) {
		"use strict";

		return Controller.extend("gdt.salesui.s4.controller.Master", {

			onInit: function () {
				vc = this;
				var closedQuotesList = null,
					openQuotesList = null,
					completedQuotesList = null,
					rejectedSalesOrdersList = null,
					pendingSalesOrdersList = null,
					openSalesOrdersList = null,
					closedSalesOrdersList = null,
					componentId = null,
					eventBus = null;

				vc.view = this.getView();
				vc.page = vc.view.byId("masterpage");
				vc.splitApp = core.byId("app").byId("fioriContent");
				closedQuotesList = vc.view.byId("closedQuotesList");
				openQuotesList = vc.view.byId("openQuotesList");
				completedQuotesList = vc.view.byId("completedQuotesList");
				rejectedSalesOrdersList = vc.view.byId("rejectedSalesOrdersList");
				pendingSalesOrdersList = vc.view.byId("pendingSalesOrdersList");
				openSalesOrdersList = vc.view.byId("openSalesOrdersList");
				closedSalesOrdersList = vc.view.byId("closedSalesOrdersList");
				componentId = sap.ui.core.Component.getOwnerIdFor(vc.view);
				eventBus = sap.ui.component(componentId).getEventBus();

				vc.page.setModel(core.getModel("i18n"), "i18n");
				vc.page.setModel(core.getModel("device"), "device");
				vc.page.setModel(core.getModel("currentCustomer"));
				vc.page.setModel(core.getModel("currentCustomerBalances"), "currentCustomerBalances");
				vc.page.setModel(core.getModel("globalSelectItems"), "globalSelectItems");
				vc.page.setModel(core.getModel("customerSelectItems"), "customerSelectItems");
				vc.page.setModel(core.getModel("systemInfo"), "systemInfo");
				vc.page.setModel(core.getModel("userPref"), "userPref");
				vc.view.setModel(core.getModel("userPref"), "userPref");
				closedQuotesList.setModel(core.getModel("closedQuotes"), "closedQuotes");
				openQuotesList.setModel(core.getModel("openQuotes"), "openQuotes");
				completedQuotesList.setModel(core.getModel("completedQuotes"), "completedQuotes");
				rejectedSalesOrdersList.setModel(core.getModel("rejectedSalesOrders"), "rejectedSalesOrders");
				pendingSalesOrdersList.setModel(core.getModel("pendingSalesOrders"), "pendingSalesOrders");
				openSalesOrdersList.setModel(core.getModel("openSalesOrders"), "openSalesOrders");
				closedSalesOrdersList.setModel(core.getModel("closedSalesOrders"), "closedSalesOrders");

				vc.view.addStyleClass("sapUiSizeCompact");

				eventBus.subscribe("master", "salesDocAltered", function (channelId, eventId, data) {
					var results = [];

					vc.page.setBusyIndicatorDelay(0);
					vc.page.setBusy(true);

					setTimeout(function () {
						results = _.sortBy(datacontext.salesdocuments.getLocalByForeignKey(data.CustomerID), function (line) {
							return parseInt(line.SalesDocumentID) * -1;
						});
						core.getModel("closedQuotes").setData(_.filter(results, function (sd) {
							return (sd.DocumentCategory === "B" && sd.ValidTo < new Date() && sd.Status !== "C");
						}));
						core.getModel("openQuotes").setData(_.filter(results, function (sd) {
							return (sd.DocumentCategory === "B" && sd.ValidTo >= new Date() && sd.Status !== "C");
						}));
						core.getModel("completedQuotes").setData(_.filter(results, function (sd) {
							return (sd.DocumentCategory === "B" && sd.Status === "C");
						}));
						core.getModel("rejectedSalesOrders").setData(_.filter(results, function (sd) {
							return (sd.DocumentCategory === "C" && sd.RejectionStatus !== "A" && sd.SalesOrderStatus !== "E0002");
						}));
						core.getModel("pendingSalesOrders").setData(_.filter(results, function (sd) {
							return (sd.DocumentCategory === "C" && sd.SalesOrderStatus !== "E0002" && sd.RejectionStatus === "A");
						}));
						core.getModel("openSalesOrders").setData(_.filter(results, function (sd) {
							return (sd.DocumentCategory === "C" && sd.SalesOrderStatus === "E0002" && sd.Status !== "C" && sd.RejectionStatus !== "C");
						}));
						core.getModel("closedSalesOrders").setData(_.filter(results, function (sd) {
							return (sd.DocumentCategory === "C" && sd.SalesOrderStatus === "E0002" && (sd.Status === "C" || sd.RejectionStatus ===
								"C"));
						}));
						vc.page.setBusy(false);
					});
				});

				sap.ui.core.UIComponent
					.getRouterFor(this)
					.attachRouteMatched(
						function (event) {
							//	if (event.getParameter("name") === "master") {
							var args = event.getParameter("arguments"),
								customerId = core.getModel("currentCustomer").getProperty("/CustomerID");

							//	if (( !customerId && (customerId !== args.customerId) ) || arguments.refresh) {
							if (!customerId && customerId !== args.customerId || arguments.refresh) {
								vc.page.setBusyIndicatorDelay(0);
								vc.page.setBusy(true);

								setTimeout(function () {
									var lv_vkorg = (args.orgData) ? args.orgData.substring(0, 4) : core.getModel("userPref").getProperty("/Vkorg");
									var lv_vtweg = (args.orgData) ? args.orgData.substring(4, 6) : core.getModel("userPref").getProperty("/Vtweg");
									var lv_spart = (args.orgData) ? args.orgData.substring(6, 8) : core.getModel("userPref").getProperty("/Spart");
									loader.loadCustomerInfo({
										"CustomerID": args.customerId,
										"Vkorg": lv_vkorg,
										"Vtweg": lv_vtweg,
										"Spart": lv_spart
									}).done(function () {
										vc._updateCurrentState();
										vc.page.setBusy(false);
										if (core.getModel("customerSelectItems").getProperty("/AccountManagers").length === 0) {
											MessageBox.show(
												"Customer with Sales Org(" + lv_vkorg + "-" + formatter.salesOrgText(lv_vkorg) +
												") has no assigned Account Manager(s). \n Please contact Master Data to resolve this issue before proceeding.", {
													icon: MessageBox.Icon.ERROR,
													title: "Customer Master Data Error",
													onClose: function () {
														vc._leaveCustomer();
													}
												});
										} else {
											if (!args.salesDocId) {
												vc.splitApp.showMaster();
											} else {
												vc.splitApp.hideMaster();
											}
										}
									}).fail(function (response) {
										vc.page.setBusy(false);
										sap.m.MessageToast.show("Failed to load customer details.  " + response);
										vc._leaveCustomer();
									});
								});
								//	}
							}
						}, this);
			},

			_updateCurrentState: function () {
				var currentState = core.getModel("currentState"),
					customerSelectItems = core.getModel("customerSelectItems"),
					endcustomers = customerSelectItems.getProperty("/EndCustomers");

				var endCustomerCount = (Boolean(endcustomers)) ? endcustomers.length : 0;
				currentState.setProperty("/hasEndCustomers", endCustomerCount !== 0);
			},

			_toggleCustomersCollapse: function (event, list) {
				var source = event.getSource();

				if (source.getIcon() === "sap-icon://collapse-group") {
					source.setIcon("sap-icon://expand-group");
					list.setVisible(false);
				} else {
					source.setIcon("sap-icon://collapse-group");
					list.setVisible(true);
				}

			},

			handleToggleOpenQuotesCollapse: function (event) {
				vc._toggleCustomersCollapse(event, this.getView().byId("openQuotesList"));
			},

			handleToggleCompletedQuotesCollapse: function (event) {
				vc._toggleCustomersCollapse(event, this.getView().byId("completedQuotesList"));
			},

			handleToggleClosedQuotesCollapse: function (event) {
				vc._toggleCustomersCollapse(event, this.getView().byId("closedQuotesList"));
			},

			handleToggleRejectedSalesOrdersCollapse: function (event) {
				vc._toggleCustomersCollapse(event, this.getView().byId("rejectedSalesOrdersList"));
			},

			handleTogglePendingSalesOrdersCollapse: function (event) {
				vc._toggleCustomersCollapse(event, this.getView().byId("pendingSalesOrdersList"));
			},

			handleToggleOpenSalesOrdersCollapse: function (event) {
				vc._toggleCustomersCollapse(event, this.getView().byId("openSalesOrdersList"));
			},

			handleToggleClosedSalesOrdersCollapse: function (event) {
				vc._toggleCustomersCollapse(event, this.getView().byId("closedSalesOrdersList"));
			},
			_setFilter: function (filter) {
				var listOpenQuotes = vc.view.byId("openQuotesList"),
					bindingOpenQuotes = listOpenQuotes.getBinding("items"),
					listCompletedQuotes = vc.view.byId("completedQuotesList"),
					bindingCompletedQuotes = listCompletedQuotes.getBinding("items"),
					listClosedQuotes = vc.view.byId("closedQuotesList"),
					bindingClosedQuotes = listClosedQuotes.getBinding("items"),
					listRejectedSalesOrders = vc.view.byId("rejectedSalesOrdersList"),
					bindingRejectedSalesOrders = listRejectedSalesOrders.getBinding("items"),
					listPendingSalesOrders = vc.view.byId("pendingSalesOrdersList"),
					bindingPendingSalesOrders = listPendingSalesOrders.getBinding("items"),
					listOpenSalesOrders = vc.view.byId("openSalesOrdersList"),
					bindingOpenSalesOrders = listOpenSalesOrders.getBinding("items"),
					listClosedSalesOrders = vc.view.byId("closedSalesOrdersList"),
					bindingClosedSalesOrders = listClosedSalesOrders.getBinding("items");

				bindingOpenQuotes.filter(filter);
				bindingCompletedQuotes.filter(filter);
				bindingClosedQuotes.filter(filter);
				bindingRejectedSalesOrders.filter(filter);
				bindingPendingSalesOrders.filter(filter);
				bindingOpenSalesOrders.filter(filter);
				bindingClosedSalesOrders.filter(filter);

			},

			handleSearch: function (event) {
				var filters = null,
					filter = null,
					searchString = this.getView().byId("searchField").getValue(),
					listOpenQuotes = this.getView().byId("openQuotesList"),
					buttonOpenQuotes = this.getView().byId("openQuotesToggle"),
					listCompletedQuotes = this.getView().byId("completedQuotesList"),
					buttonCompletedQuotes = this.getView().byId("completedQuotesToggle"),
					listClosedQuotes = this.getView().byId("closedQuotesList"),
					buttonClosedQuotes = this.getView().byId("closedQuotesToggle"),
					listRejectedSalesOrders = this.getView().byId("rejectedSalesOrdersList"),
					buttonRejectedSalesOrders = this.getView().byId("rejectedSalesOrdersToggle"),
					listPendingSalesOrders = this.getView().byId("pendingSalesOrdersList"),
					buttonPendingSalesOrders = this.getView().byId("pendingSalesOrdersToggle"),
					listOpenSalesOrders = this.getView().byId("openSalesOrdersList"),
					buttonOpenSalesOrders = this.getView().byId("openSalesOrdersToggle"),
					listClosedSalesOrders = this.getView().byId("closedSalesOrdersList"),
					buttonClosedSalesOrders = this.getView().byId("closedSalesOrdersToggle");

				if (event.getParameter("refreshButtonPressed")) {
					loader.loadCustomerInfo(core.getModel("currentCustomer").getProperty("/CustomerID"), true).done(function () {
						vc._updateCurrentState();
						vc.page.setBusy(false);
					}).fail(function (response) {
						vc.page.setBusy(false);
						sap.m.MessageToast.show("Failed to load customer details.  " + response);
						vc._leaveCustomer();
					});
					return;
				}

				if (searchString && searchString.length > 0) {
					filters = [new sap.ui.model.Filter("HeaderText", sap.ui.model.FilterOperator.Contains, searchString),
						new sap.ui.model.Filter("SalesDocumentID", sap.ui.model.FilterOperator.Contains, searchString),
						new sap.ui.model.Filter("ReferencedBy", sap.ui.model.FilterOperator.Contains, searchString)
					];

					filter = new sap.ui.model.Filter(filters, false);
					buttonClosedQuotes.setIcon("sap-icon://collapse-group");
					listClosedQuotes.setVisible(true);
					buttonOpenQuotes.setIcon("sap-icon://collapse-group");
					listOpenQuotes.setVisible(true);
					buttonCompletedQuotes.setIcon("sap-icon://collapse-group");
					listCompletedQuotes.setVisible(true);
					buttonRejectedSalesOrders.setIcon("sap-icon://collapse-group");
					listRejectedSalesOrders.setVisible(true);
					buttonPendingSalesOrders.setIcon("sap-icon://collapse-group");
					listPendingSalesOrders.setVisible(true);
					buttonOpenSalesOrders.setIcon("sap-icon://collapse-group");
					listOpenSalesOrders.setVisible(true);
					buttonClosedSalesOrders.setIcon("sap-icon://collapse-group");
					listClosedSalesOrders.setVisible(true);
				}

				vc._setFilter(filter);
			},

			handleSelect: function (event) {
				var listItem = event.getSource(),
					currentCustomer = core.getModel("currentCustomer").getData(),
					customerId = currentCustomer.CustomerID,
					orgData = currentCustomer.Vkorg + currentCustomer.Vtweg + currentCustomer.Spart,
					salesDocId = listItem.getBinding("title").getValue(),
					docType = listItem.getAttributes()[2].getText().split("-")[1].replace(/ /g, "");

				if (core.getModel("currentState").getProperty("/isEditMode")) {
					MessageBox.confirm(
						"Changing Sales Document while in Edit Mode will lose any unsaved changes. \n Are you sure you wish to leave this document?",
						function (confirmation) {
							if (confirmation === "OK") {
								core.getModel("currentState").setProperty("/forceRefresh", true);
								core.getModel("currentState").setProperty("/isEditMode", false);
								core.getModel("currentState").setProperty("/isNotEditMode", true);
								event.preventDefault();
								vc._goToSalesDocument(customerId, salesDocId, orgData, docType);
							} else {
								sap.m.MessageToast.show("Navigation canceled.");
								return false;
							}

						},
						"Confirm Cancel Edit");
				} else {
					vc._goToSalesDocument(customerId, salesDocId, orgData, docType);
					event.preventDefault();
				}
			},

			_goToSalesDocument: function (customerId, salesDocId, orgData, docType) {
				var currentDocId = core.getModel("currentSalesDocument").getProperty("/SalesDocumentID"),
					userPref = core.getModel("userPref").getData();

				if (!!currentDocId && currentDocId === salesDocId && parseInt(currentDocId) !== 0) {
					sap.m.MessageToast.show("Requested document already loaded.  Navigation canceled.");
					return;
				}

				vc.view.byId("searchField").setValue("");
				vc._setFilter(null);
				core.getModel("ciscoPayload").setData([]); // initialize payload data to initial
				sap.ui.core.UIComponent.getRouterFor(vc.view).navTo(
					"detail", {
						from: "master",
						tab: "lineItems",
						orgData: (Boolean(orgData)) ? orgData : userPref.Vkorg + userPref.Vtweg + userPref.Spart,
						customerId: customerId,
						orderType: docType,
						salesDocId: salesDocId
					});
			},

			handleNavButtonPress: function (event) {
				if (core.getModel("currentState").getProperty("/isEditMode")) {
					MessageBox.confirm(
						"Changing customer while in Edit Mode will lose any unsaved changes. \n Are you sure you wish to leave this customer?",
						function (confirmation) {
							if (confirmation === "OK") {
								core.getModel("currentSalesDocument").setData({});
								core.getModel("currentSalesDocumentLines").setData([]);
								core.getModel("currentState").setProperty("/isEditMode", false);
								core.getModel("currentState").setProperty("/isNotEditMode", true);
								event.preventDefault();
								vc._leaveCustomer();
							} else {
								sap.m.MessageToast.show("Navigation canceled.");
								return false;
							}

						},
						"Confirm Cancel Edit");
				} else {
					event.preventDefault();
					vc._leaveCustomer();
				}

			},

			handleFindByDocumentID: function () {
				var dialog = this.getView().byId("customerSearchByDocIDDialog"),
					msg = this.getView().byId("Msg"),
					input = this.getView().byId("SalesDocID"),
					router = sap.ui.core.UIComponent.getRouterFor(this),

					handler = function () {
						var docid = input.getValue();

						input.setValue("");

						if (!docid) {
							return;
						}
						input.setValueState("None");
						dialog.setBusy(true);
						dialog.setTitle("Searching Document.Please wait..");
						loader.loadSalesDocument(vc._pad(docid, 10)).done(function (data) {
							var salesDocument = core.getModel("currentSalesDocument").getData();
							core.getModel("currentState").setProperty("/forceRefresh", true);
							input.setValueState("None");
							dialog.close();
							dialog.setBusy(false);
							dialog.setTitle("Please enter the Sales Document ID");

							router.navTo(
								"detail", {
									from: "master",
									tab: "lineItems",
									orgData: salesDocument.Vkorg + salesDocument.Vtweg + salesDocument.Spart,
									customerId: salesDocument.CustomerID,
									orderType: salesDocument.DocumentType,
									salesDocId: salesDocument.SalesDocumentID
								});
						}).fail(function () {
							var newID = vc._pad(docid, 10);

							newID = newID.substring(3);
							newID = "002" + newID;
							loader.loadSalesDocument(vc._pad(docid, 10)).done(function (data) {
								var salesDocument = core.getModel("currentSalesDocument").getData();
								core.getModel("currentState").setProperty("/forceRefresh", true);
								input.setValueState("None");
								dialog.close();
								dialog.setBusy(false);
								dialog.setTitle("Please enter the Sales Document ID");
								router.navTo(
									"detail", {
										from: "master",
										tab: "lineItems",
										orgData: salesDocument.Vkorg + salesDocument.Vtweg + salesDocument.Spart,
										customerId: salesDocument.CustomerID,
										orderType: salesDocument.DocumentType,
										salesDocId: salesDocument.SalesDocumentID
									});
							}).fail(function () {
								dialog.setBusy(false);
								dialog.setTitle("Please enter the Sales Document ID");
								msg.setText("Sales Document Not Found");
								input.setValueState("Error");
							});
						});
					};

				dialog.removeAllButtons();

				input.onChange = handler;

				dialog.addStyleClass("sapUiSizeCompact");
				dialog.addButton(new sap.m.Button({
					text: "Search",
					enabled: true,
					press: handler
				}));
				dialog.addButton(new sap.m.Button({
					text: "Cancel",
					press: function () {
						dialog.close();
					}
				}));

				dialog.open();
				input.focus();
			},

			_leaveCustomer: function () {
				core.getModel("currentSalesDocument").setData({});
				core.getModel("currentSalesDocumentLines").setData([]);
				core.getModel("currentCustomer").setData({});
				core.getModel("currentCustomerBalances").setData({});
				core.getModel("customerSelectItems").setData({});
				core.getModel("closedQuotes").setData([]);
				core.getModel("openQuotes").setData([]);
				core.getModel("completedQuotes").setData([]);
				core.getModel("rejectedSalesOrders").setData([]);
				core.getModel("pendingSalesOrders").setData([]);
				core.getModel("openSalesOrders").setData([]);
				core.getModel("closedSalesOrders").setData([]);

				vc.view.byId("searchField").setValue("");
				vc._setFilter(null);

				vc.splitApp.toDetail(vc.splitApp.getInitialDetail());
				setTimeout(function () {
					sap.ui.core.UIComponent.getRouterFor(vc.view).navTo("customer", {}, true);
				}, 1000);
			},

			handleDetailTabChanged: function (chanel, event, data) {
				// var  tab = data.tabKey;
			},

			// Create New Quote
			handleCreateNewQuote: function (event) {
				var customerId = core.getModel("currentCustomer").getProperty("/CustomerID"),
					userPref = core.getModel("userPref").getData(),
					salesDocId = "0000000000",
					docType = "ZQT1",
					orgData = userPref.Vkorg + userPref.Vtweg + userPref.Spart;

				if (core.getModel("currentSalesDocument").getProperty("/SalesDocumentID") === salesDocId) {
					sap.m.MessageToast.show(
						"You cannot create a new document, you already are! \n If you wish to start a new quote, please exit this one first.");
					return false;
				}

				if (core.getModel("currentState").getProperty("/isEditMode")) {
					MessageBox.confirm(
						"Creating a new Sales Document while in Edit Mode will lose any unsaved changes. \n Are you sure you wish to leave this document?",
						function (confirmation) {
							if (confirmation === "OK") {
								core.getModel("currentState").setProperty("/forceRefresh", true);
								core.getModel("currentState").setProperty("/isEditMode", false);
								core.getModel("currentState").setProperty("/isNotEditMode", true);
								event.preventDefault();

								vc._goToSalesDocument(customerId, salesDocId, orgData, docType);

							} else {
								sap.m.MessageToast.show("Navigation canceled.");
								return false;
							}

						},
						"Confirm Cancel Edit");
				} else {
					vc._goToSalesDocument(customerId, salesDocId, orgData, docType);
					event.preventDefault();
				}
			},
			_pad: function (n, width, z) {
				var paddingChar = z || "0",
					stringToPad = n + "";
				return stringToPad.length >= width ? stringToPad : new Array(width - stringToPad.length + 1).join(paddingChar) + stringToPad;
			}
		});

	});