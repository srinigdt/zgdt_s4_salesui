/* global _:true */
/* global gdt:true */
sap.ui.define([
		"gdt/salesui/s4/util/Controller",
		"sap/ui/core/Core",
		"gdt/salesui/s4/util/Formatter",
		"gdt/salesui/s4/data/DataLoader",
		"gdt/salesui/s4/data/Preloader"
	],
	function (Controller,
		core,
		formatter,
		dataLoader,
		preLoader) {
		"use strict";

		return Controller.extend("gdt.salesui.s4.controller.Customer", {
			//var myPref;
			onInit: function () {
				var splitApp = null,
					view = this.getView(),
					page = view.byId("page");

				view.addStyleClass("sapUiSizeCompact");

				sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function (event) {
					// when detail navigation occurs, update the binding context
					if (event.getParameter("name") === "customer") {
						page.setModel(core.getModel("i18n"), "i18n");
						page.setModel(core.getModel("device"), "device");
						page.setModel(core.getModel("systemInfo"), "systemInfo");
						page.setModel(core.getModel("userPref"), "userPref");
						view.byId("myCustomerList").setModel(core.getModel("myCustomers"));
						view.byId("allCustomerList").setModel(core.getModel("allCustomers"));
						//myPref = getUserPreferences();
						//applyFavorites();
						splitApp = sap.ui.getCore().byId("app").byId("fioriContent");
						splitApp.showMaster();
					}
				}, this);
			},
			//getUserPreferences= function(){return {favoriteCustomers: []}},
			handleSearch: function () {
				var filters = null,
					filter = null,
					searchString = this.getView().byId("searchField").getValue(),
					listMy = this.getView().byId("myCustomerList"),
					bindingMy = listMy.getBinding("items"),
					listAll = this.getView().byId("allCustomerList"),
					bindingAll = listAll.getBinding("items");

				if (searchString && searchString.length > 0) {
					filters = [new sap.ui.model.Filter("CustomerName", sap.ui.model.FilterOperator.Contains, searchString),
						new sap.ui.model.Filter("CustomerID", sap.ui.model.FilterOperator.Contains, searchString),
						new sap.ui.model.Filter("Street", sap.ui.model.FilterOperator.Contains, searchString),
						new sap.ui.model.Filter("State", sap.ui.model.FilterOperator.Contains, searchString),
						new sap.ui.model.Filter("Zip", sap.ui.model.FilterOperator.Contains, searchString)
					];

					filter = new sap.ui.model.Filter(filters, false);
				}
				bindingMy.filter(filter);
				bindingAll.filter(filter);
			},

			toggleCustomersCollapse: function (event, list) {
				var source = event.getSource();

				if (source.getIcon() === "sap-icon://collapse-group") {
					source.setIcon("sap-icon://expand-group");
					list.setVisible(false);
				} else {
					source.setIcon("sap-icon://collapse-group");
					list.setVisible(true);
				}

			},

			handleToggleMyCustomersCollapse: function (event) {
				this.toggleCustomersCollapse(event, this.getView().byId("myCustomerList"));
			},

			handleToggleAllCustomersCollapse: function (event) {
				this.toggleCustomersCollapse(event, this.getView().byId("allCustomerList"));
			},

			handleFindByDocumentID: function () {
				var dialog = this.getView().byId("customerSearchByDocIDDialog"),
					msg = this.getView().byId("Msg"),
					input = this.getView().byId("SalesDocID");
				input.setValueState("None");
				var router = sap.ui.core.UIComponent.getRouterFor(this),
					vc = this,
					handler = function () {
						var docid = input.getValue();

						input.setValue("");

						if (!docid) {
							return;
						}
						input.setValueState("None");
						dialog.setBusy(true);
						dialog.setTitle("Searching Document.Please wait..");
						dataLoader.loadSalesDocument(vc._pad(docid, 10)).done(function (data) {
							var salesDocument = core.getModel("currentSalesDocument").getData();
							core.getModel("currentState").setProperty("/forceRefresh", true);
							input.setValueState("None");
							dialog.close();
							dialog.setBusy(false);
							dialog.setTitle("Please enter the Sales Document ID");
							router.navTo(
								"detail", {
									from: "master",
									tab: "lineItems",
									orgData: salesDocument.Vkorg + salesDocument.Vtweg + salesDocument.Spart,
									customerId: salesDocument.CustomerID,
									orderType: salesDocument.DocumentType,
									salesDocId: salesDocument.SalesDocumentID
								});
						}).fail(function () {
							var newID = vc._pad(docid, 10);

							newID = newID.substring(3);
							newID = "002" + newID;
							dataLoader.loadSalesDocument(vc._pad(docid, 10)).done(function (data) {
								var salesDocument = core.getModel("currentSalesDocument").getData();
								core.getModel("currentState").setProperty("/forceRefresh", true);
								input.setValueState("None");
								dialog.close();
								dialog.setBusy(false);
								dialog.setTitle("Please enter the Sales Document ID");
								router.navTo(
									"detail", {
										from: "master",
										tab: "lineItems",
										orgData: salesDocument.Vkorg + salesDocument.Vtweg + salesDocument.Spart,
										customerId: salesDocument.CustomerID,
										orderType: salesDocument.DocumentType,
										salesDocId: salesDocument.SalesDocumentID
									});
								vc._setCustShippingConditions(salesDocument.CustomerID);
							}).fail(function () {
								dialog.setBusy(false);
								dialog.setTitle("Please enter the Sales Document ID");
								msg.setText("Sales Document Not Found");
								input.setValueState("Error");
							});
						});
					};

				dialog.removeAllButtons();

				input.onChange = handler;

				dialog.addStyleClass("sapUiSizeCompact");
				dialog.addButton(new sap.m.Button({
					text: "Search",
					enabled: true,
					press: handler
				}));
				dialog.addButton(new sap.m.Button({
					text: "Cancel",
					press: function () {
						dialog.close();
					}
				}));

				dialog.open();
				input.focus();
			},

			handleSelectCustomer: function (event) {
				var listItem = event.getParameter("listItem") || event.getSource(),
					listMy = this.getView().byId("myCustomerList"),
					bindingMy = listMy.getBinding("items"),
					listAll = this.getView().byId("allCustomerList"),
					bindingAll = listAll.getBinding("items"),
					bindingContext = listItem.getBindingContext(),
					customerPath = bindingContext.getPath(),
					customerId = bindingContext.getModel().getObject(customerPath).CustomerID,
					salesOrgId = bindingContext.getModel().getObject(customerPath).Vkorg,
					distChannelId = bindingContext.getModel().getObject(customerPath).Vtweg,
					disivisionId = bindingContext.getModel().getObject(customerPath).Spart;

				core.getModel("currentSalesDocument").setData({});
				core.getModel("currentSalesDocumentLines").setData([]);

				sap.ui.core.UIComponent.getRouterFor(this).navTo("master", {
					from: "customer",
					orgData: salesOrgId + distChannelId + disivisionId,
					customerId: customerId
				});

				this.getView().byId("searchField").setValue("");
				bindingMy.filter(null);
				bindingAll.filter(null);

			},
			handleChangeSalesOrg: function () {
				preLoader.popUpToDisplaySalesOrgs(core.getModel("userPref").getData(), undefined, false, this);
			},

			//handleFavorites = function(oEvent) {
			//   var titleClicked = oEvent.getSource().data("custID");
			//   var idx = myPref.favoriteCustomers.indexOf(titleClicked);
			//   if ( idx > -1){
			//       myPref.favoriteCustomers.splice(idx, 1);
			//   } else {
			//       myPref.favoriteCustomers.push(titleClicked);
			//   }
			//	applyFavorites(titleClicked);
			//},
			//applyFavorites = function(titleClicked){
			//	var idx, favCust = [], favClicked;
			//	if (titleClicked){
			//		core.getModel('allCustomers').getObject('/').findIndex(function(cust){
			//			if(cust.CustomerID == titleClicked) cust["favIcon"] = false;});};
			//	myPref.favoriteCustomers.forEach(function(fav){
			//		idx = core.getModel('allCustomers').getObject('/')
			//					.findIndex(function(cust){
			//						if(cust.CustomerID == fav) {
			//							cust["favIcon"] = true;
			//							favCust.push(cust);
			//							return cust;
			//						}
			//					});
			//	});
			//	core.getModel("myCustomers").setData(favCust);
			//	core.getModel("allCustomers").refresh(true);
			//},
			_pad: function (n, width, z) {
				var paddingChar = z || "0",
					stringToPad = n + "";
				return stringToPad.length >= width ? stringToPad : new Array(width - stringToPad.length + 1).join(paddingChar) + stringToPad;
			}
		});

	});