sap.ui.define([
	"sap/ui/core/Control",
	"sap/m/Text",
	"sap/m/Input"
], function (Control, Text, Input) {
	"use strict";
	return Control.extend("gdt.salesui.s4.control.InputTextInput", {
		metadata: {
			properties: {
				currencyVal: {
					type: "string",
					defaultValue: ""
				},
				text: {
					type: "string",
					defaultValue: ""
				},
				xRateVal: {
					type: "string",
					defaultValue: ""
				},
				editable: {
					type: "boolean",
					defaultValue: true
				},
				visible: {
					type: "boolean",
					defaultValue: true
				}
			},
			aggregations: {
				_curr: {
					type: "sap.m.Input",
					multiple: false,
					visibility: "hidden"
				},
				_text: {
					type: "sap.m.Text",
					multiple: false,
					visibility: "hidden"
				},
				_xRate: {
					type: "sap.m.Input",
					multiple: false,
					visibility: "hidden"
				}
			}
		},
		init: function () {

			this.setAggregation("_curr",
				new Input({
					value: this.getXRateVal(),
					visible: this.getVisible(),
					suggest: this.suggestCurrency.bind(this),
					change: this.changeCurrency.bind(this)
				})
			);

			this.setAggregation("_text",
				new Text({
					text: this.getText(),
					visible: true
				})

			);
			this.setAggregation("_xRate",
				new Input({
					value: this.getXRateVal(),
					visible: this.getVisible()
				})
			);

		},

		setCurrencyVal: function (iValue) {
			this.setProperty("currencyVal", iValue, true);
			this.getAggregation("_curr").setValue(iValue);
		},
		setXRateVal: function (iValue) {
			this.setProperty("xRateVal", iValue, true);
			this.getAggregation("_curr").setValue(iValue);
		},

		setText: function (iValue) {
			this.setProperty("text", iValue, true);
			this.getAggregation("_text").setText(iValue);
		},

		setVisible: function (iValue) {
			this.setProperty("visible", iValue, true);
			this.getAggregation("_text").setVisible(iValue);
			this.getAggregation("_curr").setVisible(iValue);
			this.getAggregation("_xRate").setVisible(iValue);
		},

		setEditable: function (iValue) {
			this.setProperty("editable", iValue, true);
			this.getAggregation("_curr").setEditable(iValue);
			this.getAggregation("_xRate").setEditable(iValue);
		},

		suggestCurrency: function (event, viewConroller) {
			var term = event.getParameter("suggestValue"),
				source = event.getSource(),
				core = sap.ui.getCore(),
				Uom = core.getModel('Uom').getData().results || [],
				suggestions = [];

			suggestions = $.grep(Uom, function (n) {
				return n.Msehl.match(new RegExp(term, "i"));
			});

			source.destroySuggestionItems();
			for (var i = 0, len = (!!suggestions) ? suggestions.length : 0; i < len; i++) {
				source.addSuggestionItem(new sap.ui.core.Item({
					text: suggestions[i].Msehi + '-' + suggestions[i].Msehl
				}));
			}

		},

		changeCurrency: function (event, viewConroller) {
			var source = event.getSource(),
				core = sap.ui.getCore(),
				uom = source.getValue(),
				binding = source.getBinding('value'),
				context = binding.getContext(),
				model = binding.getModel(),
				row = (context) ? model.getProperty(context.getPath()) : model.getData(),
				saveRow = $.extend(true, {}, row),
				uoms = core.getModel("Uom").getData().results || [],
				found = false;

			if (uom) {
				source.setValueState(sap.ui.core.ValueState.None);
				var results = $.grep(uoms, function (n) {
					return ((n.Msehi.toLowerCase() == uom.toLowerCase()) || (n.Msehi.toLowerCase() + '-' + n.Msehl.toLowerCase() == uom.toLowerCase()));
				});
				if (!results || results.length == 0) {
					results = $.grep(uoms, function (n) {
						return n.Msehl.toLowerCase() == uom.toLowerCase();
					});
				}
				if (!!results && results.length == 1) {
					row.BaseUom = results[0].Msehi;
					if (source.getValueState() == sap.ui.core.ValueState.Error) {
						source.setValueState(sap.ui.core.ValueState.None);
						source.setTooltip();
					}
					model.setProperty(context.getPath(), row);
					found = true;
				}

				if (!found) {
					source.setTooltip(new sap.ui.commons.RichTooltip({
						text: 'Entered Unit of Measure(' + uom +
							') is not in Master Data.  If this is the correct name, please contact Master Data Management.',
					}));
					source.setValueState(sap.ui.core.ValueState.Error);
					return false;
				}
			} else {
				row.BaseUom = '';
				source.setTooltip(new sap.ui.commons.RichTooltip({
					text: 'Uom is a required field, please enter.',
				}));
				source.setValueState(sap.ui.core.ValueState.Error);
				return false;
			}
		},

		renderer: function (oRM, oControl) {
			/*			oRM.write("<div");
						oRM.writeControlData(oControl);
						oRM.addClass("salesUITextButton");
						oRM.writeClasses();
						oRM.write(">");			
						oRM.renderControl(oControl.getAggregation("_text"));
						oRM.write("</div>");*/
			oRM.renderControl(oControl.getAggregation("_curr"));
			oRM.renderControl(oControl.getAggregation("_text"));
			oRM.renderControl(oControl.getAggregation("_xRate"));

		}
	});
});