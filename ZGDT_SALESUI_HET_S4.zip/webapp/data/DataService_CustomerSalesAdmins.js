/* global _:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.data.DataService_CustomerSalesAdmins");
$.sap.require("gdt.salesui.s4.util.SAPGatewayHelper");
$.sap.require("sap.ui.core.Core");
//$.sap.require("gdt.salesui.s4.lib.underscoreMin");

gdt.salesui.s4.data.DataService_CustomerSalesAdmins = (function ($, core, _, helper) {
	var getByForeignKey = function (input) {
		return $.Deferred(function (defer) {
			var model = core.getModel();

			model.read("/CustomerSet(CustomerID='" + input.CustomerID + "')/SalesAdmins?$filter=Vkorg eq '" + input.Vkorg + "' and Vtweg eq '" +
				input.Vtweg + "' and Spart eq '" + input.Spart + "'", {
					success: function (data, response) {
						defer.resolve(data.results);
					},
					error: function (response) {
						defer.reject(helper.ParseError(response, "SalesUI Could not fetch the Sales Admins for Customer from SAP."));
					}
				});
		}).promise();
	};

	return {
		getByForeignKey: getByForeignKey
	};

})($, sap.ui.getCore(), _, gdt.salesui.s4.util.SAPGatewayHelper);