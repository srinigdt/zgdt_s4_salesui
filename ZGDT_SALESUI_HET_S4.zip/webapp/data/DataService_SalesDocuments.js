/* global _:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.data.DataService_SalesDocuments");
$.sap.require("gdt.salesui.s4.util.SAPGatewayHelper");
$.sap.require("sap.ui.core.Core");
//$.sap.require("gdt.salesui.s4.lib.underscoreMin");

gdt.salesui.s4.data.DataService_SalesDocuments = (function ($, core, _, helper) {
	var get = function (salesDocumentId) {
			return $.Deferred(function (defer) {
				var model = core.getModel();
				model.read("/SalesDocumentSet(SalesDocumentID='" + salesDocumentId + "')", {
					success: function (data, response) {
						defer.resolve(_fixDataDown(data));
					},
					error: function (data, response) {
						defer.reject(helper.ParseError(data, "SalesUI Could not fetch the Sales Document from SAP."));
					}
				});
			}).promise();
		},
		_fixDataDown = function (data) {
			if (!data) {
				return data;
			}
			if (!data.DocumentCategory) {
				data.DocumentCategory = "B";
			}

			// Below line is changed due to length restriction
			if (data.WBSElement === "000000000000000000000000") {
				data.WBSElement = "";
			}

			if (data.CartonNotes) {
				data.CartonNotes = data.CartonNotes.replace(/(\r\n|\n|\r)/gm, "");
			}

			/* Take care of SAP Date to Timestamp, timezone issue */
			if (data.ValidFrom) {
				data.ValidFrom = new Date(data.ValidFrom.getTime() + (data.ValidFrom.getTimezoneOffset() * 60 * 1000));
			}
			if (data.ValidTo) {
				data.ValidTo = new Date(data.ValidTo.getTime() + (data.ValidTo.getTimezoneOffset() * 60 * 1000));
			}
			if (data.CreatedOn) {
				data.CreatedOn = new Date(data.CreatedOn.getTime() + (data.CreatedOn.getTimezoneOffset() * 60 * 1000));
			}
			if (data.RequestedDeliveryDate) {
				data.RequestedDeliveryDate = new Date(data.RequestedDeliveryDate.getTime() + (data.RequestedDeliveryDate.getTimezoneOffset() * 60 *
					1000));
			}
			if (data.PriceDate) {
				data.PriceDate = new Date(data.PriceDate.getTime() + (data.PriceDate.getTimezoneOffset() * 60 * 1000));
			}

			if (!data.LastChangedOn && data.CreatedOn) {
				data.LastChangedOn = data.CreatedOn;
			} else {
				data.LastChangedOn = new Date(data.LastChangedOn.getTime() + (data.LastChangedOn.getTimezoneOffset() * 60 * 1000));
			}
			// Begin of Insert: Populating default routing, Shipping method while creating sales order 				
			//            if (data.SalesDocumentID === "0000000000") {
			//            var routeOptions  = core.getModel('routeOptions').getData();
			//            var routeOption = _.findWhere(routeOptions, {RouteOptionID: "G"});
			//            
			//            if(routeOption) {
			//            	var shippingMethodValues = routeOption.ShippingRouteSet.results;
			//            	var ShippingMethodValue = _.findWhere(shippingMethodValues, {Default: "X"});
			//            	if(ShippingMethodValue) {
			//            		
			//            		data.Account = ShippingMethodValue.Account;
			//            		data.RouteOptionID = ShippingMethodValue.Routeoption;
			//            		data.ShippingConditionID = ShippingMethodValue.Vsbed;
			//            		data.Scaccode = ShippingMethodValue.Scaccode;            		
			//                 		
			//            	}
			//            	else
			//            		{
			//            		  var ShipMethodValue = _.findWhere(shippingMethodValues, {Vsbed: "01"});
			//            		  if(ShipMethodValue) {
			//            			data.Account = "";
			//                  		data.RouteOptionID = ShipMethodValue.Routeoption;
			//                		data.ShippingConditionID = ShipMethodValue.Vsbed;
			//                		data.Scaccode = ShipMethodValue.Scaccode;   
			//            		  }
			//            		}
			//  
			//            	
			//            }
			//		}
			// End of Insert: Populating default routing, Shipping method while creating sales order 	            

			return data;
		},
		fixDataUp = function (data) {
			if (!data) {
				return data;
			}

			if (!!data.DeliveryBlock && data.DeliveryBlock === '90') {
				data.DeliveryBlock = "";
			}

			if (data.LineItems) {
				_.each(data.LineItems, function (line) {
					// Due to XML Parse Error at the backend, convert raw numbers to strings: 02/12/16  rows[i].SalesDocumentLineID + rows[i].ShipToID;
					line.DummyLineId = line.SalesDocumentLineID + line.ShipToID;
					line.GDTDiscountPercent = line.GDTDiscountPercent.toString();
					line.CustomerDiscountPercent = line.CustomerDiscountPercent.toString();
					line.GrossProfitPercentage = line.GrossProfitPercentage.toString();

					//Due to XML Parse Error at the backend, convert raw numbers to strings: 03/15/16 
					line.ListPrice = line.ListPrice.toString();
					line.UnitCost = line.UnitCost.toString();
					line.UnitPrice = line.UnitPrice.toString();
					line.QTY = line.QTY.toString();
					line.QtyBilled = line.QtyBilled.toString();
					line.ExtendedPrice = line.ExtendedPrice.toString();
					line.ExtendedCost = line.ExtendedCost.toString();
					line.Description = line.Description.substring(0, 40);
					line.CCWLeadTimeDays = (line.CCWLeadTimeDays) ? line.CCWLeadTimeDays.toString() : "";

					if ($.type(line.VendorID) !== "string") {
						if (!line.VendorID || parseInt(line.VendorID) === 0) {
							line.VendorID = "";
						} else {
							line.VendorID = line.VendorID.toString();
						}
					}
					if ($.type(line.SmartNetDuration) !== "string") {
						if (!line.SmartNetDuration || parseInt(line.SmartNetDuration) === 0) {
							line.SmartNetDuration = "";
						} else {
							line.SmartNetDuration = line.SmartNetDuration.toString();
						}
					}
				});
			}

			var payloads = core.getModel("ciscoPayload").getData();
			if (payloads.length > 0) {
				data.payloads = payloads;
			}

			return data;
		},
		getByForeignKey = function (input) {
			return $.Deferred(function (defer) {
				var model = core.getModel();
				//	model.read("/CustomerSet(CustomerID='" + customerId + "')/SalesDocuments", {
				model.read("/CustomerSet(CustomerID='" + input.CustomerID + "')/SalesDocuments?$filter=Vkorg eq '" + input.Vkorg +
					"' and Vtweg eq '" + input.Vtweg + "' and Spart eq '" + input.Spart + "'", {
						success: function (data, response) {
							_.each(data.results, function (result) {
								result = _fixDataDown(result);
							});
							defer.resolve(data.results, response);
						},
						error: function (data) {
							defer.reject(helper.ParseError(data, "SalesUI Could not fetch the Sales Documents for Customer from SAP."));
						}
					});
			}).promise();
		},
		remove = function (salesDocumentId) {
			return $.Deferred(function (defer) {
				var model = core.getModel();
				model.remove("/SalesDocumentSet(SalesDocumentID='" + salesDocumentId + "')", {
					success: function (data, response) {
						if (response.statusCode >= 200 && response.statusCode <= 299) {
							defer.resolve();
						} else {
							defer.reject(helper.ParseError(data, "SalesUI Could not delete the Sales Document from SAP."));
						}
					},
					error: function (data) {
						defer.reject(helper.ParseError(data, "SalesUI Could not delete the Sales Document from SAP."));
					}
				});
			}).promise();
		},

		create = function (salesDocument) {
			return $.Deferred(function (defer) {
				var model = core.getModel();
				fixDataUp(salesDocument);
				model.create("/SalesDocumentSet", salesDocument, {
					success: function (data, response) {
						if (response.statusCode >= 200 && response.statusCode <= 299) {
							defer.resolve(_fixDataDown(data));
						} else {
							defer.reject(helper.ParseError(data, "SalesUI Could not create/update the Sales Document in SAP."));
						}
					},
					error: function (data) {
						defer.reject(helper.ParseError(data, "SalesUI Could not create/update the Sales Document in SAP."));
					},
					async: true
				});
			}).promise();
		};

	return {
		get: get,
		getByForeignKey: getByForeignKey,
		remove: remove,
		create: create
	};

})($, sap.ui.getCore(), _, gdt.salesui.s4.util.SAPGatewayHelper);