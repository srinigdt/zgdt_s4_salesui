/* global _:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.data.DataService_SendMail");
$.sap.require("gdt.salesui.s4.util.SAPGatewayHelper");
$.sap.require("sap.ui.core.Core");
//$.sap.require("gdt.salesui.s4.lib.underscoreMin");

gdt.salesui.s4.data.DataService_SendMail = (function ($, core, _, helper) {
	var send = function (MailBodyContent) {
		return $.Deferred(function (defer) {
			var model = core.getModel();
			var OrgData = core.getModel("userPref").getData();
			model.callFunction("/SendMail", "POST", {
					OrgData: OrgData.Vkorg + "-" + OrgData.Vtweg + "-" + OrgData.Spart,
					ActionType: "M",
					MailContent: MailBodyContent
				}, null,
				function (data, response) { //success
					if (response.statusCode >= 200 && response.statusCode <= 299) {
						defer.resolve(data);
					} else {
						defer.reject(helper.ParseError(data, "SalesUI fail to send Email to MasterData maintenance Team."));
					}
				},
				function (data) { //error
					defer.reject(helper.ParseError(data, "SalesUI fail to send Email to MasterData maintenance Team."));
				},
				true // Async
			);
		}).promise();
	};

	return {
		send: send
	};

})($, sap.ui.getCore(), _, gdt.salesui.s4.util.SAPGatewayHelper);