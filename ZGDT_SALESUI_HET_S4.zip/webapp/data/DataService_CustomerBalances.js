/* global _:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.data.DataService_CustomerBalances");
$.sap.require("gdt.salesui.s4.util.SAPGatewayHelper");
$.sap.require("sap.ui.core.Core");
//$.sap.require("gdt.salesui.s4.lib.underscoreMin");

gdt.salesui.s4.data.DataService_CustomerBalances = (function ($, core, _, helper) {
	var get = function (customerId) {
		return $.Deferred(function (defer) {
			var model = core.getModel();

			model.read("/CustomerSet(CustomerID='" + customerId + "')/Balances", {
				success: function (data, response) {
					defer.resolve(data);
				},
				error: function (response) {
					defer.reject(helper.ParseError(response, "SalesUI Could not fetch the Customer Balances for Customer from SAP."));
				}
			});
		}).promise();
	};

	return {
		get: get
	};

})($, sap.ui.getCore(), _, gdt.salesui.s4.util.SAPGatewayHelper);