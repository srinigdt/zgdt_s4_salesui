/* global _:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.data.DataService_CiscoPunchOut");
$.sap.require("gdt.salesui.s4.util.SAPGatewayHelper");
$.sap.require("sap.ui.core.Core");
gdt.salesui.s4.data.DataService_CiscoPunchOut = (function ($, core, _, helper) {
	var get = function (inputData) {
		return $.Deferred(function (defer) {
			var model = core.getModel();
			//	    		model.callFunction("/CiscoPunchOut","GET", {CiscoPw:inputData.CiscoPw,CiscoUserId:inputData.CiscoUserId,WebHookUrl:""},null,
			model.callFunction("/CiscoPunchOut", "GET", {
					CiscoPw: 'Welcome1',
					CiscoUserId: 'SXVASAMSETTI',
					WebHookUrl: ""
				}, null,
				/*		model.callFunction("/SendMail","POST", {ActionType:"M",MailContent:"Testing"},null,*/
				function (data, response) { //success
					if (response.statusCode >= 200 && response.statusCode <= 299) {
						defer.resolve(data);
					} else {
						defer.reject(helper.ParseError(data, "SalesUI fail to Punchout, might be due to Wrong Credentails/destination not reachable."));
					}
				},
				function (data) { //error
					defer.reject(helper.ParseError(data, "SalesUI fail to Punchout, might be due to Wrong Credentails/destination not reachable.."));
				},
				true // Async
			);
		}).promise();
	};

	return {
		get: get
	};

})($, sap.ui.getCore(), _, gdt.salesui.s4.util.SAPGatewayHelper);