/* global _:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.data.DataService_SalesDocumentLines");
$.sap.require("gdt.salesui.s4.util.SAPGatewayHelper");
$.sap.require("sap.ui.core.Core");
//$.sap.require("gdt.salesui.s4.lib.underscoreMin");
$.sap.require("gdt.salesui.s4.util.ItemLineIdReOrderer");

gdt.salesui.s4.data.DataService_SalesDocumentLines = (function ($, core, _, helper, LineOrderer) {
	var _fixDataDown = function (row) {
			if (!row) {
				return row;
			}
			row.MaterialID = row.MaterialID.replace(/^0+/, "");
			if (Boolean(row.CreatedOn)) {
				row.CreatedOn = new Date(row.CreatedOn.getTime() + (row.CreatedOn.getTimezoneOffset() * 60 * 1000));
			}
			if (Boolean(row.DeliveryDate)) {
				row.DeliveryDate = new Date(row.DeliveryDate.getTime() + (row.DeliveryDate.getTimezoneOffset() * 60 * 1000));
			}
			if (Boolean(row.SmartNetBeginDate)) {
				row.SmartNetBeginDate = new Date(row.SmartNetBeginDate.getTime() + (row.SmartNetBeginDate.getTimezoneOffset() * 60 * 1000));
			}
			if (Boolean(row.SmartNetEndDate)) {
				row.SmartNetEndDate = new Date(row.SmartNetEndDate.getTime() + (row.SmartNetEndDate.getTimezoneOffset() * 60 * 1000));
			}
			if (Boolean(row.SmartNetDuration) && parseInt(row.SmartNetDuration) === 0) {
				row.SmartNetDuration = "";
			}
			if (!row.StructuredLineID) {
				row.StructuredLineID = parseInt(row.SalesDocumentLineID) + ".0";
			}

			if (!row.LastUpdatedOn && row.CreatedOn) {
				row.LastUpdatedOn = row.CreatedOn;
			} else {
				row.LastUpdatedOn = new Date(row.LastUpdatedOn.getTime() + (row.LastUpdatedOn.getTimezoneOffset() * 60 * 1000));
			}
			if ((row.ItemCategory.substring(0, 1) === "Z") || (!!row.ReasonForRejection && !row.MarkedAsDeleted)) {
				row.Selected = true;
			}
			return row;
		},
		_RearrageData = function (data) {
			return LineOrderer.reOrderData(data);
		},
		getByForeignKey = function (salesDocumentId) {
			return $.Deferred(function (defer) {
				var model = core.getModel();
				model.read("/SalesDocumentSet(SalesDocumentID='" + salesDocumentId + "')/LineItems", {
					success: function (data, response) {
						data.results = _RearrageData(data.results);
						_.each(data.results, function (result) {
							result = _fixDataDown(result);
						});
						defer.resolve(data.results);
					},
					error: function (data) {
						defer.reject(helper.ParseError(data, "SalesUI Could not fetch the Details for Sales Document from SAP."));
					}
				});
			}).promise();
		};

	return {
		getByForeignKey: getByForeignKey
	};

})($, sap.ui.getCore(), _, gdt.salesui.s4.util.SAPGatewayHelper, gdt.salesui.s4.util.ItemLineIdReOrderer);