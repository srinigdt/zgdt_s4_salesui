/* global _:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.data.DataService_SalesDocumentAttachments");
$.sap.require("gdt.salesui.s4.util.SAPGatewayHelper");
$.sap.require("sap.ui.core.Core");
//$.sap.require("gdt.salesui.s4.lib.underscoreMin");

gdt.salesui.s4.data.DataService_SalesDocumentAttachments = (function ($, core, _, helper) {
	var getByForeignKey = function (salesDocumentId) {
		return $.Deferred(function (defer) {
			var model = core.getModel();
			model.read("/SalesDocumentSet(SalesDocumentID='" + salesDocumentId + "')/AttachmentsLink", {
				success: function (data, response) {
					defer.resolve(data.results);
				},
				error: function (data) {
					defer.reject(helper.ParseError(data, "SalesUI Could not fetch the Attachments for Sales Document from SAP."));
				}
			});
			console.log('---docs fetched ---');
		}).promise();
	};

	return {
		getByForeignKey: getByForeignKey
	};

})($, sap.ui.getCore(), _, gdt.salesui.s4.util.SAPGatewayHelper);