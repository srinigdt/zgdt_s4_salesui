/* global _:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.data.DataService_Draft");
$.sap.require("gdt.salesui.s4.util.SAPGatewayHelper");
$.sap.require("sap.ui.core.Core");
//$.sap.require("gdt.salesui.s4.lib.underscoreMin");

gdt.salesui.s4.data.DataService_Draft = (function ($, core, _, helper) {
	var get = function (input) {
			return $.Deferred(function (defer) {
				var model = core.getModel();
				model.read("/DraftSet(DraftId='" + input.DraftId + "',DraftType='" + input.DraftType + "',Kunnr='" + input.Kunnr + "' )", {
					success: function (data, response) {
						defer.resolve(_fixDataDown(data));
					},
					error: function (data, response) {
						console.log("No Draft found for selection input");
						defer.reject();

					}
				});
			}).promise();
		},
		_fixDataDown = function (data) {

			return data;
		},
		fixDataUp = function (data) {
			return data;
		},
		getByForeignKey = function (input) {
			return $.Deferred(function (defer) {
				var model = core.getModel();
				model.read("/DraftSet()", {
					success: function (data, response) {
						_.each(data.results, function (result) {
							result = _fixDataDown(result);
						});
						defer.resolve(data.results, response);
					},
					error: function (data) {
						defer.reject(helper.ParseError(data, "SalesUI Could not fetch the Draft Documents  from SAP."));
					}
				});
			}).promise();
		},
		remove = function (DraftId) {
			return $.Deferred(function (defer) {
				var model = core.getModel();

				model.remove("/DraftSet(DraftId='" + DraftId + "',DraftType='',Kunnr='')", {
					success: function (data, response) {
						if (response.statusCode >= 200 && response.statusCode <= 299) {
							defer.resolve();
						} else {
							defer.reject(helper.ParseError(data, "SalesUI Could not delete the Sales Document from SAP."));
						}
					},
					error: function (data) {
						defer.reject(helper.ParseError(data, "SalesUI Could not delete the Sales Document from SAP."));
					}
				});
			}).promise();
		},

		create = function (draft) {
			return $.Deferred(function (defer) {
				var model = core.getModel();
				fixDataUp(draft);
				model.create("/DraftSet", draft, {
					success: function (data, response) {
						if (response.statusCode >= 200 && response.statusCode <= 299) {
							defer.resolve(_fixDataDown(data));
						} else {
							console.log("unable to create Draft");
						}
					},
					error: function (data) {
						console.log("unable to create Draft");
					},
					async: true
				});
			}).promise();
		};

	return {
		get: get,
		getByForeignKey: getByForeignKey,
		remove: remove,
		create: create
	};

})($, sap.ui.getCore(), _, gdt.salesui.s4.util.SAPGatewayHelper);