/* global _:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.data.DataService");
$.sap.require("gdt.salesui.s4.data.DataService_Customers");
$.sap.require("gdt.salesui.s4.data.DataService_CustomerAcctMgrs");
$.sap.require("gdt.salesui.s4.data.DataService_CustomerBalances");
$.sap.require("gdt.salesui.s4.data.DataService_CustomerBillTos");
$.sap.require("gdt.salesui.s4.data.DataService_CustomerEndCustomers");
$.sap.require("gdt.salesui.s4.data.DataService_CustomerPayers");
$.sap.require("gdt.salesui.s4.data.DataService_CustomerSalesAdmins");
$.sap.require("gdt.salesui.s4.data.DataService_CustomerShipTos");
$.sap.require("gdt.salesui.s4.data.DataService_Materials");
$.sap.require("gdt.salesui.s4.data.DataService_SalesDocuments");
$.sap.require("gdt.salesui.s4.data.DataService_SalesDocumentLines");
$.sap.require("gdt.salesui.s4.data.DataService_SalesDocumentAttachments");
$.sap.require("gdt.salesui.s4.data.DataService_RejectionReasons");
$.sap.require("gdt.salesui.s4.data.DataService_UserPrefs");
$.sap.require("gdt.salesui.s4.data.DataService_DocumentFlow");
$.sap.require("gdt.salesui.s4.data.DataService_SalesOrderAvailableQuantity");
$.sap.require("gdt.salesui.s4.data.DataService_SendMail");
$.sap.require("gdt.salesui.s4.data.DataService_Variant");
$.sap.require("gdt.salesui.s4.data.DataService_CiscoPunchOut");
$.sap.require("gdt.salesui.s4.data.DataService_Draft");

gdt.salesui.s4.data.DataService = (function (customers, customerbalances, customershiptos, customerbilltos, customerpayers,
	customerendcustomers, customersalesadmins, customeracctmgrs, materials, salesdocuments,
	salesdocumentlines, salesdocumentattachments, rejectionreasons, userprefs, documentflow,
	SoAvailableQty, EmailNotification, variant, ciscoPunchOut, draft) {
	var dataservice = {
		customers: customers,
		customerbalances: customerbalances,
		customershiptos: customershiptos,
		customerbilltos: customerbilltos,
		customerpayers: customerpayers,
		customerendcustomers: customerendcustomers,
		customersalesadmins: customersalesadmins,
		customeracctmgrs: customeracctmgrs,
		materials: materials,
		salesdocuments: salesdocuments,
		salesdocumentlines: salesdocumentlines,
		salesdocumentattachments: salesdocumentattachments,
		rejectionreasons: rejectionreasons,
		userprefs: userprefs,
		documentflow: documentflow,
		SoAvailableQty: SoAvailableQty,
		EmailNotification: EmailNotification,
		variant: variant,
		ciscoPunchOut: ciscoPunchOut,
		draft: draft
	};

	return dataservice;
})(gdt.salesui.s4.data.DataService_Customers,
	gdt.salesui.s4.data.DataService_CustomerBalances,
	gdt.salesui.s4.data.DataService_CustomerShipTos,
	gdt.salesui.s4.data.DataService_CustomerBillTos,
	gdt.salesui.s4.data.DataService_CustomerPayers,
	gdt.salesui.s4.data.DataService_CustomerEndCustomers,
	gdt.salesui.s4.data.DataService_CustomerSalesAdmins,
	gdt.salesui.s4.data.DataService_CustomerAcctMgrs,
	gdt.salesui.s4.data.DataService_Materials,
	gdt.salesui.s4.data.DataService_SalesDocuments,
	gdt.salesui.s4.data.DataService_SalesDocumentLines,
	gdt.salesui.s4.data.DataService_SalesDocumentAttachments,
	gdt.salesui.s4.data.DataService_RejectionReasons,
	gdt.salesui.s4.data.DataService_UserPrefs,
	gdt.salesui.s4.data.DataService_DocumentFlow,
	gdt.salesui.s4.data.DataService_SalesOrderAvailableQuantity,
	gdt.salesui.s4.data.DataService_SendMail,
	gdt.salesui.s4.data.DataService_Variant,
	gdt.salesui.s4.data.DataService_CiscoPunchOut,
	gdt.salesui.s4.data.DataService_Draft);