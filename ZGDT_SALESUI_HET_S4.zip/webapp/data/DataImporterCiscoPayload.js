/* global _:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.data.DataImporterCiscoPayload");
$.sap.require("sap.ui.core.Core");
$.sap.require("gdt.salesui.s4.data.DataContext");
$.sap.require("gdt.salesui.s4.util.AddressHelper");
//$.sap.require("gdt.salesui.s4.lib.underscoreMin");

gdt.salesui.s4.data.DataImporterCiscoPayload = (function ($, core, _, datacontext, addressHelper) {
	var Defaults = [],
		templateName = "",
		CiscoMfrID = null,
		CiscoVdrID = null,
		IngramVdrID = null,
		TechDataVdrID = null,

		ImportFromCiscoPayLoad = function (payLoad, salesOrderHeader, salesOrderDetails, errors, missingAddresses, _createNewLine,
			_lookupPartID, _determineItemCategory, append) {

			var def = null,
				header = false,
				template = null,
				headerField = null,
				headerValue = null,
				fieldCount = 0,
				optionalCount = 0,
				nextLineNum = 10,
				line = [],

				newline = {},
				templates = [],
				vendorError = "",
				salesOrderDetailsArray = (append) ? salesOrderDetails.getData() : [],
				customerID = core.getModel("currentCustomer").getProperty("/CustomerID"),
				i = 0,
				j = 0,
				k = 0,
				l = 0,
				l2 = 0,
				l3 = Defaults.length;

			def = $.Deferred(function (defer) {
				if (!Boolean(payLoad)) {
					return;
				};
				var searchAddress = "",
					parentNode,
					childNode,
					CCWQuoteID = "",
					CCWDealID = "",
					newRows = [],
					keys = [],

					mfrs = core.getModel("globalSelectItems").getProperty("/Manufacturers") || [],
					vdrs = core.getModel("globalSelectItems").getProperty("/Vendors") || [],
					payloadHeader = payLoad.Header,
					payloadItems = payLoad.Items,
					payloadMapping = payLoad.mappingFields,
					ciscoMfr = _.findWhere(mfrs, {
						SortL: "CIS001"
					}),
					ciscoVdr = _.findWhere(vdrs, {
						SortL: "CIS001"
					}),
					techDataVdr = _.findWhere(vdrs, {
						SortL: "TEC001"
					}),
					shipTos = core.getModel("customerSelectItems").getProperty("/ShipTos"),
					ingramVdr = _.findWhere(vdrs, {
						SortL: "ING001"
					});

				//				var dummyLineItem = _createNewLine([]);
				//				    delete dummyLineItem.__metadata;
				//				    delete dummyLineItem.Selected;
				//				    delete dummyLineItem.Selected;
				//				var soItemFields = Object.getOwnPropertyNames(dummyLineItem);

				var soItemFields = Object.getOwnPropertyNames(payloadMapping);
				var totalFields = soItemFields.length;

				if (!missingAddresses) {
					missingAddresses = [];
				}
				if (!errors) {
					errors = [];
				}
				salesOrderDetailsArray = _.filter(salesOrderDetailsArray, function (line) {
					return (!!line.MaterialID);
				});

				CiscoMfrID = (ciscoMfr) ? ciscoMfr.ManufacturerID : null;
				CiscoVdrID = (ciscoVdr) ? ciscoVdr.ManufacturerID : null;
				IngramVdrID = (ingramVdr) ? ingramVdr.ManufacturerID : null;
				TechDataVdrID = (techDataVdr) ? techDataVdr.ManufacturerID : null;

				Defaults.push({
					field: "VendorID",
					value: CiscoVdrID
				});
				Defaults.push({
					field: "ManufacturerID",
					value: CiscoMfrID
				});

				// Setting Sales Document Header Details
				// Set Cisco Payload Details to save in Custom Table for Future Reference

				// Below lines are commented as each document might contain more than one payload(requests), so below code is replaced to fill in table(array) at below(end)
				//				salesOrderHeader.setProperty("/Payld",payLoad.response );
				//				salesOrderHeader.setProperty("/Reqid",payLoad.reqReqID );

				if (header) {
					if (!salesOrderHeader.getProperty("/" + headerField.field)) {
						salesOrderHeader.setProperty("/" + headerField.field, headerValue);
					}
				}

				_.each(payloadItems, function (item, lineNumber) {
					newline = _createNewLine((newRows.length === 0) ? salesOrderDetailsArray : newRows);

					newline.CustomerPOLineID = newline.SalesDocumentLineID;

					for (i = 0; i < totalFields; i++) {

						switch (soItemFields[i]) {
						case "ExternalQuoteID":
							newline[soItemFields[i]] = item[soItemFields[i]];
							if (CCWQuoteID === "") {
								CCWQuoteID = newline[soItemFields[i]].toString();
							}
							break;
						case "DealID":
							newline[soItemFields[i]] = item[soItemFields[i]];
							if (CCWDealID === "") {
								CCWDealID = newline[soItemFields[i]];
							}
							break;
						case "ManufacturerPartID":
							newline[soItemFields[i]] = item[soItemFields[i]];
							break;
						case "Description":
							newline[soItemFields[i]] = item[soItemFields[i]];
							break;
						case "QTY":
							newline[soItemFields[i]] = item[soItemFields[i]];
							break;
						case "UnitOfMeasure":
							newline[soItemFields[i]] = item[soItemFields[i]];
							break;
						case "UnitPrice":
							newline[soItemFields[i]] = item[soItemFields[i]];
							break;
						case "LeadTime":
							newline[soItemFields[i]] = item[soItemFields[i]];
							break;
						case "ciscoMagicKey":
							newline[soItemFields[i]] = item[soItemFields[i]];
							break;
						case "VendorID":
							newline[soItemFields[i]] = item[soItemFields[i]];

							switch (newline[soItemFields[i]]) {
							case "CISCO":
								newline[soItemFields[i]] = CiscoVdrID;
								break;
							case "INGRAMMICRO":
								newline[soItemFields[i]] = IngramVdrID;
								break;
							case "TECHDATA":
								newline[soItemFields[i]] = TechDataVdrID;
								break;
							default:
								if (newline.ManufacturerPartID.length > 0) {
									var vendor = newline[soItemFields[i]];
									if (vendor.length > 0) {
										if (/^[0-9]+$/.test(vendor)) { // checking only numeric characters
											if (Boolean(_.findWhere(vdrs, {
													ManufacturerID: vendor
												}))) {
												newline[soItemFields[i]] = vendor;
											} else {
												newline[column.field] = "Error";
												vendorError = vendorError + "Vendor/Buy Method( " + vendor + ") with line having Part ID#(" + newline.ManufacturerPartID +
													") doesn't exist in SAP system. Please check and Try again. \n";
											}
										}
									}
								}
								break;
							}
							break;
						case "StructuredLineID":

							if (salesOrderDetailsArray.length === 0) // Checking whether it is not in append Mode
							{
								newline[soItemFields[i]] = item[soItemFields[i]].toString();
								if (newline[soItemFields[i]].length === 1) {
									newline[soItemFields[i]] = newline[soItemFields[i]] + ".0";
								}
							} else { //Append Mode
								var previousLineID = (newRows.length === 0) ? salesOrderDetailsArray[salesOrderDetailsArray.length - 1].StructuredLineID :
									payloadItems[lineNumber - 1].StructuredLineID;

								if (parseInt(previousLineID) === parseInt(item[soItemFields[i]])) {
									if (parseInt(salesOrderDetailsArray[salesOrderDetailsArray.length - 1].StructuredLineID) === 1 && newRows.length === 0) {
										newline[soItemFields[i]] = parseInt(newline[soItemFields[i]]);
									} else {
										newline[soItemFields[i]] = newline[soItemFields[i]] - 1;
									}

									var lineLevels = item[soItemFields[i]].toString().split(".");
									for (var n = 1; n < lineLevels.length; n++) {
										newline[soItemFields[i]] = newline[soItemFields[i]] + "." + lineLevels[n];
									}
								}

								newline[soItemFields[i]] = newline[soItemFields[i]].toString();
								if (newline[soItemFields[i]].length === 1) {
									newline[soItemFields[i]] = newline[soItemFields[i]] + ".0";
								}
							}

							if (newRows.length > 0) {
								var exist = _.find(newRows, function (row) {
									return row.StructuredLineID === newline[soItemFields[i]];
								});
								if (Boolean(exist)) {
									newline[soItemFields[i]] = newline[soItemFields[i]] + "0";
								}
							}

							break;
						case "SmartNetBeginDate":
							try {
								newline.SmartNetBeginDate = new Date(item[soItemFields[i]]);
							} catch (ex) { // Convert Date failed
								console.error("Bad date in SmartNet Begin Date import field");
								newline.SmartNetBeginDate = null;
							}
							break;
						case "SmartNetEndDate":
							try {
								newline.SmartNetEndDate = new Date(item[soItemFields[i]]);
							} catch (ex) { // Convert Date failed
								console.error("Bad date in SmartNet End Date import field");
								newline.SmartNetEndDate = null;
							}
							break;

						default:
							newline[soItemFields[i]] = item[soItemFields[i]];
						}

					}

					//               ciscoVdr.ManufacturerID
					if (!newline.WBSElement) {
						nextLineNum += 10;
						if ((newline.VendorID !== ciscoVdr.ManufacturerID) && (!!newline.DealID)) {
							//Per Karen, do not import DealID if not purchasing from Cisco
							newline.DealID = "";
						}

						if (Boolean(newline.GDTPrice)) {
							newline.GDTDiscount = (parseFloat(newline.GDTPrice) - parseFloat(newline.ListPrice)).toString();
							delete newline.GDTPrice;
						}

						if (Boolean(newline.CustomerPrice)) {
							newline.CustomerDiscount = (parseFloat(newline.CustomerPrice) - parseFloat(newline.ListPrice)).toString();
							delete newline.CustomerPrice;
						}

						if (Boolean(newline.Dummy)) {
							delete newline.Dummy;
						}

						if (Boolean(newline.CustomerManufacturerPartID)) {
							delete newline.CustomerManufacturerPartID;
						}

						if (Boolean(newline.ExtendedListPrice)) {
							if (Boolean(newline.QTY)) {
								newline.ListPrice = newline.ExtendedListPrice / newline.QTY;
							} else {
								newline.ListPrice = newline.ExtendedListPrice;
							}
							delete newline.ExtendedListPrice;
						}
						if (!!newline.ExtendedPrice && parseFloat(newline.ExtendedPrice) !== 0) {
							if (Boolean(newline.QTY)) {
								newline.UnitPrice = Math.round(newline.ExtendedPrice * 100.0 / newline.QTY) / 100.0;
							} else {
								newline.UnitPrice = newline.ExtendedPrice;
							}
						}
						if (!!newline.ExtendedCost && parseFloat(newline.ExtendedCost) !== 0) {
							if (Boolean(newline.QTY)) {
								newline.UnitCost = Math.round(newline.ExtendedCost * 100.0 / newline.QTY) / 100.0;
							} else {
								newline.UnitCost = newline.ExtendedCost;
							}
						}
						if (!!newline.UnitPrice && (parseFloat(newline.UnitPrice) !== 0) && (parseFloat(newline.ListPrice) !== 0) && (newline.UnitPrice !==
								newline.ListPrice) && (!newline.CustomerDiscount || (parseFloat(newline.CustomerDiscount) === 0))) {
							newline.CustomerDiscount = newline.UnitPrice - newline.ListPrice;
						}
						if (!!newline.UnitCost && (parseFloat(newline.UnitCost) !== 0) && (newline.UnitCost !== newline.ListPrice) && (!newline.GDTDiscount ||
								(parseFloat(newline.GDTDiscount) === 0))) {
							newline.GDTDiscount = newline.UnitCost - newline.ListPrice;
						}
						if (!newline.CustomerPartID && !!newline.ManufacturerPartID) {
							newline.CustomerPartID = newline.ManufacturerPartID;
						}
						if (!!newline.GDTDiscountPercent && (!newline.GDTDiscount || (parseFloat(newline.GDTDiscount) === 0 && parseFloat(newline.GDTDiscountPercent) !==
								0))) {
							newline.GDTDiscount = Math.round(newline.ListPrice * newline.GDTDiscountPercent) / 100.0;
						}
						if (!!newline.GDTDiscount && (!newline.GDTDiscountPercent || (parseFloat(newline.GDTDiscount) !== 0 && parseFloat(newline.GDTDiscountPercent) ===
								0))) {
							newline.GDTDiscountPercent = Math.round((newline.GDTDiscount / newline.ListPrice) * 100000.0) / 1000.0; // Discounts to 3 DP
						}
						if (!!newline.CustomerDiscountPercent && (!newline.CustomerDiscount || (parseFloat(newline.CustomerDiscount) === 0 &&
								parseFloat(newline.CustomerDiscountPercent) !== 0))) {
							newline.CustomerDiscount = Math.round(newline.ListPrice * newline.CustomerDiscountPercent) / -100.0;
						}
						/*	
							if (!!newline.CustomerDiscount && (!newline.CustomerDiscountPercent || (parseFloat(newline.CustomerDiscount) !== 0 && parseFloat(newline.CustomerDiscountPercent) === 0))) {
								newline.CustomerDiscountPercent = Math.round((newline.CustomerDiscount / newline.ListPrice) * -100000.0) / 1000.0;  // Discounts to 3 DP
							}*/
						newline.Selected = true;

						newRows.push(newline);
					}
				});

				// All lines parsed...now process import
				if (vendorError.length > 0) {
					defer.reject(vendorError);
					return;
				}
				if ((!Boolean(payloadItems)) || (payloadItems.length < 1)) {
					defer.reject("Unable to retrieve data from Cisco Payload Data.  Please try again.");
				} else {
					if (newRows.length === 0) {
						defer.reject("No recognisable parts were found in Import file.  File ignored.");
					} else {
						_.each(newRows, function (row) {
							var address = "",
								addressMatch,
								key = {
									CustomerID: customerID,
									ManufacturerID: row.ManufacturerID,
									MaterialID: "",
									MfrPartID: ($.isNumeric(row.ManufacturerPartID)) ? row.ManufacturerPartID.toUpperCase().trim().replace(/^0+/, "") : row.ManufacturerPartID
										.toUpperCase().trim()
								};

							keys.push(key);

							if (templateName === "SmartNet") {
								row.ShipToID = "ONETIME";
							}

							if (Boolean(row.PartnerName)) {
								address = row.PartnerName;
								delete row.PartnerName;
							}

							if (Boolean(row.Street)) {
								address += ((address.length !== 0) ? ", " : "") + row.Street;
								delete row.Street;
							}

							if (Boolean(row.City)) {
								address += ((address.length !== 0) ? ", " : "") + row.City;
								delete row.City;
							}

							if (Boolean(row.State)) {
								address += ((address.length !== 0) ? ", " : "") + row.State;
								delete row.State;
							}

							if (Boolean(row.Zip)) {
								address += ((address.length !== 0) ? ", " : "") + row.Zip;
								delete row.Zip;
							}

							if (Boolean(address)) {
								addressMatch = addressHelper.find(address, shipTos);
								if (Boolean(addressMatch)) {
									row.ShipToID = addressMatch.PartnerID;
								} else {
									missingAddresses.push(address);
								}
							}

						});

						keys = _.uniq(keys, function (key) {
							return key.MaterialID + key.MfrPartID;
						});
						keys = _.filter(keys, function (key) {
							return !datacontext.materials.getLocal(key);
						});

						datacontext.materials.load(keys).done(function () {
							var duration;
							_.each(newRows, function (newline, idx) {
								_lookupPartID(newline, newline.ManufacturerPartID, false, true, null, null, true);

								if (parseFloat(newline.ListPrice) === 0) {
									newline.GDTDiscountPercent = "00.00";
								}
								newline.ItemCategory = _determineItemCategory(newline);
								if (!!newline.SmartNetDuration && (parseInt(newline.SmartNetDuration).toString() !== newline.SmartNetDuration)) {
									duration = newline.SmartNetDuration.split(" ")[0];
									if (parseInt(duration).toString() === duration) {
										newline.SmartNetDuration = duration;
									} else {
										newline.SmartNetDuration = "";
									}
								}
								if (Boolean(newline.SmartNetDuration)) {
									newline.Description = ("" + newline.Description).substring(0, 30) + " (" + newline.SmartNetDuration.substring(0, 2) +
										" mnth)";
								}

								if (newline.MaterialID) {
									newline.CustomerMaterialID = newline.MaterialID;
									newRows[idx] = newline;
								} else {
									errors.push(newline);
								}
							});

							// Restrict Materials with 4 series to add in UI(4 Series will have itemCategory (ZPFS,ZTAO,YTAO) ,Only launch team/Admin Team will maintain from GUI not from UI
							var Seeries4Material = _.find(newRows, function (row) {
								return (row.ItemCategory === "ZPFS" || row.ItemCategory === "YTAO" || row.ItemCategory === "ZTAO");
							});
							if (Seeries4Material === undefined || (!!Seeries4Material && Seeries4Material.length === 0)) {

								Array.prototype.push.apply(salesOrderDetailsArray, newRows);
								_setParentChildRelationships(salesOrderDetailsArray);
								if ((!errors || errors.length === 0) && (!missingAddresses || missingAddresses.length === 0)) {
									if (salesOrderDetailsArray.length > 100) {
										salesOrderDetails.setSizeLimit(salesOrderDetailsArray.length + 100);
									}
									salesOrderDetails.setData(salesOrderDetailsArray);
									// Store each instance of Cisco Payload into Global model.Up on Save, payload will be transferred to dataservice(salesDocument)                        

									var payload = {
										"Vbeln": salesOrderHeader.getProperty("/SalesDocumentID"),
										"Reqid": payLoad.reqReqID.toString(),
										"CCWQuoteID": CCWQuoteID,
										"CCWDealID": CCWDealID,
										"Payld": payLoad.response,
										"PunchoutTime": new Date()

									};
									var payloadModel = core.getModel("ciscoPayload");
									var payloadData = payloadModel.getData();
									payloadData.push(payload);
									payloadData = _.uniq(payloadData);
									payloadModel.setData(payloadData);
									// end of Cisco Payload  update                      

								}

							} else {
								errors.length = 0;
								sap.m.MessageBox.show(
									"Sales UI does not allow you to add materials starts with 4 Series ( Professional Services ). These materials are only maintained from SAP GUI by Projects/Launch team", {
										icon: sap.m.MessageBox.Icon.ERROR,
										title: "Authorizaton Issue",
										actions: sap.m.MessageBox.Action.OK,
										onClose: null
									});

							}
							defer.resolve();
						}).fail(function (msg) {
							defer.reject(msg);
						});
					}
				}

			});

			return def.promise();
		},

		_setParentChildRelationships = function (lines) {
			var l = lines.length,
				parentLineID = 0,
				i = 0;

			for (i = 0; i < l; i++) {
				parentLineID = _findParentOf(lines[i], lines);
				lines[i].ParentLineID = parentLineID;
			}

		},

		_findParentOf = function (line, lines) {
			var parent = null,
				lastNode = 0,
				lastNodeIdx = 0,
				topParent = _pad(0, 6),
				parentNode = "";

			if (!line.StructuredLineID) {
				return topParent;
			} // No structured line id so assume this has no parent

			lastNodeIdx = line.StructuredLineID.lastIndexOf(".");
			if (lastNodeIdx === -1 || lastNodeIdx >= (line.StructuredLineID.length - 1)) {
				return topParent;
			} // No "." in structured line id so must be top level, no parent

			lastNode = parseInt(line.StructuredLineID.substring(lastNodeIdx + 1));
			parentNode = line.StructuredLineID.substring(0, lastNodeIdx);

			if (!lastNode) { // ends in .0 so move up the tree for parent 
				lastNodeIdx = parentNode.lastIndexOf(".");
				if (lastNodeIdx === -1 || lastNodeIdx >= (parentNode.length - 1)) {
					return topParent;
				} // there isn"t anything further up the tree

				lastNode = parseInt(parentNode.substring(lastNodeIdx + 1));
				parentNode = parentNode.substring(0, lastNodeIdx);
			}

			// ensure parent node does not end in .0
			lastNodeIdx = parentNode.lastIndexOf(".");
			if (lastNodeIdx > -1 && lastNodeIdx < (parentNode.length)) {
				lastNode = parseInt(parentNode.substring(lastNodeIdx + 1));
				if (!lastNode) {
					parentNode = parentNode.substring(0, lastNodeIdx);
				}
			}

			parent = _.find(lines, function (candidate) {
				return (candidate.StructuredLineID === parentNode) || candidate.StructuredLineID === parentNode + ".0";
			});

			if (!parent) {
				return topParent;
			}

			return parent.SalesDocumentLineID;

		},

		_pad = function (n, width, z) {
			var paddingChar = z || "0",
				stringToPad = n + "";
			return stringToPad.length >= width ? stringToPad : new Array(width - stringToPad.length + 1).join(paddingChar) + stringToPad;
		};

	return {
		ImportFromCiscoPayLoad: ImportFromCiscoPayLoad
	};
})($, sap.ui.getCore(), _, gdt.salesui.s4.data.DataContext, gdt.salesui.s4.util.AddressHelper);