/* global _:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.data.DataService_Customers");
$.sap.require("gdt.salesui.s4.util.SAPGatewayHelper");
$.sap.require("sap.ui.core.Core");
//$.sap.require("gdt.salesui.s4.lib.underscoreMin");

gdt.salesui.s4.data.DataService_Customers = (function ($, core, _, helper) {
	var get = function (input) {
			return $.Deferred(function (defer) {
				var model = core.getModel();
				/*  	model.read("/CustomerSet(CustomerID='" + input[0] + "')", {*/ //CustomerID eq '"+input[0]+"' and 
				model.read("/CustomerSet?$filter=CustomerID eq '" + input.CustomerID + "' and Vkorg eq '" + input.Vkorg + "' and Vtweg eq '" +
					input.Vtweg + "' and Spart eq '" + input.Spart + "'", {
						success: function (data, response) {
							if (data.results.length > 0) {
								data = data.results[0];
							} else {
								data = {};
							}
							_dataDownFix(data);
							defer.resolve(data);
						},
						error: function (response) {
							defer.reject(helper.ParseError(response, "SalesUI Could not fetch the Customer from SAP."));
						}
					});
			}).promise();
		},

		//Begin of Change: To get the results of Duplicate PO :Change by SXVASAMSETTI, 02/16/16		
		getPO = function (CustomerPOID) {
			return $.Deferred(function (defer) {
				var model = core.getModel();
				model.read("/CheckDuplicatePOSet(CustomerPOID='" + CustomerPOID + "')", {
					success: function (data, response) {
						defer.resolve(data);
					},
					error: function (data, response) {
						defer.reject(helper.ParseError(data, "Failed to check Duplicate PO."));
					}
				});
			}).promise();
		},
		// End of Change			

		_dataDownFix = function (data) {
			if (data.ContactLastName && data.ContactFirstName) {
				data.ContactFullName = data.ContactLastName + ", " + data.ContactFirstName;
			} else {
				data.ContactFullName = "(Contact Unknown)";
			}

			if (!data.ContactPhone) data.ContactPhone = (data.Phone) ? data.Phone : "(Phone # Unknown)";
		},
		load = function (userData) {
			return $.Deferred(function (defer) {
				var model = core.getModel();
				//model.read("RouteOptionSet?$expand=ShippingRouteSet&$filter=Customer eq '"+customerId+"'" , {
				model.read("/CustomerSet?$filter=Vkorg eq '" + userData.Vkorg + "' and Vtweg eq '" +
					userData.Vtweg + "' and Spart eq '" + userData.Spart + "'", {
						success: function (data, response) {
							_.each(data.results, function (row) {
								_dataDownFix(row);
							});
							defer.resolve(data.results);
						},
						error: function (response) {
							defer.reject(helper.ParseError(response, "SalesUI Could not fetch the Customers from SAP."));
						}
					});
			}).promise();
		};

	return {
		get: get,
		getPO: getPO,
		load: load
	};

})($, sap.ui.getCore(), _, gdt.salesui.s4.util.SAPGatewayHelper);