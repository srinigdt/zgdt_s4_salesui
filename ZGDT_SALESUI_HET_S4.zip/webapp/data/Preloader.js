/* global _:true */
/* global gdt:true */
$.sap.declare("gdt.salesui.s4.data.Preloader");
$.sap.require("gdt.salesui.s4.data.DataContext");
$.sap.require("sap.ui.core.Core");
$.sap.require("gdt.salesui.s4.util.IndexDBHelper");
//$.sap.require("gdt.salesui.s4.lib.underscoreMin");

gdt.salesui.s4.data.Preloader = (function ($, core, _, datacontext, indexdbhelper) {
	var init = function (model) {

			/*		window.callback = function(result) {
					    alert( 'Call back is called');
					};
					window.onmessage = function (e) {
					    if (e.data) {
					    	 alert( 'onmessage Call back is called');
					    } else {
					    	 alert( 'No dataonmessage Call back is called');
					    }
					};
						*/
			/*			$( document ).ready(function() {
						    console.log( "ready!" );
						    var form = false;
							var length = document.forms.length;
							for(var i = 0; i < length; i++) {
							    if(form.id == "wanted_id") {
							        form = document.forms[i];
							    }
							}
						
							var nameValue = (document.getElementById("cxml-urlencoded"))?document.getElementById("cxml-urlencoded").value:"";
						});
					window.Response = function(e){
						alert( 'Responsemessage Call back is called');
					};*/
			// indexdbhelper.init( );
			var that = this;

			var systemInfoDfr = $.Deferred(function (defer) {
					var oHashChanger = new sap.ui.core.routing.HashChanger();
					var sHash = window.location.hash;
					/*				var urlParts;
								    urlParts = window.location.href.split("/indexDBidEq");
								    if(urlParts.length > 1){
									window.location.replace(urlParts[0]||window.location.href);
									if(Boolean(urlParts) && (urlParts[1] !== null) ){
										indexdbhelper.read(urlParts[1])
										};
								    }*/
					model.read("/SystemProfileSet()", {
						success: function (data) {
							var systemInfo = core.getModel("systemInfo");
							if (data.results.length > 0) {
								systemInfo.setData(data.results[0]);
								datacontext.userprefs.get(systemInfo.getProperty("/Uname")).done(function (userData) {
									core.getModel("userPref").setData(userData);
									if (sHash.indexOf("orgData") !== -1) { // WebRefresh done
										var start = sHash.indexOf("orgData") + "orgData".length + 1;
										var end = start + 8;
										var orgData = sHash.substring(start, end);
										userData.Vkorg = orgData.substring(0, 4);
										userData.Vtweg = orgData.substring(4, 6);
										userData.Spart = orgData.substring(6, 8);
										var start = sHash.indexOf("docType") + "docType".length + 1;
										var end = start + 4;
										var docType = sHash.substring(start, end);
										userData.docType = docType;
									}
									if (!Boolean(userData.Vkorg)) {
										sap.m.MessageToast.show("Sales Org is not assigned");
										_popUpToDisplaySalesOrgs(userData, defer, that);
									} else {
										_loadAllCustomers(userData, defer);
									}

								}).fail(function (msg) {
									defer.reject(msg);
								});
							} else {
								defer.reject();
							}
						},
						error: function () {
							defer.reject();
						}
					});
				}),

				/*	var systemInfoDfr = $.Deferred(function(defer) {
				model.read("/SystemProfileSet()", {
	            	success: function(data) {
	                	var systemInfo = core.getModel("systemInfo");
	                	if (data.results.length > 0) {
	                		systemInfo.setData(data.results[0]);
							datacontext.userprefs.load(systemInfo.getProperty("/Uname")).done(function () {
								defer.resolve();
							}).fail(function(msg) {
								defer.reject(msg);
							});
	                	} else {
							defer.reject();
	                	}
	            	},
					error: function() {
						defer.reject();
					}
	            });
			}),
			
			
			allCustomersDfr = $.Deferred(function(defer) {
					datacontext.customers.load().done(function () {
						var allCustomers = core.getModel('allCustomers'),
							results = datacontext.customers.getAllLocal();
	                		allCustomers.setData(results);
	                		defer.resolve();
	                }).fail(function (response) {
	                	defer.reject(response);
	                });
				}),
				
			myCustomersDfr = $.Deferred(function(defer) {
				model.read("/MyCustomerSet()", {
	            	success: function(data) {
	                	var myCustomers = core.getModel('myCustomers');
	                	myCustomers.setData(_.uniq(data.results, function(item) { 
	                	    return item.CustomerID;
	                	}));
	                	defer.resolve();
	            	},
					error: function() {
						defer.reject();
					}
	            });
			}),

*/

				blankDetailLineDfr = $.Deferred(function (defer) {
					model.read(
						"/SalesDocumentDetailSet(SalesDocumentID='0000000000',SalesDocumentLineID='000000',ManufacturerID='000000000000',MaterialID='00',ManufacturerPartID='00')", {
							success: function (data) {
								var blankDetailLine = core.getModel("blankDetailLine");
								blankDetailLine.setData(data);
								defer.resolve();
							},
							error: function () {
								defer.reject();
							}
						});
				}),

				shippingConditionsDfr = $.Deferred(function (defer) {
					model.read("/ShippingConditionsSet", {
						success: function (data) {
							var globalSelectItems = core.getModel("globalSelectItems");
							globalSelectItems.setProperty("/ShippingConditions", data.results);
							defer.resolve();
						},
						error: function () {
							defer.reject();
						}
					});
				}),

				/*			shippingConditionsDfr2 = $.Deferred(function(defer) {
								model.read('/RouteOptionSet?$expand=ShippingRouteSet', {
									success: function(data) {
										var routeOptionsModel = core.getModel('routeOptions');
										routeOptionsModel.setData(data.results);
										defer.resolve();
									},
									error: function() {
										defer.reject();
									}
								});
							}),*/

				rejectionReasonsDfr = $.Deferred(function (defer) {
					datacontext.rejectionreasons.load().done(function () {
						var rejectionReasons = core.getModel("rejectionReasons"),
							results = datacontext.rejectionreasons.getAllLocal();

						rejectionReasons.setData(results);
						defer.resolve();
					}).fail(function (response) {
						defer.reject(response);
					});
				}),

				/*			invoiceOutputDetermineValuesDfr = $.Deferred(function(defer) {
								model.read("/HelpValues", {
					            	success: function(data) {
					                	var model = core.getModel('invoiceOutputValues');
					                	model.setData(data.results);
					                	defer.resolve();
					            	},
									error: function() {
										defer.reject();
									}
					            });			
							}),*/

				itemCatConfigValuesDfr = $.Deferred(function (defer) {
					var model = core.getModel();
					var noData = [];
					var itemCatConfigValuesModel = core.getModel("itemCatConfigValues");
					model.callFunction("/GetItemCategories", "GET", {}, null,
						function (data, response) { //success    			        
							if (response.statusCode >= 200 && response.statusCode <= 299) {
								itemCatConfigValuesModel.setData(data.results);
							} else {
								itemCatConfigValuesModel.setData(noData);
							}
						},
						function (data) { //error
							itemCatConfigValuesModel.setData(noData);
							defer.reject();
						},
						false // Async
					);

				}),

				currencyValuesDfr = $.Deferred(function (defer) {
					var noData = [];
					var currencyModel = core.getModel("currencies");
					model.callFunction("/HelpValues", "GET", {
							helpName: "currency",
							inputValue: ""
						}, null,
						function (data, response) { //success    			        
							if (response.statusCode >= 200 && response.statusCode <= 299) {
								currencyModel.setData(data.results);
							} else {
								currencyModel.setData(noData);
							}
							defer.resolve();
						},
						function (data) { //error
							currencyModel.setData(noData);
							defer.reject();
						},
						false // Async
					);

				}),

				invoiceOutputDetermineValuesDfr = $.Deferred(function (defer) {
					var noData = [];
					var invoiceOutputModel = core.getModel("invoiceOutputValues");
					model.callFunction("/HelpValues", "GET", {
							helpName: "invoiceOutput",
							inputValue: ""
						}, null,
						function (data, response) { //success    			        
							if (response.statusCode >= 200 && response.statusCode <= 299) {
								invoiceOutputModel.setData(data.results);
							} else {
								invoiceOutputModel.setData(noData);
							}
							defer.resolve();
						},
						function (data) { //error
							invoiceOutputModel.setData(noData);
							defer.reject();
						},
						false // Async
					);

				}),

				// Begin of Insert By ANIL PALADUGU Id: AXPALADUGU for DIR functionality 		
				direOutputDetermineValuesDfr = $.Deferred(function (defer) {
					var noData = [];
					var dirOutputModel = core.getModel("dirOutputValues");
					model.callFunction("/HelpValues", "GET", {
							helpName: "dirOutput",
							inputValue: ""
						}, null,
						function (data, response) { //success    			        
							if (response.statusCode >= 200 && response.statusCode <= 299) {
								dirOutputModel.setData(data.results);
							} else {
								dirOutputModel.setData(noData);
							}
							defer.resolve();
						},
						function (data) { //error
							dirOutputModel.setData(noData);
							defer.reject();
						},
						false // Async
					);

				}),

				// End of Insert By ANIL PALADUGU Id: AXPALADUGU for DIR functionality 				

				orderTypesDfr = $.Deferred(function (defer) {
					var model = core.getModel();
					var noData = [];
					var orderTypeModel = core.getModel("orderTypes");
					model.callFunction("/GetValues", "GET", {
							WhatValues: "orderTypes",
							Value1: "",
							Value2: "",
							Value3: ""
						}, null,
						function (data, response) { //success    			        
							if (response.statusCode >= 200 && response.statusCode <= 299) {
								orderTypeModel.setData(data.results);
							} else {
								orderTypeModel.setData(noData);
							}
						},
						function (data) { //error
							orderTypeModel.setData(noData);
							defer.reject();
						},
						false // Async
					);

				}),

				organizationalDataDfr = $.Deferred(function (defer) {
					_loadSaleOrgsValues();
				});

			//allCustomersDfr,myCustomersDfr,		

			return $.when(systemInfoDfr, blankDetailLineDfr, shippingConditionsDfr, rejectionReasonsDfr).promise();
		},

		_popUpToDisplaySalesOrgs = function (userData, defer, ref, vc) {
			var that = (Boolean(ref)) ? ref : this;
			//defer.reject('Sales Org is not assigned');
			if (!that._oDialog) {
				that._oDialog = sap.ui.xmlfragment("gdt.salesui.s4.fragment.SelectOrganizationalData", that);
				that._oDialog.setModel(core.getModel("orgData"), "orgData");
				that._oDialog.attachConfirm(function (event) {
					var selectedItem = event.getParameter('selectedItem');
					if (Boolean(selectedItem)) {
						userData.Vkorg = selectedItem.getCells()[0].getText();
						userData.VkorgT = selectedItem.getCells()[1].getText();
						_loadAllCustomers(userData, defer, vc);
						core.getModel("userPref").setData(userData);
						if (Boolean(defer)) {
							_setUserSalesOrgParameter(userData.UserID, userData.Vkorg);
						}
					} else {
						_handleCancelSelectOrganizationalData(event);
					}
				});
				that._oDialog.attachCancel(function (event) {
					_handleCancelSelectOrganizationalData(event);
				});
			}
			_loadSaleOrgsValues();
			that._oDialog.open();
		},

		_setUserSalesOrgParameter = function (userId, salesOrg) {
			var setParamDefr = $.Deferred(function (defer) {
				var model = core.getModel();
				model.callFunction("/ExecuteAction", "POST", {
						ActionType: "setUserParameterSalesOrg",
						Value1: userId,
						Value2: salesOrg,
						Value3: ""
					}, null,
					function (data, response) { //success
						if (response.statusCode >= 200 && response.statusCode <= 299) {
							defer.resolve(data);
						} else {
							defer.reject();
						}
					},
					function (data) { //error
						defer.reject();
					},
					true // Async
				);
			});
		},

		_loadSaleOrgsValues = function () {
			var currentPage;
			var model = core.getModel(),
				loadSaleOrgsValuesDfr = $.Deferred(function (defer) {
					var noData = [];
					var orgDataModel = core.getModel("orgData");
					if (orgDataModel.getData().length === 0) {
						model.callFunction("/HelpValues", "GET", {
								helpName: "orgData",
								inputValue: ""
							}, null,
							function (data, response) { //success    			        
								if (response.statusCode >= 200 && response.statusCode <= 299) {
									orgDataModel.setData(data.results);
								} else {
									orgDataModel.setData(noData);
								}
								if (Boolean(defer)) {
									defer.resolve();
								}
								if (Boolean(currentPage)) {
									currentPage.setBusy(false);
								}
							},
							function (data) { //error
								orgDataModel.setData(noData);
								if (Boolean(defer)) {
									defer.reject();
								}
								if (Boolean(currentPage)) {
									currentPage.setBusy(false);
								}
							},
							false // Async
						);
					} else {
						defer.resolve();
					}
				});
		},
		_handleCancelSelectOrganizationalData = function (event) {
			if (Boolean(sap.ushell.Container)) {
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigator.toExternal({
					target: {
						semanticObject: "#"
					}
				});
			} else {
				sap.m.MessageToast.show("App can't be exited");
			}
		},

		_loadAllCustomers = function (userData, defer, vc) {
			var currentPage;
			if (Boolean(vc)) {
				currentPage = vc.getView().byId("page");
				currentPage.setBusyIndicatorDelay(0);
				currentPage.setBusy(true);
			}

			var model = core.getModel();
			datacontext.customers.load(userData).done(function () {
				var allCustomers = core.getModel("allCustomers"),
					results = datacontext.customers.getLocalByForeignKey(userData.Vkorg); //getAllLocal();	

				allCustomers.setData(results);
				if (Boolean(defer)) {
					defer.resolve();
				}
				if (Boolean(currentPage)) {
					currentPage.setBusy(false);
				}
			}).fail(function (response) {
				if (Boolean(defer)) {
					defer.reject();
				}
				if (Boolean(currentPage)) {
					currentPage.setBusy(false);
				}
			});

			model.read("/MyCustomerSet?$filter=Vkorg eq '" + userData.Vkorg + "' and Vtweg eq '" +
				userData.Vtweg + "' and Spart eq '" + userData.Spart + "'", {
					success: function (data) {
						var myCustomers = core.getModel("myCustomers");
						myCustomers.setData(_.uniq(data.results, function (item) {
							return item.CustomerID;
						}));
						if (Boolean(defer)) {
							defer.resolve();
						}
					},
					error: function () {
						if (Boolean(defer)) {
							defer.reject();
						}
					}
				});

			var manufacturersDfr = $.Deferred(function (defer) {
				model.read("/ManufacturerSet?$filter=Vkorg eq '" + userData.Vkorg + "'", {
					success: function (data) {
						var globalSelectItems = core.getModel("globalSelectItems"),
							mfrs = null,
							vdrs = null;

						data.results.unshift({
							ManufacturerID: "",
							ManufacturerName: ""
						});
						mfrs = _.filter(_.reject(data.results, {
							ManufacturerName: "Alt Payee"
						}), {
							KTOKK: "MNFR"
						});
						vdrs = _.filter(_.reject(data.results, {
							ManufacturerName: "Alt Payee"
						}), {
							KTOKK: "YB01"
						});
						globalSelectItems.setProperty("/Manufacturers", mfrs);
						globalSelectItems.setProperty("/Vendors", vdrs);
						defer.resolve();
					},
					error: function () {
						defer.reject();
					}
				});
			});

		};

	return {
		init: init,
		loadAllCustomers: _loadAllCustomers,
		popUpToDisplaySalesOrgs: _popUpToDisplaySalesOrgs
	};
})($, sap.ui.getCore(), _, gdt.salesui.s4.data.DataContext, gdt.salesui.s4.util.IndexDBHelper);